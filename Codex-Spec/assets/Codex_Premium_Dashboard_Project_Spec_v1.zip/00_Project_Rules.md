# 00_Project_Rules.md — Hard Rules for Codex

## Rule 1 — Recovery First

If `npm run build` fails, do not refactor, redesign, or add UI polish.

Only fix the build failure.

## Rule 2 — Audit Before Code

Before changing any import/export, inspect:

- `package.json`
- `package-lock.json`
- `src/ui/vendor/index.ts`
- `src/ui/vendor/medusa.ts`
- `src/ui/vendor/mantine.ts`
- `src/ui/vendor/charts.ts`
- `src/ui/vendor/lucide.ts`
- all files importing from `src/ui/vendor`

## Rule 3 — No Fake Export

Never assume that a symbol exists.

Before using any of these, verify the corresponding vendor module exports it:

- `Card`
- `Text`
- `Badge`
- `MantineText`
- `MantineBadge`
- `PieChart`
- `Pie`
- `Cell`
- `clsx`
- icons

If it does not exist, either:
- add it correctly to the existing vendor submodule, or
- change the consuming file to use a symbol that exists, or
- request user approval.

## Rule 4 — No Direct Dependency Leakage

Feature components should not directly import third-party packages unless the project already does so consistently.

Preferred dependency path:

`Feature UI -> ui/vendor/* -> installed libraries`

For utilities such as `clsx`, exporting through the vendor layer is acceptable only after confirming `clsx` is installed and listed in `package.json`.

## Rule 5 — Existing Architecture First

Respect the current structure before proposing improvements.

Do not impose a new design system until the current architecture is understood.

## Rule 6 — No New Files While Broken

When the build is broken, do not add new files.

Only modify existing files required to recover build.

## Rule 7 — Build After Every Step

After any meaningful edit:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm run build
```

If the build fails, stop and fix that error before continuing.

## Rule 8 — Do Not Delete Working Architecture

Do not delete existing adapter/vendor/component files just to remove errors.

Prefer compatibility repair.

## Rule 9 — No Placeholder UI

Do not replace charts, cards, tables, or modals with placeholder text unless explicitly requested for emergency recovery.

## Rule 10 — Visual Work Starts Only After Green Build

Premium design work may start only after:

- plugin build succeeds,
- backend admin resolves plugin admin entry,
- no TypeScript errors remain in plugin source.
