# 07_Codex_Checklist.md

Before editing:

- [ ] Read `PROJECT.md`
- [ ] Read `00_Project_Rules.md`
- [ ] Run build
- [ ] Capture first real error
- [ ] Inspect package.json
- [ ] Inspect vendor exports
- [ ] Confirm if app is broken or green

During editing:

- [ ] Modify the minimum number of files
- [ ] Do not add files while build is broken
- [ ] Do not invent exports
- [ ] Do not introduce uninstalled packages
- [ ] Keep existing architecture intact
- [ ] Run build after each step

Before final response:

- [ ] Build result reported
- [ ] Files changed listed
- [ ] Remaining errors listed, if any
- [ ] Next exact command provided
