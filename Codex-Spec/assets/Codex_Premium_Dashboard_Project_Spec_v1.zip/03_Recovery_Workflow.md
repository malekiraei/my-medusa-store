# 03_Recovery_Workflow.md — Build Recovery Protocol

Use this file when the app/plugin does not build.

## Step 1 — Capture Exact Error

Run:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm run build
```

Copy only the first actual TypeScript/Vite errors.

## Step 2 — Classify Error

### A. Missing package

Example:

```txt
Cannot find module 'clsx'
```

Fix:
- verify package.json
- run install only if user approves
- then export through vendor if needed

### B. Missing vendor export

Example:

```txt
Module "../vendor" has no exported member "MantineBadge"
```

Fix:
- inspect `src/ui/vendor/*`
- either add real export to existing vendor submodule
- or update consuming import to existing symbol
- do not invent fake exports

### C. Wrong icon props

Example:

```txt
Property 'level' does not exist on LucideProps
```

Fix:
- identify which component is mistakenly resolved as icon
- use correct Medusa UI component or wrapper
- do not pass UI props to SVG icon components

### D. Plugin admin entry not resolved

Example:

```txt
Failed to resolve import "medusa-premium-recovery/admin"
```

Fix:
- confirm plugin package name
- confirm plugin admin build output
- clean backend `.medusa`
- rebuild plugin
- restart backend

Do not create a new admin entry file unless the original file truly does not exist and user approves.

## Step 3 — Clean Build Cache When Needed

Backend cache:

```bash
cd C:\Users\H.M\my-medusa-store\apps\backend
rmdir /s /q .medusa
```

Plugin cache:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
rmdir /s /q .medusa
```

## Step 4 — Windows EPERM Recovery

If npm fails with:

```txt
EPERM: operation not permitted, unlink esbuild.exe
```

Run:

```bash
taskkill /F /IM node.exe
```

Close VS Code/terminals if needed, then retry.

## Step 5 — Stop After Green Build

Once build is green, stop recovery work and report the exact change set.
