# Premium Dashboard Rewrite — Codex Specification Package v1.0

This package is the working instruction set for continuing the Premium Recovery plugin inside VS Code/Codex.

Start here:

1. Read `PROJECT.md`.
2. Read `00_Project_Rules.md`.
3. Run the audit checklist before changing any file.
4. If the app/build is broken, follow `03_Recovery_Workflow.md` first.
5. Do not begin visual redesign until build is green.

The original user-provided instruction ZIP is included unchanged under:

`original_uploaded_package/Premium-Dashboard-Rewrite-Docs(2).zip`

If extracted successfully, its contents are also available under:

`original_uploaded_package/extracted/`
