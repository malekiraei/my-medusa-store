# 10_Codex_Work_Order_Template.md

Use this prompt inside Codex:

---

You are working on the Medusa plugin `medusa-premium-recovery`.

Before editing, read:

1. `PROJECT.md`
2. `00_Project_Rules.md`
3. `03_Recovery_Workflow.md`
4. `07_Codex_Checklist.md`

Current goal:

Recover the plugin build first. Do not redesign UI until build is green.

Rules:

- Do not create new files while build is broken.
- Do not add fake exports.
- Do not assume installed packages.
- Inspect package.json and vendor exports first.
- Fix only the current build errors.
- Run `npm run build` after changes.
- Report exactly which files changed.

After build is green, ask before starting visual polish.
