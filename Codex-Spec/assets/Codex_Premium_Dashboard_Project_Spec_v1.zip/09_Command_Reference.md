# 09_Command_Reference.md

## Plugin root

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
```

## Build plugin

```bash
npm run build
```

## Install clsx if approved

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm install clsx
```

## Backend root

```bash
cd C:\Users\H.M\my-medusa-store\apps\backend
```

## Clear backend Medusa cache

```bash
rmdir /s /q .medusa
```

## Kill locked node processes on Windows

```bash
taskkill /F /IM node.exe
```

## Restart TypeScript server in VS Code

Open command palette:

```txt
Ctrl + Shift + P
```

Run:

```txt
TypeScript: Restart TS Server
```
