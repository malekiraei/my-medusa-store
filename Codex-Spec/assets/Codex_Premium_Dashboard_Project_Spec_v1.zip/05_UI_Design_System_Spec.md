# 05_UI_Design_System_Spec.md — Premium Medusa-Compatible UI

## Goal

Create a visually premium dashboard while staying compatible with Medusa Admin.

The plugin should feel like it belongs inside Medusa, but still have a refined signature.

## Visual Principles

- Calm SaaS aesthetic.
- Soft surfaces.
- High-quality spacing.
- Subtle elevation.
- Clear hierarchy.
- No noisy gradients.
- No decorative clutter.
- Professional status colors.
- Mobile-first layout.

## Spacing

Use an 8px rhythm:

- 4px micro gap
- 8px small gap
- 12px compact card inner gap
- 16px normal card padding
- 24px section gap
- 32px large section gap

## Radius

Recommended:

- small elements: 8px
- badges/buttons: 8–10px
- cards: 12–16px
- modal panels: 16px

## Shadows

Use restrained shadows:

- default card: subtle
- hover card: slightly elevated
- modals: stronger but soft

Avoid heavy black shadows.

## Color System

Use semantic tones:

- success: green
- warning: amber/orange
- critical: red
- info: blue
- neutral: gray/slate

Use Medusa tokens where possible.

## Typography

- strong metric value
- small muted labels
- descriptive secondary text
- consistent title sizing

Avoid oversized text that breaks Medusa admin density.

## Cards

Metric card requirements:

- icon container
- label
- value
- secondary detail
- optional trend
- optional progress
- responsive grid

Cards should look premium but not detached from Medusa.

## Tables

Tables must be clean:

- compact rows
- clear status badges
- hover state
- aligned numeric values
- no excessive borders
- readable empty states

## Modals

Modal design:

- clear title
- short description
- strong primary action
- soft destructive action styling
- keyboard-friendly
- no custom modal if Medusa component exists

## Charts

Charts must use real data or production-like data from actual plugin state.

Charts should be:

- readable
- minimal
- responsive
- label-safe
- compatible with admin dark/light modes if possible

## Icons

Icons should communicate meaning, not decoration.

Use a central icon policy/layer.

Do not pass unsupported props to icon components.
