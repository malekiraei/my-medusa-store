# 06_Component_Standards.md

## Metric Components

Single source of truth should be under:

`src/ui/components/metric`

Avoid duplicate root-level metric card definitions unless legacy compatibility requires them.

If duplicate files exist, do not delete immediately while build is broken. First map imports.

## Dashboard Components

`DashboardCards.tsx` must not assume vendor exports exist.

Before importing anything from `ui/vendor`, confirm the export path.

## Status Adapter

`src/ui/adapters/status.ts` must not use a hand-written icon type that conflicts with the actual icon library.

If using Medusa icons, type against their actual component type or use `React.ComponentType` with compatible SVG props.

Do not assume Lucide types unless using `lucide-react`.

## Charts

Chart components must import from the project’s chart vendor module only.

Before adding chart types, confirm `vendor/charts.ts` exports them.

## Class Utilities

If `clsx` is used:

- it must be installed,
- declared in package.json,
- exported from vendor if project uses vendor-first policy.

Optional future improvement after green build:
- introduce a `cn()` utility only with user approval.
