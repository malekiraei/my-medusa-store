# Premium Dashboard Rewrite — Codex Specification Package v1.0

This package is the working instruction set for continuing the Premium Recovery plugin inside VS Code/Codex.

Start here:

1. Read `PROJECT.md`.
2. Read `00_Project_Rules.md`.
3. Run the audit checklist before changing any file.
4. If the app/build is broken, follow `03_Recovery_Workflow.md` first.
5. Do not begin visual redesign until build is green.

The original user-provided instruction ZIP is included unchanged under:

`original_uploaded_package/Premium-Dashboard-Rewrite-Docs(2).zip`

If extracted successfully, its contents are also available under:

`original_uploaded_package/extracted/`


---

# PROJECT.md — Codex Entry Point

## Project Context

Project: `medusa-premium-recovery`  
Host workspace: `C:\Users\H.M\my-medusa-store`  
Plugin path: `apps\medusa-premium-recovery`  
Backend path: `apps\backend`

The user wants a premium Medusa-compatible admin dashboard for the Premium Recovery plugin.

The target is not merely a prettier UI. The target is:

- Medusa-compatible admin UI.
- Real dependency usage.
- No fake imports.
- No placeholder components.
- Build-safe incremental development.
- A visually premium dashboard with a distinct plugin signature.
- Tables, cards, modals, charts, badges, icons, and states must share one design language.

## Current Priority

If the project does not build, stop all redesign work.

Current workflow priority:

1. Recover build.
2. Audit dependencies.
3. Stabilize vendor layer.
4. Stabilize existing UI files.
5. Only then improve visual design.

## Non-Negotiable User Preference

The user does not want speculative files or random architectural additions while the app is broken.

Do not create new files unless:
- the build is already green, or
- the user explicitly approves the new file, or
- the new file is part of the agreed design-system stage.

## Important Past Failure

Previous attempts introduced mismatches such as:
- importing `clsx` from vendor before confirming it exists.
- using `lucide-react` assumptions while the plugin had `@medusajs/icons`.
- adding exports that did not exist in vendor submodules.
- modifying UI before build recovery.

Do not repeat these mistakes.


---

# 00_Project_Rules.md — Hard Rules for Codex

## Rule 1 — Recovery First

If `npm run build` fails, do not refactor, redesign, or add UI polish.

Only fix the build failure.

## Rule 2 — Audit Before Code

Before changing any import/export, inspect:

- `package.json`
- `package-lock.json`
- `src/ui/vendor/index.ts`
- `src/ui/vendor/medusa.ts`
- `src/ui/vendor/mantine.ts`
- `src/ui/vendor/charts.ts`
- `src/ui/vendor/lucide.ts`
- all files importing from `src/ui/vendor`

## Rule 3 — No Fake Export

Never assume that a symbol exists.

Before using any of these, verify the corresponding vendor module exports it:

- `Card`
- `Text`
- `Badge`
- `MantineText`
- `MantineBadge`
- `PieChart`
- `Pie`
- `Cell`
- `clsx`
- icons

If it does not exist, either:
- add it correctly to the existing vendor submodule, or
- change the consuming file to use a symbol that exists, or
- request user approval.

## Rule 4 — No Direct Dependency Leakage

Feature components should not directly import third-party packages unless the project already does so consistently.

Preferred dependency path:

`Feature UI -> ui/vendor/* -> installed libraries`

For utilities such as `clsx`, exporting through the vendor layer is acceptable only after confirming `clsx` is installed and listed in `package.json`.

## Rule 5 — Existing Architecture First

Respect the current structure before proposing improvements.

Do not impose a new design system until the current architecture is understood.

## Rule 6 — No New Files While Broken

When the build is broken, do not add new files.

Only modify existing files required to recover build.

## Rule 7 — Build After Every Step

After any meaningful edit:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm run build
```

If the build fails, stop and fix that error before continuing.

## Rule 8 — Do Not Delete Working Architecture

Do not delete existing adapter/vendor/component files just to remove errors.

Prefer compatibility repair.

## Rule 9 — No Placeholder UI

Do not replace charts, cards, tables, or modals with placeholder text unless explicitly requested for emergency recovery.

## Rule 10 — Visual Work Starts Only After Green Build

Premium design work may start only after:

- plugin build succeeds,
- backend admin resolves plugin admin entry,
- no TypeScript errors remain in plugin source.


---

# 01_Environment_Audit.md

Before edits, Codex must gather facts.

## Commands

Run from plugin root:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm pkg get name version dependencies devDependencies peerDependencies
npm run build
```

Run from workspace root if needed:

```bash
cd C:\Users\H.M\my-medusa-store
npm ls @medusajs/ui @medusajs/icons clsx recharts lucide-react @mantine/core
```

## Audit Targets

Check whether these packages are installed and where they are declared:

- `@medusajs/ui`
- `@medusajs/icons`
- `clsx`
- `recharts`
- `lucide-react`
- `@mantine/core`
- `react`
- `react-dom`

## Output Required Before Editing

Codex should produce a short audit summary:

- installed packages
- missing packages
- vendor files and their current exports
- broken import lines
- exact build errors
- safest recovery plan

Do not edit until this audit is complete.


---

# 02_Dependency_And_Vendor_Policy.md

## Vendor Layer Purpose

`src/ui/vendor/*` is a compatibility boundary.

It must re-export real installed package symbols only.

It must not contain fake objects, placeholder components, or invented aliases unless the alias points to a real installed export.

## Recommended Structure

Existing vendor index should remain simple:

```ts
export * from "./medusa"
export * from "./lucide"
export * from "./charts"
export * from "./mantine"
```

If `clsx` is installed and package.json includes it, this is acceptable:

```ts
export { default as clsx } from "clsx"
```

Only add this after dependency audit confirms `clsx` exists.

## Important Package Notes

### clsx

Use case:
- conditional className composition
- metric card variants
- status badge variants
- table row states
- modal open/disabled states
- responsive grid classes

Allowed usage:
- through vendor export, if project policy requires all UI dependencies to pass through vendor.

### Icons

The project may use official Medusa icons:

```ts
@medusajs/icons
```

Additional icon libraries may be used only if:
- installed,
- declared in package.json,
- wrapped through an existing vendor/icon abstraction,
- type compatibility is confirmed.

### Charts

Charts must use real installed chart library exports.

Do not import `PieChart`, `Pie`, or `Cell` unless `src/ui/vendor/charts.ts` actually exports them from an installed library.

### Mantine

Do not use Mantine symbols unless `@mantine/core` is installed and vendor/mantine exports them.

Do not invent aliases like `MantineBadge` unless the alias is explicitly exported in `vendor/mantine.ts`.


---

# 03_Recovery_Workflow.md — Build Recovery Protocol

Use this file when the app/plugin does not build.

## Step 1 — Capture Exact Error

Run:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm run build
```

Copy only the first actual TypeScript/Vite errors.

## Step 2 — Classify Error

### A. Missing package

Example:

```txt
Cannot find module 'clsx'
```

Fix:
- verify package.json
- run install only if user approves
- then export through vendor if needed

### B. Missing vendor export

Example:

```txt
Module "../vendor" has no exported member "MantineBadge"
```

Fix:
- inspect `src/ui/vendor/*`
- either add real export to existing vendor submodule
- or update consuming import to existing symbol
- do not invent fake exports

### C. Wrong icon props

Example:

```txt
Property 'level' does not exist on LucideProps
```

Fix:
- identify which component is mistakenly resolved as icon
- use correct Medusa UI component or wrapper
- do not pass UI props to SVG icon components

### D. Plugin admin entry not resolved

Example:

```txt
Failed to resolve import "medusa-premium-recovery/admin"
```

Fix:
- confirm plugin package name
- confirm plugin admin build output
- clean backend `.medusa`
- rebuild plugin
- restart backend

Do not create a new admin entry file unless the original file truly does not exist and user approves.

## Step 3 — Clean Build Cache When Needed

Backend cache:

```bash
cd C:\Users\H.M\my-medusa-store\apps\backend
rmdir /s /q .medusa
```

Plugin cache:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
rmdir /s /q .medusa
```

## Step 4 — Windows EPERM Recovery

If npm fails with:

```txt
EPERM: operation not permitted, unlink esbuild.exe
```

Run:

```bash
taskkill /F /IM node.exe
```

Close VS Code/terminals if needed, then retry.

## Step 5 — Stop After Green Build

Once build is green, stop recovery work and report the exact change set.


---

# 04_Incremental_Rewrite_Plan.md

All future work must follow this order.

## Phase 0 — Audit

No code changes.

- package audit
- vendor export audit
- component import audit
- duplicate file audit
- build status

## Phase 1 — Build Stabilization

Only fix build errors.

No visual polish.

## Phase 2 — Vendor Normalization

Make vendor exports real and consistent.

No feature redesign.

## Phase 3 — Primitive Components

Stabilize low-level primitives:

- card surfaces
- badges
- buttons
- typography wrappers
- icon wrappers
- progress indicators

## Phase 4 — Composite Components

Stabilize:

- metric cards
- metric grids
- trend components
- chart cards
- table cards
- modal containers

## Phase 5 — Feature Components

Improve actual dashboard views:

- `page.tsx`
- `DashboardCards.tsx`
- dashboard components
- operations list
- system health views

## Phase 6 — Visual Polish

Only after build is green.

Apply premium visual layer.

## Phase 7 — Final QA

Run build and inspect UI manually in Medusa admin.


---

# 05_UI_Design_System_Spec.md — Premium Medusa-Compatible UI

## Goal

Create a visually premium dashboard while staying compatible with Medusa Admin.

The plugin should feel like it belongs inside Medusa, but still have a refined signature.

## Visual Principles

- Calm SaaS aesthetic.
- Soft surfaces.
- High-quality spacing.
- Subtle elevation.
- Clear hierarchy.
- No noisy gradients.
- No decorative clutter.
- Professional status colors.
- Mobile-first layout.

## Spacing

Use an 8px rhythm:

- 4px micro gap
- 8px small gap
- 12px compact card inner gap
- 16px normal card padding
- 24px section gap
- 32px large section gap

## Radius

Recommended:

- small elements: 8px
- badges/buttons: 8–10px
- cards: 12–16px
- modal panels: 16px

## Shadows

Use restrained shadows:

- default card: subtle
- hover card: slightly elevated
- modals: stronger but soft

Avoid heavy black shadows.

## Color System

Use semantic tones:

- success: green
- warning: amber/orange
- critical: red
- info: blue
- neutral: gray/slate

Use Medusa tokens where possible.

## Typography

- strong metric value
- small muted labels
- descriptive secondary text
- consistent title sizing

Avoid oversized text that breaks Medusa admin density.

## Cards

Metric card requirements:

- icon container
- label
- value
- secondary detail
- optional trend
- optional progress
- responsive grid

Cards should look premium but not detached from Medusa.

## Tables

Tables must be clean:

- compact rows
- clear status badges
- hover state
- aligned numeric values
- no excessive borders
- readable empty states

## Modals

Modal design:

- clear title
- short description
- strong primary action
- soft destructive action styling
- keyboard-friendly
- no custom modal if Medusa component exists

## Charts

Charts must use real data or production-like data from actual plugin state.

Charts should be:

- readable
- minimal
- responsive
- label-safe
- compatible with admin dark/light modes if possible

## Icons

Icons should communicate meaning, not decoration.

Use a central icon policy/layer.

Do not pass unsupported props to icon components.


---

# 06_Component_Standards.md

## Metric Components

Single source of truth should be under:

`src/ui/components/metric`

Avoid duplicate root-level metric card definitions unless legacy compatibility requires them.

If duplicate files exist, do not delete immediately while build is broken. First map imports.

## Dashboard Components

`DashboardCards.tsx` must not assume vendor exports exist.

Before importing anything from `ui/vendor`, confirm the export path.

## Status Adapter

`src/ui/adapters/status.ts` must not use a hand-written icon type that conflicts with the actual icon library.

If using Medusa icons, type against their actual component type or use `React.ComponentType` with compatible SVG props.

Do not assume Lucide types unless using `lucide-react`.

## Charts

Chart components must import from the project’s chart vendor module only.

Before adding chart types, confirm `vendor/charts.ts` exports them.

## Class Utilities

If `clsx` is used:

- it must be installed,
- declared in package.json,
- exported from vendor if project uses vendor-first policy.

Optional future improvement after green build:
- introduce a `cn()` utility only with user approval.


---

# 07_Codex_Checklist.md

Before editing:

- [ ] Read `PROJECT.md`
- [ ] Read `00_Project_Rules.md`
- [ ] Run build
- [ ] Capture first real error
- [ ] Inspect package.json
- [ ] Inspect vendor exports
- [ ] Confirm if app is broken or green

During editing:

- [ ] Modify the minimum number of files
- [ ] Do not add files while build is broken
- [ ] Do not invent exports
- [ ] Do not introduce uninstalled packages
- [ ] Keep existing architecture intact
- [ ] Run build after each step

Before final response:

- [ ] Build result reported
- [ ] Files changed listed
- [ ] Remaining errors listed, if any
- [ ] Next exact command provided


---

# 08_Acceptance_Criteria.md

## Recovery Acceptance

- `npm run build` succeeds in plugin root.
- Backend admin no longer fails resolving plugin admin entry.
- No TypeScript import/export errors remain.
- No fake placeholders introduced.

## UI Acceptance

- Dashboard remains compatible with Medusa admin.
- Cards, tables, charts, modals, icons, and badges share one visual system.
- UI is premium and refined, not generic.
- No dependency is used without being installed and declared.
- No direct dependency chaos in feature components.
- Responsive behavior is preserved.
- Mobile layout remains premium, not merely stacked.

## Code Acceptance

- Imports are stable.
- Vendor layer is truthful.
- Components are reusable.
- No duplicate component definitions unless intentionally preserved.
- Build passes after every stage.


---

# 09_Command_Reference.md

## Plugin root

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
```

## Build plugin

```bash
npm run build
```

## Install clsx if approved

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm install clsx
```

## Backend root

```bash
cd C:\Users\H.M\my-medusa-store\apps\backend
```

## Clear backend Medusa cache

```bash
rmdir /s /q .medusa
```

## Kill locked node processes on Windows

```bash
taskkill /F /IM node.exe
```

## Restart TypeScript server in VS Code

Open command palette:

```txt
Ctrl + Shift + P
```

Run:

```txt
TypeScript: Restart TS Server
```


---

# 10_Codex_Work_Order_Template.md

Use this prompt inside Codex:

---

You are working on the Medusa plugin `medusa-premium-recovery`.

Before editing, read:

1. `PROJECT.md`
2. `00_Project_Rules.md`
3. `03_Recovery_Workflow.md`
4. `07_Codex_Checklist.md`

Current goal:

Recover the plugin build first. Do not redesign UI until build is green.

Rules:

- Do not create new files while build is broken.
- Do not add fake exports.
- Do not assume installed packages.
- Inspect package.json and vendor exports first.
- Fix only the current build errors.
- Run `npm run build` after changes.
- Report exactly which files changed.

After build is green, ask before starting visual polish.


---

