# PROJECT.md — Codex Entry Point

## Project Context

Project: `medusa-premium-recovery`  
Host workspace: `C:\Users\H.M\my-medusa-store`  
Plugin path: `apps\medusa-premium-recovery`  
Backend path: `apps\backend`

The user wants a premium Medusa-compatible admin dashboard for the Premium Recovery plugin.

The target is not merely a prettier UI. The target is:

- Medusa-compatible admin UI.
- Real dependency usage.
- No fake imports.
- No placeholder components.
- Build-safe incremental development.
- A visually premium dashboard with a distinct plugin signature.
- Tables, cards, modals, charts, badges, icons, and states must share one design language.

## Current Priority

If the project does not build, stop all redesign work.

Current workflow priority:

1. Recover build.
2. Audit dependencies.
3. Stabilize vendor layer.
4. Stabilize existing UI files.
5. Only then improve visual design.

## Non-Negotiable User Preference

The user does not want speculative files or random architectural additions while the app is broken.

Do not create new files unless:
- the build is already green, or
- the user explicitly approves the new file, or
- the new file is part of the agreed design-system stage.

## Important Past Failure

Previous attempts introduced mismatches such as:
- importing `clsx` from vendor before confirming it exists.
- using `lucide-react` assumptions while the plugin had `@medusajs/icons`.
- adding exports that did not exist in vendor submodules.
- modifying UI before build recovery.

Do not repeat these mistakes.
