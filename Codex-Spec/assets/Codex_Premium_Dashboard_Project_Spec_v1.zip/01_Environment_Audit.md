# 01_Environment_Audit.md

Before edits, Codex must gather facts.

## Commands

Run from plugin root:

```bash
cd C:\Users\H.M\my-medusa-store\apps\medusa-premium-recovery
npm pkg get name version dependencies devDependencies peerDependencies
npm run build
```

Run from workspace root if needed:

```bash
cd C:\Users\H.M\my-medusa-store
npm ls @medusajs/ui @medusajs/icons clsx recharts lucide-react @mantine/core
```

## Audit Targets

Check whether these packages are installed and where they are declared:

- `@medusajs/ui`
- `@medusajs/icons`
- `clsx`
- `recharts`
- `lucide-react`
- `@mantine/core`
- `react`
- `react-dom`

## Output Required Before Editing

Codex should produce a short audit summary:

- installed packages
- missing packages
- vendor files and their current exports
- broken import lines
- exact build errors
- safest recovery plan

Do not edit until this audit is complete.
