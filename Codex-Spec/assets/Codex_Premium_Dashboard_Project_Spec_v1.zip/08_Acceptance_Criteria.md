# 08_Acceptance_Criteria.md

## Recovery Acceptance

- `npm run build` succeeds in plugin root.
- Backend admin no longer fails resolving plugin admin entry.
- No TypeScript import/export errors remain.
- No fake placeholders introduced.

## UI Acceptance

- Dashboard remains compatible with Medusa admin.
- Cards, tables, charts, modals, icons, and badges share one visual system.
- UI is premium and refined, not generic.
- No dependency is used without being installed and declared.
- No direct dependency chaos in feature components.
- Responsive behavior is preserved.
- Mobile layout remains premium, not merely stacked.

## Code Acceptance

- Imports are stable.
- Vendor layer is truthful.
- Components are reusable.
- No duplicate component definitions unless intentionally preserved.
- Build passes after every stage.
