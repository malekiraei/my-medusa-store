# 04_Incremental_Rewrite_Plan.md

All future work must follow this order.

## Phase 0 — Audit

No code changes.

- package audit
- vendor export audit
- component import audit
- duplicate file audit
- build status

## Phase 1 — Build Stabilization

Only fix build errors.

No visual polish.

## Phase 2 — Vendor Normalization

Make vendor exports real and consistent.

No feature redesign.

## Phase 3 — Primitive Components

Stabilize low-level primitives:

- card surfaces
- badges
- buttons
- typography wrappers
- icon wrappers
- progress indicators

## Phase 4 — Composite Components

Stabilize:

- metric cards
- metric grids
- trend components
- chart cards
- table cards
- modal containers

## Phase 5 — Feature Components

Improve actual dashboard views:

- `page.tsx`
- `DashboardCards.tsx`
- dashboard components
- operations list
- system health views

## Phase 6 — Visual Polish

Only after build is green.

Apply premium visual layer.

## Phase 7 — Final QA

Run build and inspect UI manually in Medusa admin.
