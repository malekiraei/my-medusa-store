# 02_Dependency_And_Vendor_Policy.md

## Vendor Layer Purpose

`src/ui/vendor/*` is a compatibility boundary.

It must re-export real installed package symbols only.

It must not contain fake objects, placeholder components, or invented aliases unless the alias points to a real installed export.

## Recommended Structure

Existing vendor index should remain simple:

```ts
export * from "./medusa"
export * from "./lucide"
export * from "./charts"
export * from "./mantine"
```

If `clsx` is installed and package.json includes it, this is acceptable:

```ts
export { default as clsx } from "clsx"
```

Only add this after dependency audit confirms `clsx` exists.

## Important Package Notes

### clsx

Use case:
- conditional className composition
- metric card variants
- status badge variants
- table row states
- modal open/disabled states
- responsive grid classes

Allowed usage:
- through vendor export, if project policy requires all UI dependencies to pass through vendor.

### Icons

The project may use official Medusa icons:

```ts
@medusajs/icons
```

Additional icon libraries may be used only if:
- installed,
- declared in package.json,
- wrapped through an existing vendor/icon abstraction,
- type compatibility is confirmed.

### Charts

Charts must use real installed chart library exports.

Do not import `PieChart`, `Pie`, or `Cell` unless `src/ui/vendor/charts.ts` actually exports them from an installed library.

### Mantine

Do not use Mantine symbols unless `@mantine/core` is installed and vendor/mantine exports them.

Do not invent aliases like `MantineBadge` unless the alias is explicitly exported in `vendor/mantine.ts`.
