import { useMemo } from "react"

import {
  resolvePRStatus,
  type PRMetricTone,
  type PRSystemStatus,
} from "../../../../ui/adapters/status"
import { Cell, Pie, PieChart, ResponsiveContainer } from "../../../../ui/vendor"
import { Container, Text, clsx } from "../../../../ui/vendor"

type RecoveryOverviewProps = {
  status?: PRSystemStatus
  changedFiles?: number | null
  restorePoints?: number | null
  bundles?: number | null
  gitAvailable?: boolean
  gitClean?: boolean
}

type OverviewSegment = {
  name: string
  value: 1
  tone: PRMetricTone
  color: "green" | "orange" | "red" | "purple" | "neutral"
  detail: string
  isKnown: boolean
}

const colorFill: Record<OverviewSegment["color"], string> = {
  green: "#10b981",
  orange: "#f59e0b",
  red: "#f43f5e",
  purple: "#8b5cf6",
  neutral: "#94a3b8",
}

const colorClasses: Record<OverviewSegment["color"], {
  dot: string
  text: string
}> = {
  green: {
    dot: "bg-emerald-500",
    text: "text-emerald-700 dark:text-emerald-300",
  },
  orange: {
    dot: "bg-amber-500",
    text: "text-amber-700 dark:text-amber-300",
  },
  red: {
    dot: "bg-rose-500",
    text: "text-rose-700 dark:text-rose-300",
  },
  purple: {
    dot: "bg-violet-500",
    text: "text-violet-700 dark:text-violet-300",
  },
  neutral: {
    dot: "bg-slate-400",
    text: "text-ui-fg-muted",
  },
}

const getGitSegment = (
  gitAvailable?: boolean,
  gitClean?: boolean
): OverviewSegment => {
  if (typeof gitAvailable !== "boolean") {
    return {
      name: "Git State",
      value: 1,
      tone: "neutral",
      color: "neutral",
      detail: "Unknown",
      isKnown: false,
    }
  }

  if (!gitAvailable) {
    return {
      name: "Git State",
      value: 1,
      tone: "error",
      color: "red",
      detail: "Unavailable",
      isKnown: true,
    }
  }

  if (typeof gitClean !== "boolean") {
    return {
      name: "Git State",
      value: 1,
      tone: "neutral",
      color: "neutral",
      detail: "Unknown",
      isKnown: false,
    }
  }

  return {
    name: "Git State",
    value: 1,
    tone: gitClean ? "success" : "warning",
    color: gitClean ? "green" : "orange",
    detail: gitClean ? "Clean" : "Changes detected",
    isKnown: true,
  }
}

const getCountSegment = (
  name: string,
  count: number | null | undefined,
  emptyLabel: string,
  emptyTone: PRMetricTone,
  emptyColor: OverviewSegment["color"],
  activeLabel: (count: number) => string,
  activeTone: PRMetricTone,
  activeColor: OverviewSegment["color"]
): OverviewSegment => {
  if (typeof count !== "number") {
    return {
      name,
      value: 1,
      tone: "neutral",
      color: "neutral",
      detail: "Unknown",
      isKnown: false,
    }
  }

  return {
    name,
    value: 1,
    tone: count > 0 ? activeTone : emptyTone,
    color: count > 0 ? activeColor : emptyColor,
    detail: count > 0 ? activeLabel(count) : emptyLabel,
    isKnown: true,
  }
}

export const RecoveryOverview = ({
  status = "unknown",
  changedFiles,
  restorePoints,
  bundles,
  gitAvailable,
  gitClean,
}: RecoveryOverviewProps) => {
  const descriptor = resolvePRStatus(status)

  const segments = useMemo<OverviewSegment[]>(() => {
    const protectionKnown = String(status).toLowerCase() !== "unknown"

    return [
      {
        name: "Protection",
        value: 1,
        tone: descriptor.tone,
        color: protectionKnown ? "red" : "neutral",
        detail: protectionKnown ? descriptor.label : "Unknown",
        isKnown: protectionKnown,
      },
      getGitSegment(gitAvailable, gitClean),
      getCountSegment(
        "Changes",
        changedFiles,
        "No changed files",
        "success",
        "green",
        (count) => `${count} changed`,
        "warning",
        "orange"
      ),
      getCountSegment(
        "Restore Points",
        restorePoints,
        "None available",
        "neutral",
        "orange",
        (count) => `${count} available`,
        "info",
        "orange"
      ),
      getCountSegment(
        "Bundles",
        bundles,
        "None available",
        "neutral",
        "neutral",
        (count) => `${count} available`,
        "info",
        "purple"
      ),
    ]
  }, [bundles, changedFiles, descriptor.label, descriptor.tone, gitAvailable, gitClean, restorePoints, status])

  const hasKnownSegment = segments.some((segment) => segment.isKnown)

  return (
    <Container className="w-full overflow-hidden rounded-xl border border-ui-border-base bg-ui-bg-base p-0 shadow-[0_10px_30px_-26px_rgba(15,23,42,0.35)]">
      <div className="p-4 sm:p-5">
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] lg:items-center lg:gap-4 rtl:lg:[&>*:first-child]:order-2">
          <div className="min-w-0">
            <div className="relative h-32 min-w-0 sm:h-36">
              <div className="absolute inset-x-14 bottom-4 h-6 rounded-full bg-ui-bg-subtle blur-xl" />
              <div
                aria-hidden="true"
                className="pointer-events-none h-[calc(100%+16px)] outline-none [&_*]:outline-none"
                tabIndex={-1}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={segments}
                      dataKey="value"
                      nameKey="name"
                      startAngle={180}
                      endAngle={0}
                      cy="88%"
                      innerRadius={92}
                      outerRadius={136}
                      paddingAngle={2}
                      stroke="none"
                      isAnimationActive={false}
                      rootTabIndex={-1}
                    >
                      {segments.map((segment) => (
                        <Cell
                          key={segment.name}
                          fill={colorFill[segment.color]}
                          opacity={segment.isKnown ? 0.92 : 0.3}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="pointer-events-none absolute inset-x-0 -bottom-3 flex flex-col items-center text-center">
                <Text className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ui-fg-muted">
                  Current Status
                </Text>
                <div className="mt-0.5 text-xl font-semibold leading-none tracking-tight text-ui-fg-base">
                  {descriptor.label}
                </div>
              </div>
            </div>
          </div>

          <div className="min-w-0 pt-2 text-start">
            <div className="mb-3">
              <Text className="text-base font-semibold leading-5 tracking-tight text-ui-fg-base">
                Recovery Overview
              </Text>
              <Text className="mt-1 text-xs leading-4 text-ui-fg-muted">
                Operational status dimensions from current recovery data.
              </Text>
            </div>

            {!hasKnownSegment ? (
              <Text className="mb-3 text-sm leading-5 text-ui-fg-muted">
                Overview unavailable until system status resolves.
              </Text>
            ) : null}

            <div className="grid grid-cols-[minmax(7.5rem,max-content)_8rem_max-content] items-center gap-x-2 gap-y-1.5">
              {segments.map((segment) => (
                <div
                  key={segment.name}
                  className="contents"
                >
                  <div className="flex min-w-0 shrink-0 items-center gap-1.5">
                    <span
                      className={clsx(
                        "size-2.5 shrink-0 rounded-full",
                        colorClasses[segment.color].dot,
                        segment.isKnown ? "" : "opacity-45"
                      )}
                    />
                    <Text className="shrink-0 text-xs font-medium text-ui-fg-base">
                      {segment.name}
                    </Text>
                  </div>
                  <span className="min-w-0 border-b border-dotted border-ui-border-base/30" />
                  <Text
                    className={clsx(
                      "min-w-0 text-end text-xs font-medium",
                      segment.isKnown ? colorClasses[segment.color].text : "text-ui-fg-muted"
                    )}
                  >
                    {segment.detail}
                  </Text>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Container>
  )
}

export default RecoveryOverview
