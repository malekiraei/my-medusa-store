// ============================================================
// ReviewView - UNIFIED VIEW
// ✅ Same header pattern as other views
// ✅ Same padding system
// ✅ Same density
// ============================================================

import React from "react"
import { ViewHeader } from "./ViewHeader"

export type SnapshotUseCase = "manual" | "before_update" | "before_theme_change" | "before_plugin_install"

export type ReviewViewProps = {
  snapshotName: string
  snapshotDescription: string
  snapshotBusinessContext: string
  snapshotUseCase: SnapshotUseCase
  selectedCount: number
}

const useCaseLabels: Record<SnapshotUseCase, string> = {
  manual: "دستی (عمومی)",
  before_update: "به‌روزرسانی محصول",
  before_theme_change: "تغییر قالب",
  before_plugin_install: "نصب افزونه",
}

export const ReviewView: React.FC<ReviewViewProps> = ({
  snapshotName,
  snapshotDescription,
  snapshotBusinessContext,
  snapshotUseCase,
  selectedCount,
}) => {
  return (
    <div className="flex flex-col h-full">
      {/* ===== Unified Header ===== */}
      <ViewHeader
        icon={
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        }
        iconColor="#10b981"
        title="بررسی نهایی"
        subtitle={`${selectedCount} فایل برای اسنپ‌شات`}
      />

      {/* ===== Content ===== */}
      <div className="flex-1 overflow-y-auto py-3">
        {/* Details Card */}
        <div className="bg-gray-50/60 dark:bg-gray-800/30 rounded-xl px-4 py-3 space-y-2.5">
          <div className="flex justify-between items-center text-[13px]">
            <span className="text-gray-500 dark:text-gray-400">نام</span>
            <span className="font-medium text-gray-800 dark:text-gray-200">
              {snapshotName || '—'}
            </span>
          </div>

          <div className="flex justify-between items-center text-[13px]">
            <span className="text-gray-500 dark:text-gray-400">زمینه کاری</span>
            <span className="text-gray-700 dark:text-gray-300">
              {useCaseLabels[snapshotUseCase] || snapshotUseCase}
            </span>
          </div>

          {snapshotBusinessContext && (
            <div className="flex justify-between items-center text-[13px]">
              <span className="text-gray-500 dark:text-gray-400">زمینه کسب‌وکاری</span>
              <span className="text-gray-700 dark:text-gray-300 max-w-[180px] truncate" title={snapshotBusinessContext}>
                {snapshotBusinessContext}
              </span>
            </div>
          )}

          {snapshotDescription && (
            <div className="flex justify-between items-center text-[13px]">
              <span className="text-gray-500 dark:text-gray-400">توضیحات</span>
              <span className="text-gray-700 dark:text-gray-300 max-w-[180px] truncate" title={snapshotDescription}>
                {snapshotDescription}
              </span>
            </div>
          )}

          <div className="flex justify-between items-center text-[13px] pt-2.5 border-t border-gray-200/60 dark:border-gray-700/50">
            <span className="text-gray-500 dark:text-gray-400">تعداد فایل‌ها</span>
            <span className="font-bold text-indigo-600 dark:text-indigo-400 text-[15px]">
              {selectedCount}
            </span>
          </div>
        </div>

        {/* Confirmation */}
        <div className="mt-4 flex items-center gap-2.5 p-3 rounded-lg bg-emerald-50/40 dark:bg-emerald-950/10 border border-emerald-200/40 dark:border-emerald-800/30">
          <svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-[12px] text-emerald-600 dark:text-emerald-400">
            برای ایجاد اسنپ‌شات کلیک کنید
          </p>
        </div>
      </div>
    </div>
  )
}

export default ReviewView