// ============================================================
// ViewHeader - UNIFIED HEADER FOR ALL VIEWS
// ✅ Same layout, same spacing, same density
// ✅ Only icon color + title changes per view
// ============================================================

import React from "react"

export type ViewHeaderProps = {
  icon: React.ReactNode
  iconColor: string
  title: string
  subtitle: string
}

export const ViewHeader: React.FC<ViewHeaderProps> = ({
  icon,
  iconColor,
  title,
  subtitle,
}) => {
  return (
    <div className="pb-4 border-b border-gray-200/60 dark:border-gray-800/60">
      <div className="flex items-center gap-3">
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${iconColor}15` }}
        >
          <div style={{ color: iconColor }}>{icon}</div>
        </div>
        <div>
          <h3 className="text-[13px] font-semibold text-gray-800 dark:text-gray-100">
            {title}
          </h3>
          <p className="text-[11px] text-gray-500 dark:text-gray-400">
            {subtitle}
          </p>
        </div>
      </div>
    </div>
  )
}

export default ViewHeader