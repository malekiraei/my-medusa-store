// src/admin/routes/premium-recovery/services/git.service.ts
// ============================================================
// Git Service - FIXED
// ✅ endpoint صحیح: /admin/premium-recovery/git-changes
// ✅ response mapping صحیح
// ============================================================

import type { SnapshotFile } from "../types/snapshot-workflow"

export type GitServiceResult = {
  files: SnapshotFile[]
  error?: string
}

// ============================================================
// ✅ fetchGitFiles - با endpoint صحیح
// ============================================================
async function fetchGitFiles(signal?: AbortSignal): Promise<SnapshotFile[]> {
  // ✅ FIX: endpoint صحیح
  const response = await fetch("/admin/premium-recovery/git-changes", {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    signal,
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    throw new Error(errorData?.error || "خطا در دریافت فایل‌ها")
  }

  const data = await response.json()

  // ✅ بررسی ساختار response
  console.log("📡 Git API Response:", data)

  // ✅ mapping صحیح برای git-changes
  const rawChanges =
    data?.changes ??
    data?.data?.changes ??
    data?.files ??
    []

  if (!Array.isArray(rawChanges) || rawChanges.length === 0) {
    console.warn("⚠️ No changes found in git response")
    return []
  }

  const files = rawChanges
    .map((c: any) => ({
      path: c.path || c.filePath || "",
      status: c.status || c.type || "modified",
      oldPath: c.oldPath || "",
      business_impact: c.business_impact || "normal",
    }))
    .filter((f: SnapshotFile) => f.path.trim().length > 0)

  console.log(`✅ ${files.length} files normalized from git`)
  return files
}

// ============================================================
// ✅ fetchGitFilesWithRetry - با retry logic
// ============================================================
export async function fetchGitFilesWithRetry(
  maxRetries: number = 2,
  signal?: AbortSignal
): Promise<GitServiceResult> {
  let lastError: Error | null = null

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const files = await fetchGitFiles(signal)
      return { files }
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error))
      
      if (signal?.aborted) {
        return { files: [], error: "درخواست لغو شد" }
      }
      
      if (attempt === maxRetries) break
      
      // Exponential backoff
      await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1)))
    }
  }

  return {
    files: [],
    error: lastError?.message || "خطا در دریافت فایل‌ها",
  }
}
