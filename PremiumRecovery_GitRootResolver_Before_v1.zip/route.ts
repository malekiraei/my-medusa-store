import { execFile } from "node:child_process"
import { promisify } from "node:util"

import { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"

const execFileAsync = promisify(execFile)

const runGit = async (args: string[]) => {
  const { stdout } = await execFileAsync("git", args, {
    cwd: process.cwd(),
    windowsHide: true,
  })

  return String(stdout).trim()
}

const getGitStatus = async () => {
  try {
    await runGit(["rev-parse", "--is-inside-work-tree"])

    const [branch, porcelain] = await Promise.all([
      runGit(["branch", "--show-current"]).catch(() => "unknown"),
      runGit(["status", "--porcelain"]),
    ])

    const changes = porcelain
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)

    return {
      available: true,
      branch: branch || "unknown",
      clean: changes.length === 0,
      changedFilesCount: changes.length,
    }
  } catch {
    return {
      available: false,
      branch: "unknown",
      clean: false,
      changedFilesCount: 0,
    }
  }
}

export async function GET(
  req: MedusaRequest,
  res: MedusaResponse
) {
  const git = await getGitStatus()
  const level = git.available && git.clean ? "unprotected" : "unprotected"
  const message = git.available
    ? git.clean
      ? "Git is available and clean, but no recovery persistence is configured."
      : "Git has uncommitted changes and no recovery persistence is configured."
    : "Git status is unavailable and no recovery persistence is configured."

  res.json({
    protection: {
      level,
      message,
      safety_active: false,
    },
    git: {
      available: git.available,
      clean: git.clean,
      branch: git.branch,
    },
    recovery: {
      latest_snapshot: null,
      bundle_count: 0,
      changed_files_count: git.changedFilesCount,
      last_successful_restore: null,
    },
  })
}
