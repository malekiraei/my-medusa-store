import React from "react"

type FileItem = {
  path: string
  name: string
  status?: "modified" | "added" | "deleted"
}

type Props = {
  files?: FileItem[] | null
  selectedFiles?: string[] | null
  error?: string | null
  onToggleFile?: (path: string) => void
  onSelectAll?: () => void
  isAllSelected?: boolean
}

export default function SelectingView({
  files = [],
  selectedFiles = [],
  error = null,
  onToggleFile = () => {},
  onSelectAll = () => {},
  isAllSelected = false,
}: Props) {
  // Safe access for optional props.
  const safeFiles = Array.isArray(files) ? files : []
  const safeSelected = Array.isArray(selectedFiles) ? selectedFiles : []
  const fileCount = safeFiles.length
  const selectedCount = safeSelected.length

  const truncatePath = (path: string, maxLength: number = 35): string => {
    if (!path) return ""
    if (path.length <= maxLength) return path
    const parts = path.split("/")
    if (parts.length <= 2) return path.substring(0, maxLength) + "..."
    return ".../" + parts.slice(-2).join("/")
  }

  const getFileIcon = (path: string): string => {
    if (!path) return "📄"
    const ext = path.split(".").pop()?.toLowerCase() || ""
    const icons: Record<string, string> = {
      ts: "📘",
      tsx: "⚛️",
      js: "📜",
      jsx: "⚛️",
      css: "🎨",
      scss: "🎨",
      json: "📋",
      md: "📝",
      html: "🌐",
      xml: "📄",
      yaml: "📄",
      lock: "🔒",
      gitignore: "👁️",
      env: "🔐",
      png: "🖼️",
      jpg: "🖼️",
      svg: "🖼️",
      pdf: "📄",
      doc: "📄",
      zip: "📦",
    }
    return icons[ext] || "📄"
  }

  const getStatusColor = (status?: string) => {
    switch (status) {
      case "added":
        return "text-emerald-600 dark:text-emerald-400"
      case "modified":
        return "text-amber-600 dark:text-amber-400"
      case "deleted":
        return "text-rose-600 dark:text-rose-400"
      default:
        return "text-gray-400 dark:text-gray-500"
    }
  }

  const getStatusLabel = (status?: string): string => {
    switch (status) {
      case "added":
        return "افزوده شده"
      case "modified":
        return "تغییر یافته"
      case "deleted":
        return "حذف شده"
      default:
        return ""
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="pb-4 border-b border-gray-200/60 dark:border-gray-800/60">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-950/30 flex items-center justify-center flex-shrink-0">
            <svg className="w-4 h-4 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
            </svg>
          </div>
          <div>
            <h3 className="text-[13px] font-semibold text-gray-800 dark:text-gray-100">
              انتخاب فایل‌ها
            </h3>
            <p className="text-[11px] text-gray-500 dark:text-gray-400">
              {fileCount} فایل · {selectedCount} انتخاب شده
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-3 space-y-1">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-50/50 dark:hover:bg-gray-800/20 cursor-pointer transition-colors duration-150">
          <button
            onClick={onSelectAll}
            className="relative w-4 h-4 rounded-full border-2 transition-all duration-200 flex items-center justify-center flex-shrink-0"
            style={{
              background: isAllSelected ? "#6366f1" : "transparent",
              borderColor: isAllSelected ? "#6366f1" : "#d4d4d4",
            }}
          >
            {isAllSelected && (
              <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            )}
          </button>
          <span className="text-[13px] text-gray-600 dark:text-gray-300 font-body">
            انتخاب همه
          </span>
        </div>

        {fileCount === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-center">
            <span className="text-3xl mb-2">📂</span>
            <p className="text-gray-500 dark:text-gray-400 font-body text-sm">
              فایل تغییریافته‌ای یافت نشد
            </p>
          </div>
        ) : (
          safeFiles.map((file) => {
            const isSelected = safeSelected.includes(file.path)
            return (
              <div
                key={file.path}
                className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-indigo-50/30 dark:hover:bg-indigo-950/15 cursor-pointer transition-all duration-150"
                onClick={() => onToggleFile(file.path)}
              >
                <button
                  className="relative w-4 h-4 rounded-full border-2 transition-all duration-200 flex items-center justify-center flex-shrink-0"
                  style={{
                    background: isSelected ? "#6366f1" : "transparent",
                    borderColor: isSelected ? "#6366f1" : "#d4d4d4",
                  }}
                  onClick={(e) => {
                    e.stopPropagation()
                    onToggleFile(file.path)
                  }}
                >
                  {isSelected && (
                    <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </button>

                <span className="text-base leading-none flex-shrink-0 opacity-70">
                  {getFileIcon(file.path)}
                </span>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] text-gray-800 dark:text-gray-200 font-body truncate">
                      {file.path.split("/").pop()}
                    </span>
                    {file.status && (
                      <span className={`text-[10px] ${getStatusColor(file.status)} font-body flex-shrink-0`}>
                        {getStatusLabel(file.status)}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-500 font-body truncate" title={file.path}>
                    {truncatePath(file.path)}
                  </div>
                </div>
              </div>
            )
          })
        )}
      </div>

      {error && (
        <div className="mt-2 p-3 bg-rose-50 dark:bg-rose-950/20 rounded-lg border border-rose-200 dark:border-rose-800">
          <p className="text-[13px] text-rose-600 dark:text-rose-400 font-body">
            ⚠️ {error}
          </p>
        </div>
      )}
    </div>
  )
}
