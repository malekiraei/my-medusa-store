export default function PremiumRecoveryPage() {
  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 8 }}>
      <h1 style={{ fontSize: 20, fontWeight: 600, margin: 0 }}>
        Premium Recovery
      </h1>

      <p style={{ margin: 0, color: "#666", fontSize: 14 }}>
        Plugin is active and connected to Medusa Admin.
      </p>
    </div>
  )
}