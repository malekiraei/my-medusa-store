// apps/premium-recovery-plugin/src/design-system/lock.ts
// ============================================================
// STRIPE DESIGN CONSTITUTION - LOCK FILE
// ✅ Single source of truth for ALL design decisions
// ✅ NO JSX, NO UI logic, NO resolver logic
// ✅ Only tokens, rules, and behavior contracts
// ============================================================

export const tokens = {
  colors: {
    indigo: {
      50: '#eef2ff',
      100: '#e0e7ff',
      200: '#c7d2fe',
      300: '#a5b4fc',
      400: '#818cf8',
      500: '#6366f1',
      600: '#4f46e5',
      700: '#4338ca',
      800: '#3730a3',
      900: '#312e81',
      950: '#1e1b4b',
    },
    emerald: {
      50: '#ecfdf5',
      100: '#d1fae5',
      200: '#a7f3d0',
      300: '#6ee7b7',
      400: '#34d399',
      500: '#10b981',
      600: '#059669',
      700: '#047857',
      800: '#065f46',
      900: '#064e3b',
      950: '#022c22',
    },
    rose: {
      50: '#fef2f2',
      100: '#fee2e2',
      200: '#fecaca',
      300: '#fca5a5',
      400: '#f87171',
      500: '#ef4444',
      600: '#dc2626',
      700: '#b91c1c',
      800: '#991b1b',
      900: '#7f1d1d',
      950: '#0f0f0f',
    },
    neutral: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#e5e5e5',
      300: '#d4d4d4',
      400: '#a3a3a3',
      500: '#737373',
      600: '#525252',
      700: '#404040',
      800: '#262626',
      900: '#171717',
      950: '#0a0a0a',
    },
  },
  radius: {
    sm: '6px',
    md: '8px',
    lg: '10px',
    xl: '12px',
    '2xl': '16px',
    '3xl': '20px',
    full: '9999px',
  },
  shadow: {
    none: 'none',
    soft: '0 4px 20px -8px rgba(0,0,0,0.04), 0 1px 3px -2px rgba(0,0,0,0.02)',
    card: '0 8px 30px -12px rgba(0,0,0,0.08), 0 2px 8px -4px rgba(0,0,0,0.02)',
    hover: '0 20px 50px -12px rgba(0,0,0,0.12), 0 4px 12px -4px rgba(0,0,0,0.04)',
    modal: '0 25px 60px -15px rgba(0,0,0,0.35)',
  },
  typography: {
    title: {
      size: '16px',
      weight: '600',
      lineHeight: '1.3',
      letterSpacing: '-0.01em',
    },
    label: {
      size: '13px',
      weight: '500',
      lineHeight: '1.4',
      letterSpacing: '0',
    },
    meta: {
      size: '11px',
      weight: '400',
      lineHeight: '1.5',
      letterSpacing: '0.05em',
      uppercase: true,
    },
  },
}

export const motion = {
  duration: {
    instant: '0ms',
    fast: '160ms',
    normal: '250ms',
    slow: '400ms',
  },
  easing: {
    default: 'cubic-bezier(0.4, 0, 0.2, 1)',
    spring: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    easeOut: 'cubic-bezier(0, 0, 0.2, 1)',
    easeInOut: 'cubic-bezier(0.4, 0, 0.6, 1)',
  },
  interaction: {
    hover: {
      translateY: '-2px',
      duration: '250ms',
      easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    },
    press: {
      scale: '0.98',
      duration: '160ms',
      easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    },
    enter: {
      opacity: [0, 1],
      transform: ['scale(0.98) translateY(6px)', 'scale(1) translateY(0)'],
      duration: '250ms',
      easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    },
    exit: {
      opacity: [1, 0],
      transform: ['scale(1) translateY(0)', 'scale(0.98) translateY(6px)'],
      duration: '160ms',
      easing: 'cubic-bezier(0.4, 0, 0.6, 1)',
    },
  },
}

export const layout = {
  scroll: {
    container: 'overflow-hidden h-screen',
    body: 'flex-1 overflow-y-auto min-h-0',
    header: 'flex-shrink-0',
    footer: 'flex-shrink-0',
  },
  container: {
    modal: 'h-[90vh] max-h-[90vh]',
    card: 'p-5 rounded-2xl',
    section: 'space-y-4',
  },
  spacing: {
    tight: 'gap-2',
    default: 'gap-3',
    section: 'gap-4',
    block: 'gap-6',
    major: 'gap-8',
  },
  grid: {
    cards: 'grid grid-cols-1 lg:grid-cols-3 gap-4',
    twoCol: 'grid grid-cols-1 lg:grid-cols-2 gap-4',
    list: 'space-y-2',
  },
}

export const design = {
  tokens,
  motion,
  layout,
}