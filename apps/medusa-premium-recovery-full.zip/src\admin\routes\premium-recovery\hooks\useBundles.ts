import { useState, useEffect, useCallback } from "react"

export type BundleInfo = {
  id: string
  name: string
  description: string
  version: string
  status: string
  created_at: string
}

export const useBundles = () => {
  const [bundles, setBundles] = useState<BundleInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchBundles = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/admin/premium-recovery/bundles", { credentials: "include" })
      if (!res.ok) {
        setBundles([])
        return
      }
      const data = await res.json()
      setBundles(data?.bundles ?? [])
    } catch (e: any) {
      setError(e.message)
      setBundles([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchBundles()
  }, [fetchBundles])

  return { bundles, loading, error, refetch: fetchBundles }
}