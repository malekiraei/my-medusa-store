export type RestorePoint = {
  id: string
  name: string
  created_at: string
  human_date: string

  description?: string
  business_context?: string

  files_count: number

  bundle_available: boolean
  safety_verified: boolean

  recovery_risk: "low" | "medium" | "high"

  category: "today" | "yesterday" | "last_week" | "older"

  hash?: string
  author?: string

  insertions?: number
  deletions?: number

  use_case:
    | "before_update"
    | "before_theme_change"
    | "before_plugin_install"
    | "manual"
}

export type SystemStatus = {
  git: {
    available: boolean
    clean: boolean
    branch: string
    modified_files: number
  }

  protection: {
    level: "protected" | "partially_protected" | "unprotected"
    message: string
    safety_active: boolean
  }

  recovery: {
    last_successful_restore: string | null
    bundle_count: number
    latest_snapshot: string | null
    changed_files_count: number
  }
}

export type SystemStatusUI = {
  protection_level: "protected" | "partially_protected" | "unprotected"
  protection_message: string

  branch: string
  latest_snapshot: string | null

  bundle_count: number
  safety_active: boolean

  git_available: boolean
  is_clean: boolean

  last_successful_restore: string | null
  changed_files_count: number
}

export type BundleInfo = {
  id: string
  name: string
  created_at: string

  size: number

  verified: boolean
  portable: boolean

  commit_linked: boolean

  created_by?: string
  restore_ready: boolean
}

export type ActivityItem = {
  id: string
  message: string
  timestamp: string

  status: "success" | "pending" | "failed"
  business_impact?: "critical" | "normal" | "low"
}

export type ChangedFile = {
  path: string
  status: "modified" | "added" | "deleted"

  business_impact?: "critical" | "normal" | "low"
}

export type SnapshotFormData = {
  name: string
  description: string
  business_context: string

  use_case: RestorePoint["use_case"]
  files: string[]
}