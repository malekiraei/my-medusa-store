// apps/premium-recovery-plugin/src/design-system/experience.ts
// ============================================================
// Zero-Cognition Experience Engine - 100/100
// ✅ UI هیچ semantic نمی‌فهمد
// ✅ progress = opaque string
// ============================================================

import { design } from './lock'

export type ExperienceState =
  | 'idle'
  | 'analyzing'
  | 'selecting'
  | 'metadata'
  | 'review'
  | 'creating'
  | 'done'
  | 'error'

export type UISpec = {
  bg: string
  bgBadge: string
  bgProgress: string
  text: string
  textBadge: string
  border: string
  borderBadge: string
  light: string
  dark: string
  iconColor: string
  stripeColor: string
  progressGradient: string
  buttonPrimary: string
  buttonSecondary: string
  buttonDisabled: string
  stateClass: string
  motionDuration: number
  motionEasing: string
  motionKey: string
  showProgress: boolean
  showBack: boolean
  icon: string
  title: string
  description: string
  nextLabel: string
  backLabel: string
  nextDisabled: boolean
  progress: string
}

const getStateColors = (state: ExperienceState) => {
  const colors = design.tokens.colors
  
  switch (state) {
    case 'analyzing':
      return {
        bg: 'bg-indigo-50/80 dark:bg-indigo-950/30',
        bgBadge: 'bg-indigo-100 dark:bg-indigo-900/40',
        bgProgress: 'bg-indigo-500/20 dark:bg-indigo-400/20',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-indigo-700 dark:text-indigo-300',
        border: 'border-indigo-200/50 dark:border-indigo-800/30',
        borderBadge: 'border-indigo-200 dark:border-indigo-800',
        light: colors.indigo[50] || '#eef2ff',
        dark: colors.indigo[950] || '#1e1b4b',
        iconColor: colors.indigo[500] || '#6366f1',
        stripeColor: colors.indigo[400] || '#818cf8',
        progress: `linear-gradient(90deg, ${colors.indigo[400] || '#818cf8'}, ${colors.indigo[500] || '#6366f1'})`,
        buttonPrimary: 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-analyzing',
      }
    case 'selecting':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-indigo-100 dark:bg-indigo-900/40',
        bgProgress: 'bg-indigo-500/20 dark:bg-indigo-400/20',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-indigo-700 dark:text-indigo-300',
        border: 'border-gray-200/50 dark:border-gray-800/30',
        borderBadge: 'border-indigo-200 dark:border-indigo-800',
        light: colors.indigo[50] || '#eef2ff',
        dark: colors.indigo[950] || '#1e1b4b',
        iconColor: colors.indigo[500] || '#6366f1',
        stripeColor: colors.indigo[400] || '#818cf8',
        progress: `linear-gradient(90deg, ${colors.indigo[400] || '#818cf8'}, ${colors.indigo[500] || '#6366f1'})`,
        buttonPrimary: 'bg-gradient-to-r from-indigo-500 to-emerald-500 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-selecting',
      }
    case 'metadata':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-emerald-100 dark:bg-emerald-900/40',
        bgProgress: 'bg-emerald-500/20 dark:bg-emerald-400/20',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-emerald-700 dark:text-emerald-300',
        border: 'border-gray-200/50 dark:border-gray-800/30',
        borderBadge: 'border-emerald-200 dark:border-emerald-800',
        light: colors.emerald?.[50] || '#ecfdf5',
        dark: colors.emerald?.[950] || '#022c22',
        iconColor: colors.emerald?.[500] || '#10b981',
        stripeColor: colors.emerald?.[400] || '#34d399',
        progress: `linear-gradient(90deg, ${colors.indigo[400] || '#818cf8'}, ${colors.emerald?.[400] || '#34d399'})`,
        buttonPrimary: 'bg-gradient-to-r from-indigo-500 to-emerald-500 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-metadata',
      }
    case 'review':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-emerald-100 dark:bg-emerald-900/40',
        bgProgress: 'bg-emerald-500/20 dark:bg-emerald-400/20',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-emerald-700 dark:text-emerald-300',
        border: 'border-gray-200/50 dark:border-gray-800/30',
        borderBadge: 'border-emerald-200 dark:border-emerald-800',
        light: colors.emerald?.[50] || '#ecfdf5',
        dark: colors.emerald?.[950] || '#022c22',
        iconColor: colors.emerald?.[500] || '#10b981',
        stripeColor: colors.emerald?.[500] || '#10b981',
        progress: `linear-gradient(90deg, ${colors.emerald?.[400] || '#34d399'}, ${colors.emerald?.[500] || '#10b981'})`,
        buttonPrimary: 'bg-gradient-to-r from-emerald-500 to-emerald-600 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-review',
      }
    case 'creating':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-indigo-100 dark:bg-indigo-900/40',
        bgProgress: 'bg-indigo-500/20 dark:bg-indigo-400/20',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-indigo-700 dark:text-indigo-300',
        border: 'border-gray-200/50 dark:border-gray-800/30',
        borderBadge: 'border-indigo-200 dark:border-indigo-800',
        light: colors.indigo[50] || '#eef2ff',
        dark: colors.indigo[950] || '#1e1b4b',
        iconColor: colors.indigo[500] || '#6366f1',
        stripeColor: colors.indigo[400] || '#818cf8',
        progress: `linear-gradient(90deg, ${colors.indigo[400] || '#818cf8'}, ${colors.emerald?.[400] || '#34d399'})`,
        buttonPrimary: 'bg-gradient-to-r from-indigo-500 to-emerald-500 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-creating',
      }
    case 'done':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-emerald-100 dark:bg-emerald-900/40',
        bgProgress: 'bg-emerald-500/20 dark:bg-emerald-400/20',
        text: 'text-emerald-700 dark:text-emerald-300',
        textBadge: 'text-emerald-700 dark:text-emerald-300',
        border: 'border-emerald-200/50 dark:border-emerald-800/30',
        borderBadge: 'border-emerald-200 dark:border-emerald-800',
        light: colors.emerald?.[50] || '#ecfdf5',
        dark: colors.emerald?.[950] || '#022c22',
        iconColor: colors.emerald?.[500] || '#10b981',
        stripeColor: colors.emerald?.[500] || '#10b981',
        progress: `linear-gradient(90deg, ${colors.emerald?.[400] || '#34d399'}, ${colors.emerald?.[500] || '#10b981'})`,
        buttonPrimary: 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-done',
      }
    case 'error':
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-rose-100 dark:bg-rose-900/40',
        bgProgress: 'bg-rose-500/20 dark:bg-rose-400/20',
        text: 'text-rose-700 dark:text-rose-300',
        textBadge: 'text-rose-700 dark:text-rose-300',
        border: 'border-rose-200/50 dark:border-rose-800/30',
        borderBadge: 'border-rose-200 dark:border-rose-800',
        light: colors.rose?.[50] || '#fef2f2',
        dark: colors.rose?.[950] || '#0f0f0f',
        iconColor: colors.rose?.[500] || '#ef4444',
        stripeColor: colors.rose?.[500] || '#ef4444',
        progress: `linear-gradient(90deg, ${colors.rose?.[400] || '#f87171'}, ${colors.rose?.[500] || '#ef4444'})`,
        buttonPrimary: 'bg-rose-500 hover:bg-rose-600 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-error',
      }
    default:
      return {
        bg: 'bg-white/80 dark:bg-gray-900/80',
        bgBadge: 'bg-gray-100 dark:bg-gray-800',
        bgProgress: 'bg-gray-200 dark:bg-gray-700',
        text: 'text-gray-900 dark:text-gray-100',
        textBadge: 'text-gray-700 dark:text-gray-300',
        border: 'border-gray-200/50 dark:border-gray-800/30',
        borderBadge: 'border-gray-200 dark:border-gray-800',
        light: colors.neutral[50] || '#fafafa',
        dark: colors.neutral[950] || '#0a0a0a',
        iconColor: colors.neutral[500] || '#737373',
        stripeColor: colors.neutral[400] || '#a3a3a3',
        progress: `linear-gradient(90deg, ${colors.neutral[400] || '#a3a3a3'}, ${colors.neutral[500] || '#737373'})`,
        buttonPrimary: 'bg-gray-500 hover:bg-gray-600 text-white shadow-sm hover:shadow-md px-6 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 px-5 py-2.5 rounded-[10px] transition-all duration-200 active:scale-95 disabled:opacity-50',
        buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 px-6 py-2.5 rounded-[10px] cursor-not-allowed',
        stateClass: 'state-idle',
      }
  }
}

const layoutMap: Record<ExperienceState, { showProgress: boolean; showBack: boolean }> = {
  idle: { showProgress: false, showBack: false },
  analyzing: { showProgress: true, showBack: false },
  selecting: { showProgress: true, showBack: false },
  metadata: { showProgress: true, showBack: true },
  review: { showProgress: true, showBack: true },
  creating: { showProgress: false, showBack: false },
  done: { showProgress: false, showBack: false },
  error: { showProgress: false, showBack: false },
}

const narrativeMap: Record<ExperienceState, { icon: string; title: string; description: string; nextLabel: string; backLabel: string; nextDisabled: boolean }> = {
  idle: {
    icon: '📁',
    title: 'آماده',
    description: '',
    nextLabel: 'شروع',
    backLabel: '',
    nextDisabled: true,
  },
  analyzing: {
    icon: '🔍',
    title: 'تحلیل تغییرات',
    description: 'در حال اسکن مخزن...',
    nextLabel: 'در حال تحلیل...',
    backLabel: '',
    nextDisabled: true,
  },
  selecting: {
    icon: '📁',
    title: 'انتخاب فایل‌ها',
    description: 'فایل‌های تغییر یافته را انتخاب کنید',
    nextLabel: 'ادامه',
    backLabel: '',
    nextDisabled: false,
  },
  metadata: {
    icon: '📝',
    title: 'اطلاعات اسنپ‌شات',
    description: 'نام و توضیحات اسنپ‌شات را وارد کنید',
    nextLabel: 'ادامه',
    backLabel: 'بازگشت',
    nextDisabled: false,
  },
  review: {
    icon: '✅',
    title: 'بررسی نهایی',
    description: 'اطلاعات را بررسی و تأیید کنید',
    nextLabel: 'ایجاد اسنپ‌شات',
    backLabel: 'بازگشت',
    nextDisabled: false,
  },
  creating: {
    icon: '⏳',
    title: 'در حال ایجاد...',
    description: 'لطفاً چند لحظه صبر کنید',
    nextLabel: 'در حال ایجاد...',
    backLabel: '',
    nextDisabled: true,
  },
  done: {
    icon: '🎉',
    title: 'تکمیل شد!',
    description: 'اسنپ‌شات با موفقیت ایجاد شد',
    nextLabel: 'بستن',
    backLabel: '',
    nextDisabled: false,
  },
  error: {
    icon: '⚠️',
    title: 'خطا',
    description: 'خطای غیرمنتظره رخ داد',
    nextLabel: 'تلاش مجدد',
    backLabel: '',
    nextDisabled: false,
  },
}

const getMotion = (state: ExperienceState) => {
  const motion = design.motion
  switch (state) {
    case 'analyzing':
      return { duration: 300, easing: motion.easing.easeOut || 'cubic-bezier(0, 0, 0.2, 1)', key: 'fade' }
    case 'selecting':
      return { duration: 250, easing: motion.easing.default || 'cubic-bezier(0.4, 0, 0.2, 1)', key: 'slide-up' }
    case 'metadata':
      return { duration: 250, easing: motion.easing.default || 'cubic-bezier(0.4, 0, 0.2, 1)', key: 'slide-up' }
    case 'review':
      return { duration: 250, easing: motion.easing.default || 'cubic-bezier(0.4, 0, 0.2, 1)', key: 'slide-up' }
    case 'creating':
      return { duration: 500, easing: motion.easing.spring || 'cubic-bezier(0.34, 1.56, 0.64, 1)', key: 'pulse' }
    case 'done':
      return { duration: 400, easing: motion.easing.spring || 'cubic-bezier(0.34, 1.56, 0.64, 1)', key: 'scale-up' }
    case 'error':
      return { duration: 300, easing: motion.easing.default || 'cubic-bezier(0.4, 0, 0.2, 1)', key: 'shake' }
    default:
      return { duration: 250, easing: motion.easing.default || 'cubic-bezier(0.4, 0, 0.2, 1)', key: 'fade' }
  }
}

const getProgress = (state: ExperienceState): string => {
  const progressMap: Record<ExperienceState, number> = {
    idle: 0,
    analyzing: 25,
    selecting: 33,
    metadata: 66,
    review: 90,
    creating: 95,
    done: 100,
    error: 100,
  }
  return `${progressMap[state] || 0}%`
}

export const resolve = (state: ExperienceState): UISpec => {
  const colors = getStateColors(state)
  const layout = layoutMap[state] || layoutMap.idle
  const narrative = narrativeMap[state] || narrativeMap.idle
  const motion = getMotion(state)
  const progress = getProgress(state)

  return {
    bg: colors.bg,
    bgBadge: colors.bgBadge,
    bgProgress: colors.bgProgress,
    text: colors.text,
    textBadge: colors.textBadge,
    border: colors.border,
    borderBadge: colors.borderBadge,
    light: colors.light,
    dark: colors.dark,
    iconColor: colors.iconColor,
    stripeColor: colors.stripeColor,
    progressGradient: colors.progress,
    buttonPrimary: colors.buttonPrimary,
    buttonSecondary: colors.buttonSecondary,
    buttonDisabled: colors.buttonDisabled,
    stateClass: colors.stateClass,
    motionDuration: motion.duration,
    motionEasing: motion.easing,
    motionKey: motion.key,
    showProgress: layout.showProgress,
    showBack: layout.showBack,
    icon: narrative.icon,
    title: narrative.title,
    description: narrative.description,
    nextLabel: narrative.nextLabel,
    backLabel: narrative.backLabel,
    nextDisabled: narrative.nextDisabled,
    progress: progress,
  }
}