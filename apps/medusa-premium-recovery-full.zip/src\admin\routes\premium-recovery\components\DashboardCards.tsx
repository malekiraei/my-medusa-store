// apps/premium-recovery-plugin/src/admin/routes/premium-recovery/components/DashboardCards.tsx
// ============================================================
// DashboardCards - OPINIONATED IDENTITY LAYER
// ✅ Hero = identity anchor | Chart = insight engine
// ✅ Card 77 = signal marker | Color = state + intent
// ============================================================

import React, { useEffect, useState } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"

type SystemStatusUI = {
  changed_files_count: number
  safety_active: boolean
  latest_snapshot: string | null
  protection_level?: string
}

type SystemState = "empty" | "stable" | "degraded" | "critical"

type DashboardCardsProps = {
  status: SystemStatusUI | null
  pointsCount: number
  bundlesCount: number
  loading?: boolean
  onOpenWizard?: () => void
}

// ============================================================
// Icons - با پشتیبانی از className
// ============================================================
const Icons = {
  Shield: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  CircleAlert: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <circle cx="12" cy="12" r="10" strokeWidth={1.6} />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M12 8v4m0 4h.01" />
    </svg>
  ),
  Files: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
    </svg>
  ),
  Database: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <ellipse cx="12" cy="5" rx="9" ry="3" strokeWidth={1.6} />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
    </svg>
  ),
  Package: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10" />
    </svg>
  ),
  Calendar: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.6}>
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" strokeWidth={1.6} />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.6} d="M16 2v4M8 2v4M3 10h18" />
    </svg>
  ),
  Plus: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
  ),
  EmptyState: ({ className = "" }: { className?: string }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
    </svg>
  ),
}

// ============================================================
// Helper Functions
// ============================================================
const resolveSystemState = (status: SystemStatusUI | null, fileCount: number): SystemState => {
  if (!status) return "empty"
  if (status.protection_level === "unprotected") return "critical"
  if (status.protection_level === "partially_protected") return "degraded"
  if (status.protection_level === "protected") return "stable"
  if (fileCount === 0) return "stable"
  if (fileCount > 10) return "critical"
  if (fileCount > 3) return "degraded"
  return "stable"
}

const stateConfig = {
  empty: {
    state: "empty" as SystemState,
    label: "سیستم آماده است",
    badge: "آماده",
    tone: "gray",
    description: () => "داده‌ای برای نمایش وجود ندارد",
    icon: "shield",
  },
  stable: {
    state: "stable" as SystemState,
    label: "سیستم پایدار",
    badge: "عادی",
    tone: "emerald",
    description: () => "همه سیستم‌ها در وضعیت عادی",
    icon: "shield",
  },
  degraded: {
    state: "degraded" as SystemState,
    label: "بررسی تغییرات",
    badge: "توجه",
    tone: "amber",
    description: (count: number) => `${count} فایل تغییر کرده`,
    icon: "shield",
  },
  critical: {
    state: "critical" as SystemState,
    label: "سیستم در معرض خطر",
    badge: "فوری",
    tone: "rose",
    description: (count: number) => `${count} فایل بدون محافظت شناسایی شده است`,
    icon: "alert",
  },
}

// ============================================================
// Component
// ============================================================
export const DashboardCards: React.FC<DashboardCardsProps> = ({
  status,
  pointsCount,
  bundlesCount,
  loading,
  onOpenWizard,
}) => {
  const [mounted, setMounted] = useState(false)
  const [prevPoints, setPrevPoints] = useState(pointsCount)
  const [pointsAnimating, setPointsAnimating] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 50)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (pointsCount !== prevPoints) {
      setPointsAnimating(true)
      const timer = setTimeout(() => setPointsAnimating(false), 300)
      setPrevPoints(pointsCount)
      return () => clearTimeout(timer)
    }
  }, [pointsCount, prevPoints])

  const safeFileCount = status?.changed_files_count ?? 0
  const safeHasSafety = status?.safety_active ?? false
  const systemState: SystemState = resolveSystemState(status, safeFileCount)

  const config = stateConfig[systemState]
  const isCritical = systemState === "critical"
  const isDegraded = systemState === "degraded"
  const isEmpty = systemState === "empty"

  const getChartData = () => {
    const safe = Math.max(0, 100 - safeFileCount)
    const changed = Math.min(safeFileCount, 100)
    return [
      { name: 'محافظت‌شده', value: safe },
      { name: 'تغییر یافته', value: changed },
    ]
  }

  const chartData = getChartData()
  const chartColors = ['#D4C9A8', '#C9A8A0']

  const heroIcon = isEmpty ? <Icons.EmptyState /> : isCritical ? <Icons.CircleAlert /> : <Icons.Shield />

  const warmColors = {
    critical: {
      bg: 'from-rose-400/14 via-rose-400/7 to-transparent',
      border: 'border-rose-400/20',
      text: 'text-rose-700/85 dark:text-rose-400/85',
      textStrong: 'text-rose-800/90 dark:text-rose-300/90',
      stripe: 'from-rose-400/55 via-rose-400/35 to-rose-400/15',
      intent: 'urgent-focus',
    },
    degraded: {
      bg: 'from-amber-400/14 via-amber-400/7 to-transparent',
      border: 'border-amber-400/20',
      text: 'text-amber-700/85 dark:text-amber-400/85',
      textStrong: 'text-amber-800/90 dark:text-amber-300/90',
      stripe: 'from-amber-400/55 via-amber-400/35 to-amber-400/15',
      intent: 'caution-awareness',
    },
    stable: {
      bg: 'from-emerald-400/14 via-emerald-400/7 to-transparent',
      border: 'border-emerald-400/20',
      text: 'text-emerald-700/85 dark:text-emerald-400/85',
      textStrong: 'text-emerald-800/90 dark:text-emerald-300/90',
      stripe: 'from-emerald-400/55 via-emerald-400/35 to-emerald-400/15',
      intent: 'confident-calm',
    },
    empty: {
      bg: 'from-gray-300/8 via-gray-300/4 to-transparent',
      border: 'border-gray-200/12',
      text: 'text-gray-500/85 dark:text-gray-400/85',
      textStrong: 'text-gray-600/90 dark:text-gray-300/90',
      stripe: 'from-gray-300/30 via-gray-300/15 to-gray-300/5',
      intent: 'invitation',
    },
  }

  const warm = isEmpty ? warmColors.empty : isCritical ? warmColors.critical : isDegraded ? warmColors.degraded : warmColors.stable

  const heroGradient = isEmpty
    ? 'bg-[#FAFAF8] dark:bg-gray-900/50'
    : `bg-gradient-to-b ${warm.bg} bg-[#FAFAF8] dark:bg-gray-900/80`

  const card1Gradient = `bg-gradient-to-l ${warm.bg} bg-[#FAFAF8] dark:bg-gray-900/60`
  const card2Gradient = 'bg-gradient-to-l from-indigo-400/8 via-indigo-400/4 to-transparent bg-[#FAFAF8] dark:bg-gray-900/60'
  const card3Gradient = safeHasSafety
    ? 'bg-gradient-to-l from-emerald-400/8 via-emerald-400/4 to-transparent bg-[#FAFAF8] dark:bg-gray-900/60'
    : 'bg-gradient-to-l from-rose-400/8 via-rose-400/4 to-transparent bg-[#FAFAF8] dark:bg-gray-900/60'

  const cardRadius = '16px'

  if (loading) {
    return (
      <div className="space-y-6 font-body bg-[#FAFAF8] dark:bg-gray-950 p-4 rounded-2xl">
        <div className="h-32 bg-gray-100/8 dark:bg-gray-800/4 rounded-2xl shimmer-identity" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 bg-gray-100/8 dark:bg-gray-800/4 rounded-2xl shimmer-identity" />
          ))}
        </div>
        <style>{`
          .shimmer-identity {
            background: linear-gradient(90deg, transparent 0%, rgba(200,190,180,0.04) 50%, transparent 100%);
            background-size: 200% 100%;
            animation: shimmerIdentity 2.5s ease-in-out infinite;
          }
          @keyframes shimmerIdentity {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
          }
        `}</style>
      </div>
    )
  }

  return (
    <div className="space-y-6 font-body bg-[#FAFAF8] dark:bg-gray-950 p-4 rounded-2xl">
      
      {/* ===== HERO ===== */}
      <div
        className={`
          relative overflow-hidden
          rounded-[${cardRadius}]
          ${heroGradient}
          border ${warm.border}
          shadow-none
          ${mounted ? 'opacity-100' : 'opacity-0'}
          transition-opacity duration-700
          w-full
        `}
      >
        <div className="relative z-10 px-5 lg:px-8 py-5 lg:py-6">
          <div className="flex flex-row items-center gap-3 lg:gap-4">
            <div
              className={`
                flex items-center justify-center
                w-10 h-10 lg:w-12 lg:h-12
                rounded-full
                ${isEmpty ? 'text-gray-400 dark:text-gray-500' : warm.text}
                flex-shrink-0
                bg-[#FAFAF8] dark:bg-gray-800/40
                border border-gray-200/10 dark:border-gray-700/10
                shadow-none
              `}
            >
              {heroIcon}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-[0.12em] font-body">
                  {isEmpty ? 'سیستم آماده' : 'وضعیت سیستم'}
                </span>
                <span className={`text-[9px] font-medium px-2.5 py-0.5 rounded-full ${isEmpty ? 'bg-gray-100/50 dark:bg-gray-800/30 text-gray-500 dark:text-gray-400' : 'bg-gray-200/50 dark:bg-gray-700/30 text-gray-600 dark:text-gray-400'} font-body`}>
                  {config.badge}
                </span>
              </div>

              <h2 
                className={`text-base lg:text-xl font-semibold tracking-[-0.02em] leading-tight ${isEmpty ? 'text-gray-500 dark:text-gray-400' : warm.textStrong}`}
                style={{ fontWeight: 680 }}
              >
                {isEmpty ? 'سیستم آماده است' : isCritical ? 'نیاز به اقدام فوری' : isDegraded ? 'بررسی تغییرات' : 'سیستم در وضعیت عادی'}
              </h2>

              <p className={`text-[12px] lg:text-[13px] text-gray-500 dark:text-gray-400 font-body leading-relaxed`}>
                {isEmpty 
                  ? 'داده‌ای برای نمایش وجود ندارد' 
                  : isCritical 
                  ? `${safeFileCount} فایل بدون محافظت شناسایی شده است` 
                  : isDegraded 
                  ? `${safeFileCount} فایل تغییر کرده است` 
                  : 'همه سیستم‌ها در وضعیت عادی هستند'}
              </p>
            </div>

            <button
              onClick={onOpenWizard}
              className={`
                flex items-center gap-1.5
                px-3 py-1.5 lg:px-4 lg:py-2
                text-[12px] lg:text-[13px] font-medium
                rounded-[10px]
                ${isEmpty ? 'bg-gray-100/80 hover:bg-gray-200/80 dark:bg-gray-800/50 dark:hover:bg-gray-700/50 text-gray-600 dark:text-gray-300' : 'bg-gray-900/90 hover:bg-gray-800 dark:bg-gray-100 dark:hover:bg-gray-200 text-white dark:text-gray-900'}
                whitespace-nowrap
                transition-all duration-500 ease-out
                hover:scale-[1.01] active:scale-[0.99]
                font-body
                shadow-sm
                flex-shrink-0
              `}
            >
              ایجاد اسنپ‌شات
              <Icons.Plus />
            </button>
          </div>

          {!isEmpty && (
            <div className="mt-3 pt-3 border-t border-gray-200/15 dark:border-gray-700/15">
              <div className="flex items-center gap-5">
                <div className="flex items-center gap-1.5">
                  <span className={`text-sm font-medium tracking-tight ${warm.text}`}>
                    {safeFileCount}
                  </span>
                  <span className="text-[11px] text-gray-400 dark:text-gray-500 font-body">فایل تغییر یافته</span>
                </div>
                <div className="w-px h-4 bg-gray-200/15 dark:bg-gray-700/15" />
                <div className="flex items-center gap-1.5">
                  <span className={`text-sm font-medium tracking-tight text-gray-500 dark:text-gray-400 ${pointsAnimating ? 'counter-pop' : ''}`}>
                    {pointsCount}
                  </span>
                  <span className="text-[11px] text-gray-400 dark:text-gray-500 font-body">اسنپ‌شات</span>
                </div>
                <div className="w-px h-4 bg-gray-200/15 dark:bg-gray-700/15" />
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-medium tracking-tight text-gray-500 dark:text-gray-400">
                    {bundlesCount}
                  </span>
                  <span className="text-[11px] text-gray-400 dark:text-gray-500 font-body">باندل</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ===== CARDS ===== */}
      {isEmpty ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4">
          {[
            { label: 'تغییرات شناسایی‌شده', icon: <Icons.Files className="w-4 h-4 text-gray-400" /> },
            { label: 'نقاط بازیابی', icon: <Icons.Database className="w-4 h-4 text-gray-400" /> },
            { label: 'لایه امنیتی', icon: <Icons.Shield className="w-4 h-4 text-gray-400" /> },
          ].map((item, i) => (
            <div
              key={i}
              className={`
                relative
                rounded-[${cardRadius}]
                p-4 lg:p-5
                bg-[#FAFAF8] dark:bg-gray-900/40
                border border-gray-200/15 dark:border-gray-700/10
                shadow-none
                flex items-center gap-3
                min-h-[60px]
              `}
            >
              <div className="w-8 h-8 rounded-full flex items-center justify-center bg-gray-100/50 dark:bg-gray-800/30 border border-gray-200/10 dark:border-gray-700/10 flex-shrink-0">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <span className="text-base font-medium tracking-[-0.02em] text-gray-300 dark:text-gray-600">—</span>
                <div className="text-[10px] font-medium text-gray-300 dark:text-gray-600 uppercase tracking-[0.08em] font-body truncate">
                  {item.label}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4">
          
          {/* Card 1 */}
          <div
            className={`
              relative
              rounded-[${cardRadius}]
              p-4 lg:p-5
              ${card1Gradient}
              border ${warm.border}
              shadow-[0_1px_8px_-2px_rgba(0,0,0,0.02)]
              transition-all duration-500 ease-out
              hover:shadow-[0_4px_20px_-6px_rgba(0,0,0,0.04)]
              hover:border-gray-300/30 dark:hover:border-gray-600/30
              flex items-center gap-3
              min-h-[64px] lg:min-h-[72px]
              group
              cursor-pointer
            `}
          >
            <div className={`absolute inset-y-3 right-0 w-[1.5px] rounded-l-full bg-gradient-to-b ${warm.stripe}`} />

            <div className="w-12 h-12 lg:w-14 lg:h-14 flex-shrink-0 opacity-95">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={14}
                    outerRadius={20}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} strokeWidth={1} stroke="rgba(180,170,160,0.2)" />
                    ))}
                  </Pie>
                  <Tooltip
  contentStyle={{
    background: '#FAFAF8',
    borderRadius: '8px',
    border: '1px solid rgba(200,190,180,0.15)',
    fontSize: '10px',
    fontFamily: 'IRANSansWeb, sans-serif',
    direction: 'rtl',
    padding: '6px 12px',
    boxShadow: '0 4px 20px -8px rgba(0,0,0,0.04)',
  }}
  formatter={(value: any) => [`${value}%`, '']}
/>
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-xl lg:text-2xl font-bold tracking-[-0.02em] ${warm.text}`}>
                  {safeFileCount}
                </span>
                <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-[0.08em] font-body">
                  تغییرات
                </span>
              </div>
              <div className="text-[10px] font-medium text-gray-500 dark:text-gray-400">
                {isCritical ? '⚠ نیاز به اقدام فوری' : isDegraded ? '🔍 نیاز به بررسی' : '✅ وضعیت عادی'}
              </div>
              <div className="w-full max-w-[60%] h-1 bg-gray-200/20 dark:bg-gray-700/20 rounded-full overflow-hidden mt-1">
                <div
                  className="h-full rounded-full transition-all duration-700 ease-out opacity-70"
                  style={{
                    width: `${Math.min((safeFileCount / 100) * 100, 100)}%`,
                    background: isCritical ? '#C9A8A0' : isDegraded ? '#D4C9A8' : '#A8C9B8',
                  }}
                />
              </div>
            </div>
          </div>

          {/* Card 2 */}
          <div
            className={`
              relative
              rounded-[${cardRadius}]
              p-4 lg:p-5
              ${card2Gradient}
              border border-indigo-400/10 dark:border-indigo-700/8
              shadow-[0_1px_8px_-2px_rgba(0,0,0,0.02)]
              transition-all duration-500 ease-out
              hover:shadow-[0_4px_20px_-6px_rgba(0,0,0,0.04)]
              hover:border-indigo-300/30 dark:hover:border-indigo-600/30
              flex items-center gap-3
              min-h-[60px] lg:min-h-[68px]
              group
              cursor-pointer
            `}
          >
            <div className="absolute inset-y-3 right-0 w-[1.5px] rounded-l-full bg-gradient-to-b from-indigo-400/40 via-indigo-400/25 to-indigo-400/10" />

            <div className="w-9 h-9 lg:w-10 lg:h-10 rounded-full flex items-center justify-center bg-[#FAFAF8] dark:bg-gray-800/40 border border-gray-200/10 dark:border-gray-700/10 flex-shrink-0">
              <Icons.Database className="w-4 h-4 text-indigo-500/60 dark:text-indigo-400/60" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-xl lg:text-2xl font-normal tracking-[-0.02em] text-gray-700 dark:text-gray-200 ${pointsAnimating ? 'counter-pop' : ''}`}>
                  {pointsCount}
                </span>
                <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-[0.08em] font-body">
                  بازیابی
                </span>
              </div>
              <div className="text-[10px] text-gray-400 dark:text-gray-500">
                {pointsCount > 0 ? 'ذخیره شده' : 'هیچ'}
              </div>
            </div>
          </div>

          {/* Card 3 */}
          <div
            className={`
              relative
              rounded-[${cardRadius}]
              p-4 lg:p-5
              ${card3Gradient}
              border ${safeHasSafety ? 'border-emerald-400/10 dark:border-emerald-700/8' : 'border-rose-400/10 dark:border-rose-700/8'}
              shadow-[0_1px_8px_-2px_rgba(0,0,0,0.02)]
              transition-all duration-500 ease-out
              hover:shadow-[0_4px_20px_-6px_rgba(0,0,0,0.04)]
              flex items-center gap-3
              min-h-[60px] lg:min-h-[68px]
              group
              cursor-pointer
            `}
          >
            <div className={`absolute inset-y-3 right-0 w-[1.5px] rounded-l-full bg-gradient-to-b ${safeHasSafety ? 'from-emerald-400/40 via-emerald-400/25 to-emerald-400/10' : 'from-rose-400/40 via-rose-400/25 to-rose-400/10'}`} />

            <div className="w-9 h-9 lg:w-10 lg:h-10 rounded-full flex items-center justify-center bg-[#FAFAF8] dark:bg-gray-800/40 border border-gray-200/10 dark:border-gray-700/10 flex-shrink-0">
              <Icons.Shield className={`w-4 h-4 ${safeHasSafety ? 'text-emerald-500/60 dark:text-emerald-400/60' : 'text-rose-500/60 dark:text-rose-400/60'}`} />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-2">
                <span className={`text-xl lg:text-2xl font-normal tracking-[-0.02em] text-gray-700 dark:text-gray-200`}>
                  {safeHasSafety ? 'فعال' : 'خاموش'}
                </span>
                <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase tracking-[0.08em] font-body">
                  امنیت
                </span>
              </div>
              <div className="text-[10px] text-gray-400 dark:text-gray-500">
                {safeHasSafety ? 'محافظت' : 'نیاز به فعال‌سازی'}
              </div>
              <div className="w-full max-w-[60%] h-1 bg-gray-200/20 dark:bg-gray-700/20 rounded-full overflow-hidden mt-1.5">
                <div
                  className="h-full rounded-full transition-all duration-700 ease-out opacity-60"
                  style={{
                    width: safeHasSafety ? '100%' : '25%',
                    background: safeHasSafety ? '#A8C9B8' : '#C9A8A0',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== TELEMETRY ===== */}
      <div className={`flex items-center justify-center gap-4 lg:gap-6 px-2 py-1 ${isEmpty ? 'opacity-50' : 'opacity-70'}`}>
        <div className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400 font-body">
          <Icons.Package className="w-3.5 h-3.5" />
          <span>
            <span className="font-medium text-gray-600 dark:text-gray-300">
              {bundlesCount}
            </span>{" "}
            باندل
          </span>
        </div>

        <div className="w-px h-3 bg-gray-300/20 dark:bg-gray-600/20" />

        <div className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400 font-body">
          <Icons.Calendar className="w-3.5 h-3.5" />
          <span>
            آخرین اسنپ‌شات:{' '}
            <span className="font-medium text-gray-600 dark:text-gray-300">
              {status?.latest_snapshot
                ? new Date(status.latest_snapshot).toLocaleDateString("fa-IR", {
                    month: "long",
                    day: "numeric",
                  })
                : 'هیچ'}
            </span>
          </span>
        </div>

        <div className="w-px h-3 bg-gray-300/20 dark:bg-gray-600/20" />

        <div className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400 font-body">
          <span className={`w-1.5 h-1.5 rounded-full ${isCritical ? 'bg-rose-400/40' : 'bg-emerald-400/40'}`} />
          <span>سیستم {isCritical ? 'نیاز به توجه' : 'پایدار'}</span>
        </div>
      </div>

      <style>{`
        @keyframes identityDrift {
          0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.03; }
          25% { transform: translate(30px, -20px) scale(1.12); opacity: 0.08; }
          75% { transform: translate(-18px, 14px) scale(0.88); opacity: 0.01; }
        }
        @keyframes counterPop {
          0% { transform: scale(1); }
          50% { transform: scale(1.06); }
          100% { transform: scale(1); }
        }
        .counter-pop {
          animation: counterPop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .bg-\\[\\#FAFAF8\\] {
          background-color: #FAFAF8;
        }
        .dark .bg-\\[\\#FAFAF8\\] {
          background-color: transparent;
        }
      `}</style>
    </div>
  )
}

export default DashboardCards