// src/admin/routes/premium-recovery/components/StatusBanner.tsx
// ============================================================
// Premium Recovery - Status Banner
// STRIPE/VERCEL STYLE - Enterprise Grade - Production Ready
// ============================================================

import React from "react"

// ============================================================
// Types
// ============================================================

export type SystemStatusUI = {
  protection_level?: string
  changed_files_count?: number
  bundle_count?: number
  safety_active?: boolean
  latest_snapshot?: string | null
}

type StatusBannerProps = {
  status: SystemStatusUI | null
  loading?: boolean
  onRefresh?: () => void
}

// ============================================================
// Icons - Lucide-style inline SVG
// ============================================================
const Icons = {
  ShieldCheck: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  AlertTriangle: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
  ),
  CircleAlert: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="12" r="10" strokeWidth={2} />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01" />
    </svg>
  ),
  Refresh: () => (
    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
}

// ============================================================
// State Configuration - Type-safe
// ============================================================
const stateConfig = {
  protected: {
    bg: "bg-emerald-50/80 dark:bg-emerald-950/20",
    border: "border-emerald-200 dark:border-emerald-800/40",
    accent: "bg-emerald-500 dark:bg-emerald-400",
    text: "text-emerald-700 dark:text-emerald-300",
    iconBg: "bg-emerald-100 dark:bg-emerald-900/30",
    icon: Icons.ShieldCheck,
    title: "وضعیت بازیابی پایدار است",
    description: (status: SystemStatusUI) =>
      status.bundle_count && status.bundle_count > 0
        ? `${status.bundle_count} باندل بازیابی آماده است.`
        : "همه تغییرات تحت پوشش هستند.",
  },
  partially_protected: {
    bg: "bg-amber-50/80 dark:bg-amber-950/20",
    border: "border-amber-200 dark:border-amber-800/40",
    accent: "bg-amber-500 dark:bg-amber-400",
    text: "text-amber-700 dark:text-amber-300",
    iconBg: "bg-amber-100 dark:bg-amber-900/30",
    icon: Icons.AlertTriangle,
    title: "محافظت نسبی",
    description: (status: SystemStatusUI) =>
      `${status.changed_files_count || 0} فایل تغییر کرده است. توصیه می‌شود اسنپ‌شات جدید ایجاد کنید.`,
  },
  unprotected: {
    bg: "bg-rose-50/80 dark:bg-rose-950/20",
    border: "border-rose-200 dark:border-rose-800/40",
    accent: "bg-rose-500 dark:bg-rose-400",
    text: "text-rose-700 dark:text-rose-300",
    iconBg: "bg-rose-100 dark:bg-rose-900/30",
    icon: Icons.CircleAlert,
    title: "سیستم در معرض خطر",
    description: (status: SystemStatusUI) =>
      `${status.changed_files_count || 0} فایل بدون اسنپ‌شات جدید شناسایی شده است.`,
  },
} as const

type ProtectionLevel = keyof typeof stateConfig
type StateConfig = typeof stateConfig[ProtectionLevel]

// ============================================================
// Helper Functions
// ============================================================
const getStateConfig = (level?: string | null): StateConfig => {
  if (level && level in stateConfig) {
    return stateConfig[level as ProtectionLevel]
  }
  return stateConfig.unprotected
}

const getActionButtonClassName = (level: string): string => {
  const isUnprotected = level === "unprotected"
  return `
    text-[12px] font-medium
    px-3 py-1.5 rounded-lg
    border ${isUnprotected ? 'border-rose-200/70 dark:border-rose-800/50' : 'border-gray-200/60 dark:border-gray-700/50'}
    ${isUnprotected ? 'text-rose-700 dark:text-rose-300' : 'text-gray-600 dark:text-gray-400'}
    ${isUnprotected ? 'bg-rose-50/80 dark:bg-rose-950/20 hover:bg-rose-100/80 dark:hover:bg-rose-900/30' : 'bg-white/60 dark:bg-gray-800/30 hover:bg-white/80 dark:hover:bg-gray-700/30'}
    focus:outline-none
    focus:ring-2 focus:ring-gray-400/40 dark:focus:ring-gray-500/40
    focus:ring-offset-2 dark:focus:ring-offset-gray-900
    transition-all duration-150
  `
}

// ============================================================
// Component - Status Banner
// ============================================================
export const StatusBanner: React.FC<StatusBannerProps> = ({
  status,
  loading = false,
  onRefresh,
}) => {
  if (loading || !status) {
    return (
      <div className="
        rounded-xl
        border border-gray-200/60 dark:border-gray-700/50
        bg-gray-50/60 dark:bg-gray-900/30
        px-5 py-3.5
        flex flex-col sm:flex-row sm:items-center sm:justify-between
        gap-3
        animate-pulse
      ">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-lg" />
          <div className="space-y-1">
            <div className="h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded" />
            <div className="h-3 w-48 bg-gray-200 dark:bg-gray-700 rounded" />
          </div>
        </div>
        <div className="w-20 h-8 bg-gray-200 dark:bg-gray-700 rounded-lg" />
      </div>
    )
  }

  const level = status.protection_level || "unprotected"
  const config = getStateConfig(level)
  const needsAction = level === "unprotected" || level === "partially_protected"
  const IconComponent = config.icon
  const actionButtonClassName = getActionButtonClassName(level)

  return (
    <div className={`
      relative
      rounded-xl
      border ${config.border}
      ${config.bg}
      shadow-sm shadow-black/5 dark:shadow-black/20
      px-5 py-3.5
      flex flex-col sm:flex-row sm:items-center justify-between
      gap-3
      transition-all duration-200
      hover:shadow-md hover:shadow-black/10 dark:hover:shadow-black/30
    `}>
      <div className={`
        absolute inset-y-3 right-0
        w-1
        ${config.accent}
        rounded-l-full
      `} />

      <div className="flex items-center gap-3 pr-6">
        <div className={`
          w-8 h-8
          flex items-center justify-center
          rounded-lg
          ${config.iconBg}
          border ${config.border}
          flex-shrink-0
          ${config.text}
        `}>
          <IconComponent />
        </div>

        <div>
          <div className={`text-[14px] font-semibold ${config.text} leading-6`}>
            {config.title}
          </div>
          <div className="text-[12px] text-gray-500 dark:text-gray-400 leading-5">
            {config.description(status)}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {needsAction && onRefresh && (
          <button
            onClick={onRefresh}
            aria-label="بررسی وضعیت بازیابی"
            className={actionButtonClassName}
          >
            بررسی وضعیت
          </button>
        )}
        {!needsAction && onRefresh && (
          <button
            onClick={onRefresh}
            aria-label="بررسی دوباره وضعیت"
            title="بررسی دوباره وضعیت"
            className="
              text-gray-400 dark:text-gray-500
              hover:text-gray-600 dark:hover:text-gray-300
              p-1.5 rounded-lg
              hover:bg-gray-100/50 dark:hover:bg-gray-800/30
              focus:outline-none
              focus:ring-2 focus:ring-gray-400/40 dark:focus:ring-gray-500/40
              focus:ring-offset-2 dark:focus:ring-offset-gray-900
              transition-all duration-150
            "
          >
            <Icons.Refresh />
          </button>
        )}
      </div>
    </div>
  )
}