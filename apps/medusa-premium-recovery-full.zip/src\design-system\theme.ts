// ============================================================
// DESIGN SYSTEM THEME - STATIC TONE MAP
// ✅ Compile-time deterministic class map
// ✅ No string interpolation for Tailwind classes
// ✅ Single source of truth for all tone-based styling
// ============================================================

export type Tone = 'rose' | 'amber' | 'emerald' | 'indigo'

export type ToneConfig = {
  text: string
  bg: string
  border: string
  stripe: string
  badge: string
  badgeText: string
  accent: string
  action: string
  ring: string
}

export const toneClassMap: Record<Tone, ToneConfig> = {
  rose: {
    text: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-500/10 dark:bg-rose-500/10',
    border: 'border-rose-500/40 dark:border-rose-700/40',
    stripe: 'bg-rose-500',
    badge: 'bg-rose-500/20 dark:bg-rose-500/20',
    badgeText: 'text-rose-700 dark:text-rose-300',
    accent: 'bg-rose-500 dark:bg-rose-400',
    action: 'bg-rose-600 hover:bg-rose-500 text-white shadow-2xl shadow-rose-600/35',
    ring: 'ring-rose-500/20',
  },
  amber: {
    text: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10 dark:bg-amber-500/10',
    border: 'border-amber-500/40 dark:border-amber-700/40',
    stripe: 'bg-amber-500',
    badge: 'bg-amber-500/20 dark:bg-amber-500/20',
    badgeText: 'text-amber-700 dark:text-amber-300',
    accent: 'bg-amber-500 dark:bg-amber-400',
    action: 'bg-amber-600 hover:bg-amber-500 text-white shadow-2xl shadow-amber-600/35',
    ring: 'ring-amber-500/20',
  },
  emerald: {
    text: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10 dark:bg-emerald-500/10',
    border: 'border-emerald-500/40 dark:border-emerald-700/40',
    stripe: 'bg-emerald-500',
    badge: 'bg-emerald-500/20 dark:bg-emerald-500/20',
    badgeText: 'text-emerald-700 dark:text-emerald-300',
    accent: 'bg-emerald-500 dark:bg-emerald-400',
    action: 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xl shadow-emerald-600/35',
    ring: 'ring-emerald-500/20',
  },
  indigo: {
    text: 'text-indigo-600 dark:text-indigo-400',
    bg: 'bg-indigo-500/10 dark:bg-indigo-500/10',
    border: 'border-indigo-500/40 dark:border-indigo-700/40',
    stripe: 'bg-indigo-500',
    badge: 'bg-indigo-500/20 dark:bg-indigo-500/20',
    badgeText: 'text-indigo-700 dark:text-indigo-300',
    accent: 'bg-indigo-500 dark:bg-indigo-400',
    action: 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-2xl shadow-indigo-600/35',
    ring: 'ring-indigo-500/20',
  },
}

// ===== Helper: Resolve tone from state =====
export type ToneState = 'critical' | 'moderate' | 'subtle' | 'info'

export const resolveTone = (state: ToneState): Tone => {
  const toneMap: Record<ToneState, Tone> = {
    critical: 'rose',
    moderate: 'amber',
    subtle: 'emerald',
    info: 'indigo',
  }
  return toneMap[state] || 'emerald'
}

// ===== Helper: Get full tone config =====
export const getToneConfig = (state: ToneState): ToneConfig => {
  const tone = resolveTone(state)
  return toneClassMap[tone]
}