// ============================================================
// Color Tokens - Pure System Layer
// ✅ تمام رنگ‌ها به صورت ثابت و semantic
// ✅ بدون logic، فقط داده
// ============================================================

export const colors = {
  // ===== Semantic Colors =====
  semantic: {
    success: {
      light: '#ecfdf5',
      default: '#10b981',
      dark: '#059669',
      text: '#059669',
      bg: 'rgba(16,185,129,0.08)',
      border: 'rgba(16,185,129,0.35)',
    },
    warning: {
      light: '#fffbeb',
      default: '#f59e0b',
      dark: '#d97706',
      text: '#d97706',
      bg: 'rgba(245,158,11,0.08)',
      border: 'rgba(245,158,11,0.35)',
    },
    danger: {
      light: '#fef2f2',
      default: '#ef4444',
      dark: '#e11d48',
      text: '#e11d48',
      bg: 'rgba(239,68,68,0.08)',
      border: 'rgba(239,68,68,0.5)',
    },
    info: {
      light: '#eef2ff',
      default: '#6366f1',
      dark: '#4f46e5',
      text: '#4f46e5',
      bg: 'rgba(99,102,241,0.08)',
      border: 'rgba(99,102,241,0.35)',
    },
  },

  // ===== Neutral =====
  neutral: {
    white: '#ffffff',
    gray: {
      50: '#f9fafb',
      100: '#f3f4f6',
      200: '#e5e7eb',
      300: '#d1d5db',
      400: '#9ca3af',
      500: '#6b7280',
      600: '#4b5563',
      700: '#374151',
      800: '#1f2937',
      900: '#111827',
      950: '#030712',
    },
  },

  // ===== Chart =====
  chart: {
    safe: '#10b981',
    danger: '#ef4444',
  },
} as const