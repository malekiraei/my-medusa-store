import React from "react"
import type { ActivityItem } from "../types/recovery.types"

type ActivityFeedProps = {
  activities: ActivityItem[]
  loading: boolean
  maxItems?: number
}

const getStatusIcon = (status: ActivityItem["status"]) => {
  switch (status) {
    case "success": return "✅"
    case "failed": return "❌"
    case "pending": return "⏳"
    default: return "📋"
  }
}

const getStatusColor = (status: ActivityItem["status"]) => {
  switch (status) {
    case "success": return "bg-emerald-100 text-emerald-700"
    case "failed": return "bg-red-100 text-red-700"
    case "pending": return "bg-amber-100 text-amber-700"
    default: return "bg-slate-100 text-slate-600"
  }
}

const getStatusText = (status: ActivityItem["status"]) => {
  switch (status) {
    case "success": return "موفق"
    case "failed": return "ناموفق"
    case "pending": return "در انتظار"
    default: return "نامشخص"
  }
}

const formatTime = (timestamp: string) => {
  try {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return "لحظاتی پیش"
    if (diffMins < 60) return `${diffMins} دقیقه پیش`
    if (diffHours < 24) return `${diffHours} ساعت پیش`
    if (diffDays < 7) return `${diffDays} روز پیش`
    return date.toLocaleDateString("fa-IR")
  } catch {
    return timestamp
  }
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({
  activities,
  loading,
  maxItems = 10,
}) => {
  const displayActivities = activities.slice(0, maxItems)

  if (loading) {
    return (
      <div className="text-center py-10 bg-white rounded-xl border border-slate-200">
        <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-slate-500 mt-3">در حال بارگذاری فعالیت‌ها...</p>
      </div>
    )
  }

  if (displayActivities.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-slate-200">
        <div className="w-16 h-16 mx-auto bg-slate-100 rounded-full flex items-center justify-center mb-4">
          <span className="text-2xl">📋</span>
        </div>
        <p className="text-slate-500 font-medium">هیچ فعالیتی ثبت نشده است</p>
        <p className="text-sm text-slate-400 mt-1">فعالیت‌های سیستم در اینجا نمایش داده می‌شوند</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {displayActivities.map((activity) => (
        <div
          key={activity.id}
          className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md transition-all duration-200"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div className="flex items-center gap-3">
              <span className="text-lg">{getStatusIcon(activity.status)}</span>
              <div>
                <p className="text-sm font-medium text-slate-800">{activity.message}</p>
                {activity.business_impact && (
                  <p className="text-xs text-slate-400 mt-0.5">
                    تأثیر کسب‌وکاری: {activity.business_impact}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-[10px] px-2 py-0.5 rounded-full ${getStatusColor(activity.status)}`}>
                {getStatusText(activity.status)}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {formatTime(activity.timestamp)}
              </span>
            </div>
          </div>
        </div>
      ))}

      {activities.length > maxItems && (
        <p className="text-center text-xs text-slate-400 pt-2">
          و {activities.length - maxItems} فعالیت دیگر...
        </p>
      )}
    </div>
  )
}
