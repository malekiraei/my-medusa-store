// ============================================================
// Pure State → UI Projection System
// ✅ state → UISpec (خالص، بدون دانش UI)
// ✅ هیچ meta ورودی ندارد
// ✅ Stripe Final Form
// ============================================================

import { colors } from './tokens/colors'

// ============================================================
// 🎯 Types - فقط state
// ============================================================

export type ProjectionState =
  | 'idle'
  | 'analyzing'
  | 'selecting'
  | 'metadata'
  | 'review'
  | 'creating'
  | 'done'
  | 'error'

// ===== UISpec (خالص، فقط داده) =====
export type UISpec = {
  // Emotion
  color: 'emerald' | 'rose' | 'amber' | 'indigo'
  accent: string
  text: string
  badge: string
  badgeClass: string

  // Motion
  duration: number
  easing: string
  enter: string
  exit: string

  // Layout
  showProgress: boolean
  showBack: boolean
  scroll: boolean

  // Narrative
  icon: string
  title: string
  description: string
  nextLabel: string
  backLabel: string
  nextDisabled: boolean
  variant: 'primary' | 'danger' | 'success'

  // Visual
  accentClass: string
  textClass: string
  bgClass: string
  borderClass: string

  // Progress
  progress: number
  steps: string[]
  currentStep: number
  totalSteps: number
}

// ============================================================
// 🧠 Pure Projection Function (State Only)
// ============================================================

export const project = (state: ProjectionState): UISpec => {
  // ===== 1. Emotion (از state) =====
  const emotionMap: Record<ProjectionState, { color: 'emerald' | 'rose' | 'amber' | 'indigo'; badge: string }> = {
    idle: { color: 'emerald', badge: 'عادی' },
    analyzing: { color: 'indigo', badge: 'در حال' },
    selecting: { color: 'emerald', badge: 'عادی' },
    metadata: { color: 'emerald', badge: 'عادی' },
    review: { color: 'rose', badge: 'فوری' },
    creating: { color: 'indigo', badge: 'در حال' },
    done: { color: 'emerald', badge: 'تکمیل' },
    error: { color: 'rose', badge: 'خطا' },
  }

  const emotion = emotionMap[state] || emotionMap.idle
  const color = emotion.color
  const semantic = colors.semantic[color as keyof typeof colors.semantic]

  // ===== 2. Motion (از state) =====
  const motionMap: Record<ProjectionState, { duration: number; easing: string; enter: string; exit: string }> = {
    idle: { duration: 300, easing: 'ease-out', enter: 'scale(1) translateY(0)', exit: 'scale(1) translateY(0)' },
    analyzing: { duration: 400, easing: 'ease-in-out', enter: 'scale(0.98) translateY(6px)', exit: 'scale(0.98) translateY(6px)' },
    selecting: { duration: 300, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', enter: 'scale(0.98) translateY(6px)', exit: 'scale(0.98) translateY(6px)' },
    metadata: { duration: 300, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', enter: 'scale(0.98) translateY(6px)', exit: 'scale(0.98) translateY(6px)' },
    review: { duration: 200, easing: 'ease-in-out', enter: 'scale(0.98) translateY(6px)', exit: 'scale(0.98) translateY(6px)' },
    creating: { duration: 300, easing: 'linear', enter: 'scale(0.98) translateY(6px)', exit: 'scale(0.98) translateY(6px)' },
    done: { duration: 400, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)', enter: 'scale(0.95) translateY(10px)', exit: 'scale(0.95) translateY(10px)' },
    error: { duration: 200, easing: 'ease-in-out', enter: 'scale(0.98) translateX(6px)', exit: 'scale(0.98) translateX(6px)' },
  }

  const motion = motionMap[state] || motionMap.idle

  // ===== 3. Layout (از state) =====
  const layoutMap: Record<ProjectionState, { showProgress: boolean; showBack: boolean; scroll: boolean }> = {
    idle: { showProgress: false, showBack: false, scroll: true },
    analyzing: { showProgress: true, showBack: false, scroll: false },
    selecting: { showProgress: true, showBack: false, scroll: true },
    metadata: { showProgress: true, showBack: true, scroll: true },
    review: { showProgress: true, showBack: true, scroll: true },
    creating: { showProgress: false, showBack: false, scroll: false },
    done: { showProgress: false, showBack: false, scroll: false },
    error: { showProgress: false, showBack: false, scroll: false },
  }

  const layout = layoutMap[state] || layoutMap.idle

  // ===== 4. Narrative (از state) =====
  const narrativeMap: Record<ProjectionState, { icon: string; title: string; description: string; nextLabel: string; backLabel: string; nextDisabled: boolean; variant: 'primary' | 'danger' | 'success' }> = {
    idle: { icon: '📁', title: 'آماده', description: '', nextLabel: 'شروع', backLabel: '', nextDisabled: true, variant: 'primary' },
    analyzing: { icon: '🔍', title: 'تحلیل تغییرات', description: 'در حال اسکن مخزن...', nextLabel: '...', backLabel: '', nextDisabled: true, variant: 'primary' },
    selecting: { icon: '📁', title: 'انتخاب فایل‌ها', description: 'فایل‌های تغییر یافته', nextLabel: 'ادامه', backLabel: '', nextDisabled: false, variant: 'primary' },
    metadata: { icon: '📝', title: 'اطلاعات اسنپ‌شات', description: 'تکمیل اطلاعات', nextLabel: 'ادامه', backLabel: 'قبلی', nextDisabled: false, variant: 'primary' },
    review: { icon: '✅', title: 'بررسی و ایجاد', description: 'لطفاً اطلاعات را بررسی کنید', nextLabel: 'ایجاد اسنپ‌شات', backLabel: 'قبلی', nextDisabled: false, variant: 'danger' },
    creating: { icon: '⏳', title: 'در حال ایجاد...', description: 'لطفاً چند لحظه صبر کنید', nextLabel: '...', backLabel: '', nextDisabled: true, variant: 'primary' },
    done: { icon: '🎉', title: 'تکمیل شد!', description: 'اسنپ‌شات با موفقیت ایجاد شد', nextLabel: 'بستن', backLabel: '', nextDisabled: false, variant: 'success' },
    error: { icon: '⚠️', title: 'خطا', description: 'خطای غیرمنتظره رخ داد', nextLabel: 'تلاش مجدد', backLabel: '', nextDisabled: false, variant: 'danger' },
  }

  const narrative = narrativeMap[state] || narrativeMap.idle

  // ===== 5. Visual (از state) =====
  const visual = {
    accentClass: `bg-${color}-500 dark:bg-${color}-400`,
    textClass: `text-${color}-600 dark:text-${color}-400`,
    bgClass: `bg-${color}-50 dark:bg-${color}-950/20`,
    borderClass: `border-${color}-200/40 dark:border-${color}-800/30`,
  }

  // ===== 6. Progress (از state) =====
  const steps = ['selecting', 'metadata', 'review']
  const stepIndex = steps.indexOf(state as any) + 1
  const progress = state === 'analyzing' ? 0 : state === 'idle' ? 0 : state === 'done' ? 100 : stepIndex > 0 ? (stepIndex / steps.length) * 100 : 0

  return {
    // Emotion
    color,
    accent: semantic?.default || '#10b981',
    text: semantic?.text || '#059669',
    badge: emotion.badge,
    badgeClass: `bg-${color}-500/20 dark:bg-${color}-500/20 text-${color}-700 dark:text-${color}-300`,

    // Motion
    ...motion,

    // Layout
    ...layout,

    // Narrative
    ...narrative,

    // Visual
    ...visual,

    // Progress
    progress,
    steps,
    currentStep: stepIndex > 0 ? stepIndex : 0,
    totalSteps: steps.length,
  }
}