// ============================================================
// STATE CONTRACT - Single Source of Truth
// ✅ Domain defines meaning → UI only renders
// ✅ Fully deterministic | Zero ambiguity
// ============================================================

export type SystemState = "empty" | "stable" | "degraded" | "critical"

export type SystemStateConfig = {
  state: SystemState
  label: string
  badge: string
  tone: "emerald" | "amber" | "rose" | "gray"
  description: (fileCount: number) => string
  icon: "shield" | "alert" | "check"
}

// ============================================================
// 🧠 State Resolver
// ============================================================

export const resolveSystemState = (
  status: any,
  fileCount: number
): SystemState => {
  // ===== No data =====
  if (!status) return "empty"

  // ===== Critical =====
  if (status.protection_level === "unprotected") return "critical"
  if (status.protection_level === "partially_protected") return "degraded"
  if (status.protection_level === "protected") return "stable"

  // ===== Fallback =====
  return "stable"
}

// ============================================================
// 🎯 State Config Map
// ============================================================

export const stateConfig: Record<SystemState, SystemStateConfig> = {
  empty: {
    state: "empty",
    label: "سیستم آماده است",
    badge: "آماده",
    tone: "gray",
    description: () => "داده‌ای برای نمایش وجود ندارد",
    icon: "shield",
  },
  stable: {
    state: "stable",
    label: "سیستم پایدار",
    badge: "عادی",
    tone: "emerald",
    description: () => "همه سیستم‌ها در وضعیت عادی",
    icon: "shield",
  },
  degraded: {
    state: "degraded",
    label: "بررسی تغییرات",
    badge: "توجه",
    tone: "amber",
    description: (count) => `${count} فایل تغییر کرده`,
    icon: "shield",
  },
  critical: {
    state: "critical",
    label: "سیستم در معرض خطر",
    badge: "فوری",
    tone: "rose",
    description: (count) => `${count} فایل بدون محافظت شناسایی شده است`,
    icon: "alert",
  },
}