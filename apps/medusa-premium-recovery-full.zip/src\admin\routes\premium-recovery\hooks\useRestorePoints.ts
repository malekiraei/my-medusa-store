// src/admin/routes/premium-recovery/hooks/useRestorePoints.ts
// ============================================================
// useRestorePoints - با مسیرهای صحیح API
// ✅ POST به /restore-points (نه /create)
// ✅ داده‌ها به درستی parse می‌شوند
// ============================================================

import { useState, useEffect, useCallback } from "react"

export type RestorePoint = {
  id: string
  name: string
  description: string
  business_context: string
  use_case: string
  files: string[]
  created_at: string
  hash: string
}

export type SnapshotFormData = {
  name: string
  description: string
  business_context: string
  use_case: string
  files: string[]
}

export const useRestorePoints = () => {
  const [points, setPoints] = useState<RestorePoint[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // ===== Fetch Restore Points =====
  const fetchPoints = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/admin/premium-recovery/restore-points", {
        credentials: "include",
        headers: { "Content-Type": "application/json" },
      })
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}))
        throw new Error(errorData?.message || "Failed to fetch restore points")
      }
      
      const data = await res.json()
      
      // ✅ پشتیبانی از چند فرمت پاسخ
      const pointsData = data?.restore_points ?? data?.data ?? data ?? []
      setPoints(Array.isArray(pointsData) ? pointsData : [])
      
      return pointsData
      
    } catch (e: any) {
      const message = e.message || "Unknown error"
      setError(message)
      console.error("❌ fetchPoints error:", message)
      return []
    } finally {
      setLoading(false)
    }
  }, [])

  // ===== Create Restore Point =====
  const createPoint = useCallback(async (formData: SnapshotFormData) => {
    try {
      // ✅ مسیر صحیح: /restore-points
      const res = await fetch("/admin/premium-recovery/restore-points", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          business_context: formData.business_context,
          use_case: formData.use_case,
          files: formData.files,
        }),
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}))
        throw new Error(errorData?.message || "Failed to create restore point")
      }

      const result = await res.json()
      
      // ✅ بعد از ایجاد موفق، لیست را Refresh کن
      await fetchPoints()
      
      console.log("✅ Restore point created successfully:", result)
      return { success: true, data: result }
      
    } catch (e: any) {
      const message = e.message || "Unknown error"
      console.error("❌ createPoint error:", message)
      return { success: false, error: message }
    }
  }, [fetchPoints])

  // ===== Delete Restore Point =====
  const deletePoint = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/admin/premium-recovery/restore-points/${id}`, {
        method: "DELETE",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}))
        throw new Error(errorData?.message || "Failed to delete restore point")
      }

      await fetchPoints()
      console.log("✅ Restore point deleted successfully")
      return { success: true }
      
    } catch (e: any) {
      const message = e.message || "Unknown error"
      console.error("❌ deletePoint error:", message)
      return { success: false, error: message }
    }
  }, [fetchPoints])

  // ===== Load initial data =====
  useEffect(() => {
    fetchPoints()
  }, [fetchPoints])

  return {
    points,
    loading,
    error,
    refetch: fetchPoints,
    createPoint,
    deletePoint,
  }
}

export default useRestorePoints