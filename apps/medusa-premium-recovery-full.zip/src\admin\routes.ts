export const routes = [
  {
    path: "/premium-recovery",
    component: "./pages/index",
  },
]