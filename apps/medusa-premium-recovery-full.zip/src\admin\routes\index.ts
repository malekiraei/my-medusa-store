// مسیر: apps/premium-recovery-plugin/src/admin/routes/index.ts
import { defineRouteConfig } from "@medusajs/admin-sdk"
import PremiumRecoveryPage from "./premium-recovery/page"

export const config = defineRouteConfig({
  label: "مرکز بازیابی پیشرفته",
})

export default PremiumRecoveryPage