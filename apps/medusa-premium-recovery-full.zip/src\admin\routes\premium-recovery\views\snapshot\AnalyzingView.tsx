// apps/premium-recovery-plugin/src/admin/routes/premium-recovery/views/snapshot/AnalyzingView.tsx
// ============================================================
// AnalyzingView - UNIFIED VIEW
// ✅ Same header pattern as other views
// ✅ Same padding system
// ============================================================

import React from "react"
import { ViewHeader } from "./ViewHeader"

type Props = {
  isFetching: boolean
  filesCount: number
  error: string | null
}

export default function AnalyzingView({ isFetching, filesCount, error }: Props) {
  return (
    <div className="flex flex-col h-full">
      {/* ===== Unified Header ===== */}
      <ViewHeader
        icon={
          <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        }
        iconColor="#6366f1"
        title="تحلیل تغییرات"
        subtitle={isFetching ? "در حال اسکن مخزن..." : `${filesCount} فایل یافت شد`}
      />

      {/* ===== Content ===== */}
      <div className="flex-1 overflow-y-auto py-3">
        <div className="flex flex-col items-center justify-center h-full text-center">
          {isFetching ? (
            <>
              <div className="relative w-12 h-12">
                <div className="absolute inset-0 rounded-full border-4 border-indigo-200 dark:border-indigo-800" />
                <div className="absolute inset-0 rounded-full border-4 border-t-indigo-500 dark:border-t-indigo-400 border-r-transparent border-b-transparent border-l-transparent animate-spin" />
              </div>
              <p className="mt-4 text-[14px] text-gray-500 dark:text-gray-400 font-body">
                در حال بررسی فایل‌های Git...
              </p>
            </>
          ) : error ? (
            <>
              <span className="text-3xl mb-3">⚠️</span>
              <p className="text-[14px] text-rose-600 dark:text-rose-400 font-body">
                {error}
              </p>
            </>
          ) : (
            <>
              <span className="text-3xl mb-3">📁</span>
              <p className="text-[14px] text-gray-700 dark:text-gray-300 font-body">
                {filesCount} فایل یافت شد
              </p>
              <p className="text-[12px] text-gray-400 dark:text-gray-500 font-body mt-1">
                آماده برای انتخاب
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  )
}