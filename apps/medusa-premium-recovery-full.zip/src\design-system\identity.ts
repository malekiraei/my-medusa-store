// apps/premium-recovery-plugin/src/design-system/identity.ts
// ============================================================
// Identity Layer - Simplified (۳ قانون)
// ✅ Light Mood: warm-neutral ambient
// ✅ Motion Feel: calm-responsive
// ✅ Emotional Scale: subtle → moderate → critical
// ============================================================

// ===== 1. Light Mood =====
export const lightMood = {
  ambient: 'warm-neutral',
  intensity: {
    subtle: '0.04',
    normal: '0.08',
    strong: '0.15',
  },
}

// ===== 2. Motion Feel =====
export const motionFeel = {
  style: 'calm-responsive',
  timing: {
    fast: '160ms',
    medium: '300ms',
    slow: '500ms',
  },
  behaviors: {
    hover: 'translateY(-2px)',
    press: 'scale(0.96)',
  },
}

// ===== 3. Emotional Scale =====
export const emotionalScale = {
  levels: ['subtle', 'moderate', 'critical'],
  mapping: {
    subtle: {
      color: 'emerald',
      intensity: 1,
    },
    moderate: {
      color: 'amber',
      intensity: 2,
    },
    critical: {
      color: 'rose',
      intensity: 3,
    },
  },
}

// ===== Identity (Export) =====
export const identity = {
  light: lightMood,
  motion: motionFeel,
  emotion: emotionalScale,
}