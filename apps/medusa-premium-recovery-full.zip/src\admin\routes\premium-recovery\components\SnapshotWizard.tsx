// apps/premium-recovery-plugin/src/admin/routes/premium-recovery/components/SnapshotWizard.tsx
// ============================================================
// SnapshotWizard - PURE EXPERIENCE RENDERER
// ✅ استفاده از state جدید
// ✅ safe array handling
// ============================================================

import { useEffect, useCallback, useRef } from "react"
import { useSnapshotMachine } from "../hooks/useSnapshotMachine"
import AnalyzingView from "../views/snapshot/AnalyzingView"
import SelectingView from "../views/snapshot/SelectingView"
import MetadataView from "../views/snapshot/MetadataView"
import ReviewView from "../views/snapshot/ReviewView"
import { resolve } from "../../../../design-system/experience"
import { globalMotionStyles } from "../../../../design-system/motion"
import { identity } from "../../../../design-system/identity"
import { design } from "../../../../design-system/lock"
import { snapshotService } from "../services/snapshot.service"

type SnapshotUseCase = "manual" | "before_update" | "before_theme_change" | "before_plugin_install"

type Props = {
  isOpen: boolean
  onClose: () => void
  onCreate: (data: { name: string; description: string; business_context: string; use_case: SnapshotUseCase; files: string[] }) => Promise<void>
  fetchGitFiles: () => Promise<any[]>
}

export default function SnapshotWizard({ isOpen, onClose, onCreate, fetchGitFiles }: Props) {
  const { state, send, open, close: closeMachine } = useSnapshotMachine({
    fetchFiles: fetchGitFiles,
    createSnapshot: async (data) => {
      const normalized = snapshotService.normalizePayload({
        name: data.name,
        description: data.description,
        businessContext: data.businessContext,
        useCase: data.useCase as SnapshotUseCase,
        files: data.files,
      })
      await onCreate(normalized)
    },
  })

  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) { open() } else { closeMachine() }
  }, [isOpen, open, closeMachine])

  const wizardState = snapshotService.extractState(state)
  const {
    experienceState,
    step,
    files,
    selected,
    error,
    name,
    description,
    context,
    useCase,
    isAnalyzing,
    isCreating,
    isError,
    isDone,
  } = wizardState

  const ui = resolve(experienceState)

  const handleClose = useCallback(() => {
    if (!snapshotService.isActionable(wizardState)) return
    send({ type: 'CLOSE' })
    onClose()
  }, [wizardState, send, onClose])

  const handleNext = useCallback(() => {
    if (step === 'selecting' && selected.length === 0) return
    if (step === 'metadata' && !name.trim()) return
    if (step === 'review') { send({ type: 'CREATE' }); return }
    send({ type: 'NEXT' })
  }, [step, selected, name, send])

  const handleBack = useCallback(() => {
    if (step === 'selecting') return
    send({ type: 'BACK' })
  }, [step, send])

  const handleRetry = useCallback(() => send({ type: 'RETRY' }), [send])

  const handleToggleFile = useCallback((path: string) => send({ type: 'TOGGLE_FILE', path }), [send])
  const handleSelectAll = useCallback(() => send({ type: 'SELECT_ALL' }), [send])
  const handleSetName = useCallback((name: string) => send({ type: 'SET_NAME', name }), [send])
  const handleSetDescription = useCallback((description: string) => send({ type: 'SET_DESCRIPTION', description }), [send])
  const handleSetContext = useCallback((context: string) => send({ type: 'SET_BUSINESS_CONTEXT', context }), [send])
  const handleSetUseCase = useCallback((useCase: string) => send({ type: 'SET_USE_CASE', useCase }), [send])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!isOpen) return
      if (e.key === 'Escape' && !isAnalyzing && !isCreating && !isDone) {
        e.preventDefault()
        handleClose()
      }
      if (e.key === 'ArrowLeft' && ui.showBack) {
        e.preventDefault()
        handleBack()
      }
      if (e.key === 'ArrowRight' && !ui.nextDisabled) {
        e.preventDefault()
        handleNext()
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [isOpen, isAnalyzing, isCreating, isDone, ui.showBack, ui.nextDisabled, handleClose, handleBack, handleNext])

  useEffect(() => {
    if (!isOpen) return
    const container = ref.current
    if (!container) return

    const focusable = container.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')
    const first = focusable[0] as HTMLElement
    const last = focusable[focusable.length - 1] as HTMLElement

    const trap = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last?.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first?.focus()
      }
    }

    setTimeout(() => {
      const input = container.querySelector('input[type="text"]')
      if (input && step === 'metadata') (input as HTMLElement).focus()
      else if (first) (first as HTMLElement).focus()
    }, 200)

    window.addEventListener('keydown', trap)
    return () => window.removeEventListener('keydown', trap)
  }, [isOpen, step])

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : 'unset'
    return () => { document.body.style.overflow = 'unset' }
  }, [isOpen])

  if (!isOpen) return null

  const actionable = snapshotService.isActionable(wizardState)

  const renderView = () => {
    const safeFiles = Array.isArray(files) ? files : []
    const safeSelected = Array.isArray(selected) ? selected : []

    switch (experienceState) {
      case 'analyzing':
        return (
          <AnalyzingView
            isFetching={step === 'loading'}
            filesCount={safeFiles.length}
            error={error}
          />
        )
      case 'selecting':
        return (
          <SelectingView
            files={safeFiles}
            selectedFiles={safeSelected}
            error={error}
            onToggleFile={handleToggleFile}
            onSelectAll={handleSelectAll}
            isAllSelected={safeFiles.length > 0 && safeSelected.length === safeFiles.length}
          />
        )
      case 'metadata':
        return (
          <MetadataView
            snapshotName={name}
            snapshotDescription={description}
            snapshotBusinessContext={context}
            snapshotUseCase={useCase as any}
            selectedCount={safeSelected.length}
            onSetName={handleSetName}
            onSetDescription={handleSetDescription}
            onSetBusinessContext={handleSetContext}
            onSetUseCase={handleSetUseCase}
          />
        )
      case 'review':
        return (
          <ReviewView
            snapshotName={name}
            snapshotDescription={description}
            snapshotBusinessContext={context}
            snapshotUseCase={useCase as any}
            selectedCount={safeSelected.length}
          />
        )
      case 'creating':
        return (
          <div className="flex flex-col items-center justify-center py-10">
            <div className="relative w-16 h-16">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-indigo-500/20 to-emerald-500/20" />
              <div className="absolute inset-0 rounded-full border-4 border-t-indigo-500 border-r-emerald-500 border-b-transparent border-l-transparent" />
              <div className="absolute inset-[6px] rounded-full border-4 border-t-transparent border-r-indigo-400/40 border-b-indigo-400/40 border-l-transparent" />
              <div className="absolute inset-[18px] rounded-full bg-gradient-to-br from-indigo-500 to-emerald-500" />
            </div>
            <p className="mt-6 text-[15px] font-medium text-gray-700 dark:text-gray-300 font-body">
              {ui.title}
            </p>
            <p className="mt-1.5 text-[12px] text-gray-400 dark:text-gray-500 font-body">
              {ui.description}
            </p>
          </div>
        )
      case 'done':
        return (
          <div className="py-10 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-full flex items-center justify-center text-3xl">
              ✅
            </div>
            <p className={ui.text}>{ui.title}</p>
            <p className="text-gray-400 dark:text-gray-500 mt-1 text-[12px] font-body">
              {ui.description}
            </p>
            <button onClick={handleClose} className={ui.buttonPrimary}>
              بستن
            </button>
          </div>
        )
      case 'error':
        return (
          <div className="py-10 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-rose-50 dark:bg-rose-950/20 rounded-full flex items-center justify-center text-3xl">
              ⚠️
            </div>
            <p className={ui.text}>{ui.title}</p>
            <p className="text-gray-400 dark:text-gray-500 mt-1 text-[12px] font-body">
              {ui.description}
            </p>
            <button onClick={handleRetry} className={ui.buttonPrimary}>
              {ui.nextLabel}
            </button>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center font-body"
        style={{
          background: 'rgba(0,0,0,0.4)',
          backdropFilter: 'blur(8px)',
          transition: `all ${ui.motionDuration}ms ${ui.motionEasing}`,
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? 'auto' : 'none',
        }}
        onClick={handleClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="wizard-title"
      >
        <div
          ref={ref}
          className="relative w-full max-w-[520px] mx-4 h-[90vh] max-h-[90vh] flex flex-col overflow-hidden wizard-modal"
          style={{
            background: 'rgba(255,255,255,0.85)',
            borderColor: 'rgba(255,255,255,0.1)',
            borderRadius: design.tokens.radius['3xl'],
            boxShadow: design.tokens.shadow.modal,
            transition: `all ${ui.motionDuration}ms ${ui.motionEasing}`,
            opacity: isOpen ? 1 : 0,
            transform: isOpen ? 'scale(1) translateY(0)' : 'scale(0.97) translateY(4px)',
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <style>{`
            @media (prefers-color-scheme: dark) {
              .wizard-modal { 
                background: rgba(17,24,39,0.92) !important; 
                border-color: rgba(255,255,255,0.05) !important; 
              }
            }
            ${globalMotionStyles}
          `}</style>

          <div
            className="absolute inset-0 pointer-events-none rounded-[18px] overflow-hidden"
            style={{
              background: `
                radial-gradient(ellipse at top-right, 
                  rgba(251, 146, 60, ${identity.light.intensity.subtle}) 0%, 
                  transparent 70%
                ),
                radial-gradient(ellipse at bottom-left, 
                  rgba(99, 102, 241, ${identity.light.intensity.subtle}) 0%, 
                  transparent 70%
                )
              `,
            }}
          />

          <div className="absolute inset-0 pointer-events-none rounded-[18px] overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/[0.03] to-emerald-500/[0.03]" />
          </div>

          <div className={design.layout.scroll.header}>
            <div className="px-6 pt-5 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-lg leading-none" style={{ color: ui.iconColor }}>
                    {ui.icon}
                  </span>
                  <h2 id="wizard-title" className={ui.text}>
                    {ui.title}
                  </h2>
                </div>
                <button
                  onClick={handleClose}
                  disabled={!actionable}
                  className="w-8 h-8 flex items-center justify-center rounded-[10px] transition-all duration-[160ms] active:scale-95 font-body text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 hover:bg-gray-100/60 dark:hover:bg-gray-800/60"
                  aria-label="بستن"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {ui.showProgress && !isError && !isDone && (
                <div className="mt-4">
                  <div className="relative">
                    <div className="w-full h-1.5 bg-gray-200/50 dark:bg-gray-700/50 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500 ease-out relative"
                        style={{
                          width: ui.progress,
                          background: ui.progressGradient,
                        }}
                      >
                        <div
                          className="absolute inset-0 rounded-full blur-[6px] opacity-50"
                          style={{ background: ui.progressGradient }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2.5 px-0.5 font-body">
                    <div className="text-[10px] font-medium text-gray-400 dark:text-gray-500">
                      {ui.progress}
                    </div>
                    <div className="text-[10px] font-medium text-gray-400 dark:text-gray-500">
                      {snapshotService.getStepLabel(experienceState)}
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="mx-6 border-t border-[rgba(255,255,255,0.1)] dark:border-[rgba(255,255,255,0.05)]" />
          </div>

          <div className={design.layout.scroll.body}>
            <div className="px-6 pb-4 pt-5 safe-layout font-body">
              <div key={experienceState} className={`motion-enter-${ui.motionKey}`}>
                {renderView()}
              </div>
            </div>
          </div>

          {ui.showProgress && !isError && !isDone && (
            <div className={design.layout.scroll.footer}>
              <div className="px-6 py-4 border-t border-[rgba(255,255,255,0.1)] dark:border-[rgba(255,255,255,0.05)] bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm font-body">
                <div className="flex items-center justify-end gap-3">
                  {ui.showBack && (
                    <button
                      onClick={handleBack}
                      disabled={isCreating}
                      className={`px-5 py-2 text-sm font-medium rounded-[10px] transition-all duration-[${ui.motionDuration}ms] active:scale-95 ${ui.buttonSecondary} disabled:opacity-40 disabled:cursor-not-allowed`}
                    >
                      {ui.backLabel}
                    </button>
                  )}
                  <button
                    onClick={handleNext}
                    disabled={ui.nextDisabled || isCreating}
                    className={`px-5 py-2 text-sm font-semibold rounded-[10px] transition-all duration-[${ui.motionDuration}ms] active:scale-95 text-white ${ui.buttonPrimary} ${ui.nextDisabled || isCreating ? 'opacity-60 cursor-not-allowed' : 'hover:scale-[1.02]'}`}
                  >
                    {ui.nextLabel}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        .safe-layout, .safe-layout * {
          min-width: 0;
          max-width: 100%;
          box-sizing: border-box;
        }
      `}</style>
    </>
  )
}