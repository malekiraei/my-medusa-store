export default function PremiumRecoveryPage() {
  return (
    <div style={{ padding: 20 }}>
      <h1>OK - PREMIUM RECOVERY</h1>
    </div>
  )
}