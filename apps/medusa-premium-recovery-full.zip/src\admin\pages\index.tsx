import React from "react"
import { defineRouteConfig } from "@medusajs/admin-sdk"

export const config = defineRouteConfig({
  label: "مرکز بازیابی پیشرفته",
})

export default function PremiumRecoveryPage() {
  return (
    <div className="p-6 flex flex-col gap-2">
      <h1 className="text-xl font-semibold m-0">
        Premium Recovery
      </h1>
      <p className="text-sm text-gray-500 m-0">
        Plugin is active and ready.
      </p>
    </div>
  )
}