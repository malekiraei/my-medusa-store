// ============================================================
// Motion System - Centralized
// ============================================================

export type MotionState = 
  | 'idle'
  | 'analyzing'
  | 'selecting'
  | 'metadata'
  | 'review'
  | 'creating'
  | 'done'
  | 'error'

export type MotionSpec = {
  duration: number
  easing: string
  enter: string
  exit: string
  keyframes: string
}

const motionMap: Record<MotionState, MotionSpec> = {
  idle: {
    duration: 300,
    easing: 'ease-out',
    enter: 'scale(1) translateY(0)',
    exit: 'scale(1) translateY(0)',
    keyframes: `
      from { opacity: 0; transform: scale(1) translateY(0); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  analyzing: {
    duration: 400,
    easing: 'ease-in-out',
    enter: 'scale(0.98) translateY(6px)',
    exit: 'scale(0.98) translateY(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateY(6px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  selecting: {
    duration: 300,
    easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    enter: 'scale(0.98) translateY(6px)',
    exit: 'scale(0.98) translateY(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateY(6px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  metadata: {
    duration: 300,
    easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    enter: 'scale(0.98) translateY(6px)',
    exit: 'scale(0.98) translateY(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateY(6px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  review: {
    duration: 300,
    easing: 'ease-in-out',
    enter: 'scale(0.98) translateY(6px)',
    exit: 'scale(0.98) translateY(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateY(6px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  creating: {
    duration: 300,
    easing: 'linear',
    enter: 'scale(0.98) translateY(6px)',
    exit: 'scale(0.98) translateY(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateY(6px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  done: {
    duration: 400,
    easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    enter: 'scale(0.95) translateY(10px)',
    exit: 'scale(0.95) translateY(10px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.95) translateY(10px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    `,
  },
  error: {
    duration: 300,
    easing: 'ease-in-out',
    enter: 'scale(0.98) translateX(6px)',
    exit: 'scale(0.98) translateX(6px)',
    keyframes: `
      from { opacity: 0; transform: scale(0.98) translateX(6px); }
      to { opacity: 1; transform: scale(1) translateX(0); }
    `,
  },
}

export const resolveMotion = (state: MotionState): MotionSpec => {
  return motionMap[state] || motionMap.idle
}

export const globalMotionStyles = Object.entries(motionMap)
  .map(([key, spec]) => `
    .motion-enter-${key} {
      animation: fadeIn-${key} ${spec.duration}ms ${spec.easing} forwards;
    }
    @keyframes fadeIn-${key} {
      from { opacity: 0; transform: ${spec.enter}; }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }
  `)
  .join('\n')