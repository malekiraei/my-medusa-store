// ============================================================
// Atomic Token Engine - No CSS Leakage
// ✅ Only JS tokens
// ✅ No className composition
// ✅ Single source of truth
// ============================================================

export type VisualState = 'idle' | 'analyzing' | 'selecting' | 'metadata' | 'review' | 'creating' | 'done' | 'error'

// ===== Fully Atomic Tokens =====
export type VisualTokens = {
  // ===== Backgrounds =====
  bg: string
  bgBadge: string
  bgProgress: string

  // ===== Texts =====
  text: string
  textBadge: string

  // ===== Borders =====
  border: string
  borderBadge: string

  // ===== Colors =====
  light: string
  dark: string
  iconColor: string
  stripeColor: string

  // ===== Gradients =====
  progress: string

  // ===== Buttons (fully atomic) =====
  buttonPrimary: string
  buttonSecondary: string
  buttonDisabled: string

  // ===== State Class (for conditional rendering) =====
  stateClass: string

  // ===== Motion reference =====
  motionKey: string
}

// ============================================================
// 🧠 Token Resolver
// ============================================================

const colorValues = {
  emerald: {
    bg: 'bg-emerald-50 dark:bg-emerald-950/20',
    bgBadge: 'bg-emerald-500/20 dark:bg-emerald-500/30',
    text: 'text-emerald-600 dark:text-emerald-400',
    textBadge: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-200/40 dark:border-emerald-800/30',
    borderBadge: 'border-emerald-300/30 dark:border-emerald-700/30',
    light: '#10b981',
    dark: '#059669',
    iconColor: '#10b981',
    stripeColor: '#10b981',
    progress: 'linear-gradient(to right, #10b981, #059669)',
    buttonPrimary: 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/25 hover:shadow-emerald-600/40',
    stateClass: 'state-emerald',
  },
  indigo: {
    bg: 'bg-indigo-50 dark:bg-indigo-950/20',
    bgBadge: 'bg-indigo-500/20 dark:bg-indigo-500/30',
    text: 'text-indigo-600 dark:text-indigo-400',
    textBadge: 'text-indigo-700 dark:text-indigo-300',
    border: 'border-indigo-200/40 dark:border-indigo-800/30',
    borderBadge: 'border-indigo-300/30 dark:border-indigo-700/30',
    light: '#6366f1',
    dark: '#4f46e5',
    iconColor: '#6366f1',
    stripeColor: '#6366f1',
    progress: 'linear-gradient(to right, #6366f1, #4f46e5)',
    buttonPrimary: 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/25 hover:shadow-indigo-600/40',
    stateClass: 'state-indigo',
  },
  rose: {
    bg: 'bg-rose-50 dark:bg-rose-950/20',
    bgBadge: 'bg-rose-500/20 dark:bg-rose-500/30',
    text: 'text-rose-600 dark:text-rose-400',
    textBadge: 'text-rose-700 dark:text-rose-300',
    border: 'border-rose-200/40 dark:border-rose-800/30',
    borderBadge: 'border-rose-300/30 dark:border-rose-700/30',
    light: '#f43f5e',
    dark: '#e11d48',
    iconColor: '#f43f5e',
    stripeColor: '#f43f5e',
    progress: 'linear-gradient(to right, #f43f5e, #e11d48)',
    buttonPrimary: 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/25 hover:shadow-rose-600/40',
    stateClass: 'state-rose',
  },
}

const colorMap: Record<VisualState, keyof typeof colorValues> = {
  idle: 'emerald',
  analyzing: 'indigo',
  selecting: 'emerald',
  metadata: 'emerald',
  review: 'indigo',
  creating: 'indigo',
  done: 'emerald',
  error: 'rose',
}

export const resolveTokens = (state: VisualState): VisualTokens => {
  const colorKey = colorMap[state] || 'emerald'
  const c = colorValues[colorKey]

  return {
    bg: c.bg,
    bgBadge: c.bgBadge,
    bgProgress: c.bgBadge,
    text: c.text,
    textBadge: c.textBadge,
    border: c.border,
    borderBadge: c.borderBadge,
    light: c.light,
    dark: c.dark,
    iconColor: c.iconColor,
    stripeColor: c.stripeColor,
    progress: c.progress,
    buttonPrimary: c.buttonPrimary,
    buttonSecondary: 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700',
    buttonDisabled: 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-gray-600 cursor-not-allowed',
    stateClass: c.stateClass,
    motionKey: state,
  }
}