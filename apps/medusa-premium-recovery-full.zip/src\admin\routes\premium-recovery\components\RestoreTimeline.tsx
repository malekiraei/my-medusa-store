// src/admin/routes/premium-recovery/components/RestoreTimeline.tsx
// ============================================================
// Premium Recovery - Restore Timeline
// PREMIUM RECOVERY UI SYSTEM V2 - Product-Grade Design System
// 5-level elevation. Unified card physics. Standard icon hierarchy.
// ============================================================

import React from "react"

// ============================================================
// Types
// ============================================================

export type RestorePoint = {
  id: string
  name: string
  description: string
  business_context: string
  use_case: "manual" | "before_update" | "before_theme_change" | "before_plugin_install"
  files: string[]
  created_at: string
  hash: string
  category?: string
  human_date?: string
  bundle_available?: boolean
  recovery_risk?: string
}

type RestoreTimelineProps = {
  points: RestorePoint[]
  loading: boolean
  onSelect: (point: RestorePoint) => void
  onRestore: (point: RestorePoint) => void
  selectedId?: string
}

// ============================================================
// Helpers
// ============================================================
const getUseCaseLabel = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update": return "به‌روزرسانی"
    case "before_theme_change": return "تغییر قالب"
    case "before_plugin_install": return "نصب افزونه"
    case "manual": return "دستی"
    default: return "اسنپ‌شات"
  }
}

const getUseCaseIcon = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update": return "📦"
    case "before_theme_change": return "🎨"
    case "before_plugin_install": return "🔌"
    case "manual": return "📸"
    default: return "📸"
  }
}

const getRiskColor = (risk: string) => {
  switch (risk) {
    case "low": return "text-emerald-600 dark:text-emerald-400"
    case "medium": return "text-amber-600 dark:text-amber-400"
    case "high": return "text-rose-600 dark:text-rose-400"
    default: return "text-gray-400 dark:text-gray-500"
  }
}

const getRiskLabel = (risk: string) => {
  switch (risk) {
    case "low": return "کم"
    case "medium": return "متوسط"
    case "high": return "بالا"
    default: return "—"
  }
}

const getCategoryTitle = (category: string) => {
  switch (category) {
    case "today": return "امروز"
    case "yesterday": return "دیروز"
    case "last_week": return "این هفته"
    default: return "قدیمی‌تر"
  }
}

// ============================================================
// Design System - Elevation Levels
// ============================================================
const elevation = {
  0: "shadow-none border border-gray-200/40 dark:border-gray-700/30",
  1: "shadow-sm shadow-black/5 dark:shadow-black/20 border border-gray-200/50 dark:border-gray-700/40",
  2: "shadow-md shadow-black/8 dark:shadow-black/30 border border-gray-200/60 dark:border-gray-700/50",
  3: "shadow-lg shadow-black/10 dark:shadow-black/40 border border-gray-200/70 dark:border-gray-700/60",
  4: "shadow-xl shadow-black/12 dark:shadow-black/50 border border-gray-300/80 dark:border-gray-700/70",
  5: "shadow-2xl shadow-black/15 dark:shadow-black/60 border border-gray-300 dark:border-gray-700/80",
}

// ============================================================
// Components
// ============================================================

const CategoryHeader = ({ category }: { category: string }) => {
  const isToday = category === "today"
  return (
    <div className={`
      text-right px-2 mb-2
      ${isToday 
        ? 'text-[13px] font-semibold text-gray-700 dark:text-gray-300' 
        : 'text-[11px] font-medium text-gray-400 dark:text-gray-500'
      }
      uppercase tracking-wider
    `}>
      {getCategoryTitle(category)}
    </div>
  )
}

const EmptyState = () => (
  <div className="
    relative overflow-hidden rounded-2xl
    border border-gray-200/70 dark:border-gray-700/60
    bg-gradient-to-br from-white to-gray-50
    dark:from-gray-900 dark:to-gray-950
    shadow-md shadow-black/5 dark:shadow-black/30
    px-4 py-3
    h-[64px]
    flex items-center justify-center
    transition-all duration-300
    hover:shadow-lg hover:shadow-black/10 dark:hover:shadow-black/40
  ">
    <div className="
      absolute inset-0
      bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.04),transparent_60%)]
    " />

    <div className="relative z-10 flex items-center gap-3">
      <div className="
        w-8 h-8 flex items-center justify-center rounded-lg
        bg-white dark:bg-gray-800
        border border-gray-200 dark:border-gray-700
        shadow-sm shadow-black/5 dark:shadow-black/20
        text-[16px]
        transition-transform duration-300 hover:scale-105
      ">
        📸
      </div>

      <div className="text-[13px] font-medium text-gray-800 dark:text-gray-200 tracking-tight">
        هیچ اسنپ‌شاتی موجود نیست
      </div>
      <div className="text-[11px] text-gray-500 dark:text-gray-400 leading-5">
        پس از ایجاد، باندل قابل دانلود است
      </div>
    </div>
  </div>
)

const LoadingSkeleton = () => (
  <div className="space-y-2">
    {Array.from({ length: 4 }).map((_, i) => (
      <div key={i} className={`grid grid-cols-[28px_1fr_60px_70px] gap-3 px-3 py-2.5 rounded-lg ${elevation[0]}`}>
        <div className="w-7 h-7 bg-gray-200 dark:bg-gray-800 rounded-full animate-pulse" />
        <div className="space-y-1">
          <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4 animate-pulse" />
          <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-1/2 animate-pulse" />
        </div>
        <div className="h-5 bg-gray-200 dark:bg-gray-800 rounded w-10 animate-pulse" />
        <div className="h-5 bg-gray-200 dark:bg-gray-800 rounded w-12 animate-pulse" />
      </div>
    ))}
  </div>
)

const TimelineItem = ({
  point,
  isSelected,
  onSelect,
  onRestore,
}: {
  point: RestorePoint
  isSelected: boolean
  onSelect: (point: RestorePoint) => void
  onRestore: (point: RestorePoint) => void
}) => {
  const riskColor = getRiskColor(point.recovery_risk || "low")
  const riskLabel = getRiskLabel(point.recovery_risk || "low")

  return (
    <div
      onClick={() => onSelect(point)}
      className={`
        grid grid-cols-[28px_1fr_60px_70px] items-center gap-3
        px-3 py-2.5 rounded-lg
        cursor-pointer select-none
        transition-all duration-200
        ${isSelected
          ? `bg-gray-100/70 dark:bg-gray-800/50 ${elevation[1]}`
          : `hover:bg-gray-50/70 dark:hover:bg-gray-800/30 ${elevation[0]} hover:${elevation[1]}`
        }
      `}
    >
      <div className="w-7 h-7 flex items-center justify-center text-[16px] text-gray-700 dark:text-gray-300">
        {getUseCaseIcon(point.use_case)}
      </div>

      <div className="min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[14px] font-medium text-gray-800 dark:text-gray-200 truncate leading-5">
            {point.name}
          </span>
          {point.bundle_available && (
            <span className="text-[9px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 px-1.5 py-0.5 rounded leading-none">
              باندل
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 text-[12.5px] text-gray-500 dark:text-gray-400 leading-5 mt-0.5">
          <span>{getUseCaseLabel(point.use_case)}</span>
          <span className="w-0.5 h-0.5 bg-gray-300 dark:bg-gray-600 rounded-full" />
          <span>{point.human_date || new Date(point.created_at).toLocaleDateString('fa-IR')}</span>
        </div>
      </div>

      <div className={`text-[12px] font-medium ${riskColor} leading-5 text-center`}>
        {riskLabel}
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation()
          onRestore(point)
        }}
        className="
          text-[12px] font-medium
          text-gray-500 dark:text-gray-400
          hover:text-gray-800 dark:hover:text-gray-200
          px-2 py-1 rounded
          transition-colors duration-150
          pointer-events-auto
          leading-5
          text-center
        "
      >
        بازیابی
      </button>
    </div>
  )
}

// ============================================================
// Main Component
// ============================================================
export const RestoreTimeline: React.FC<RestoreTimelineProps> = ({
  points,
  loading,
  onSelect,
  onRestore,
  selectedId,
}) => {
  const groupedPoints = React.useMemo(() => {
    const groups: Record<string, RestorePoint[]> = {}
    points.forEach((p) => {
      const category = p.category || "other"
      if (!groups[category]) groups[category] = []
      groups[category].push(p)
    })
    return groups
  }, [points])

  if (loading && points.length === 0) {
    return <LoadingSkeleton />
  }

  if (points.length === 0) {
    return <EmptyState />
  }

  return (
    <div className="space-y-4">
      {Object.entries(groupedPoints).map(([category, items]) => (
        <div key={category}>
          <CategoryHeader category={category} />
          <div className="space-y-0.5">
            {items.map((point) => (
              <TimelineItem
                key={point.id}
                point={point}
                isSelected={selectedId === point.id}
                onSelect={onSelect}
                onRestore={onRestore}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}