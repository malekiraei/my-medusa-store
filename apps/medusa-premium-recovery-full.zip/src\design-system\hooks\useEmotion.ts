// apps/premium-recovery-plugin/src/design-system/hooks/useEmotion.ts
// ============================================================
// useEmotion Hook - استخراج logic از Component
// ✅ Component فقط از این hook استفاده می‌کند
// ✅ تمام تصمیمات در اینجا گرفته می‌شود
// ============================================================

import { useMemo } from 'react'
import { identity } from '../identity'
import { colors } from '../tokens/colors'

export type EmotionState = 'subtle' | 'moderate' | 'critical'

export type EmotionStyle = {
  // ===== Colors =====
  color: string
  bg: string
  text: string
  border: string
  accent: string
  shadow: string

  // ===== CSS Classes =====
  textClass: string
  bgClass: string
  borderClass: string
  accentClass: string
  badgeClass: string
  actionClass: string

  // ===== Labels =====
  badge: string
  label: string
  description: string
}

type UseEmotionParams = {
  state: EmotionState
  fileCount?: number
}

export const useEmotion = ({ state, fileCount = 0 }: UseEmotionParams): EmotionStyle => {
  return useMemo(() => {
    // ===== دریافت emotion از identity =====
    const emotion = identity.emotion.mapping[state]
    
    // ===== Fallback برای حالت‌های ناشناخته =====
    const colorKey = emotion?.color || 'emerald'
    
    // ===== دریافت semantic colors =====
    const semantic = colors.semantic[colorKey as keyof typeof colors.semantic]
    
    // ===== Fallback اگر semantic وجود نداشت =====
    const fallback = {
      light: '#ecfdf5',
      default: '#10b981',
      dark: '#059669',
      text: '#059669',
      bg: 'rgba(16,185,129,0.08)',
      border: 'rgba(16,185,129,0.35)',
    }

    const safeSemantic = semantic || fallback
    const safeColor = colorKey || 'emerald'

    const isCritical = state === 'critical'
    const isModerate = state === 'moderate'

    return {
      // ===== Colors =====
      color: safeColor,
      bg: safeSemantic.bg,
      text: safeSemantic.text,
      border: safeSemantic.border,
      accent: safeSemantic.default,
      shadow: safeSemantic.default,

      // ===== CSS Classes =====
      textClass: `text-${safeColor}-600 dark:text-${safeColor}-400`,
      bgClass: `bg-${safeColor}-50 dark:bg-${safeColor}-950/20`,
      borderClass: `border-${safeColor}-200/40 dark:border-${safeColor}-800/30`,
      accentClass: `bg-${safeColor}-500 dark:bg-${safeColor}-400`,
      badgeClass: `bg-${safeColor}-500/20 dark:bg-${safeColor}-500/20 text-${safeColor}-700 dark:text-${safeColor}-300`,
      actionClass: `bg-${safeColor}-600 hover:bg-${safeColor}-500 text-white shadow-2xl shadow-${safeColor}-600/35`,

      // ===== Labels =====
      badge: isCritical ? 'فوری' : isModerate ? 'توجه' : 'عادی',
      label: isCritical ? 'سیستم در معرض خطر' : isModerate ? 'بررسی تغییرات' : 'سیستم پایدار',
      description: isCritical
        ? `${fileCount} فایل بدون محافظت شناسایی شده است`
        : isModerate
        ? `${fileCount} فایل تغییر کرده`
        : 'همه سیستم‌ها در وضعیت عادی',
    }
  }, [state, fileCount])
}