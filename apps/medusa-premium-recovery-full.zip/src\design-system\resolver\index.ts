// ============================================================
// RESOLVER - Single Source of Truth for UI Experience
// ✅ Maps state → complete UI spec with zero logic leakage
// ✅ Consumes identity, lock, motion, and tokens
// ============================================================

import { identity } from '../identity'
import { design } from '../lock'
import { resolveMotion } from '../motion'  // ← اصلاح: حذف /motion
import { resolveTokens } from '../tokens/visual'

// ============================================================
// Types
// ============================================================

export type ResolverState =
  | 'idle'
  | 'analyzing'
  | 'selecting'
  | 'metadata'
  | 'review'
  | 'creating'
  | 'done'
  | 'error'

export type ResolverContext = {
  filesCount: number
  selectedCount: number
  name: string
  error: string | null
  stepIndex?: number
}

// ===== Complete UI Spec =====
export type UISpec = {
  // ===== Emotion =====
  emotion: {
    color: string
    badge: string
    badgeClass: string
  }

  // ===== Visual =====
  visual: {
    bg: string
    text: string
    border: string
    iconColor: string
    stripeColor: string
    progress: string
    progressGradient: string
  }

  // ===== Button =====
  button: {
    primary: string
    secondary: string
    disabled: string
  }

  // ===== Motion =====
  motion: {
    duration: number
    easing: string
    key: string
    enter: string
    exit: string
  }

  // ===== Layout =====
  layout: {
    showProgress: boolean
    showBack: boolean
    scrollBody: string
    header: string
    footer: string
  }

  // ===== Narrative =====
  narrative: {
    icon: string
    title: string
    description: string
    nextLabel: string
    backLabel: string
    nextDisabled: boolean
  }

  // ===== Progress (opaque) =====
  progress: string
}

// ============================================================
// 🧠 Resolver
// ============================================================

const layoutMap: Record<ResolverState, { showProgress: boolean; showBack: boolean }> = {
  idle: { showProgress: false, showBack: false },
  analyzing: { showProgress: true, showBack: false },
  selecting: { showProgress: true, showBack: false },
  metadata: { showProgress: true, showBack: true },
  review: { showProgress: true, showBack: true },
  creating: { showProgress: false, showBack: false },
  done: { showProgress: false, showBack: false },
  error: { showProgress: false, showBack: false },
}

const narrativeMap: Record<ResolverState, { icon: string; title: string; description: string; nextLabel: string; backLabel: string; nextDisabled: boolean }> = {
  idle: { icon: '📁', title: 'آماده', description: '', nextLabel: 'شروع', backLabel: '', nextDisabled: true },
  analyzing: { icon: '🔍', title: 'تحلیل تغییرات', description: 'در حال اسکن مخزن...', nextLabel: '...', backLabel: '', nextDisabled: true },
  selecting: { icon: '📁', title: 'انتخاب فایل‌ها', description: 'فایل‌های تغییر یافته', nextLabel: 'ادامه', backLabel: '', nextDisabled: false },
  metadata: { icon: '📝', title: 'اطلاعات اسنپ‌شات', description: 'تکمیل اطلاعات', nextLabel: 'ادامه', backLabel: 'قبلی', nextDisabled: false },
  review: { icon: '✅', title: 'بررسی و ایجاد', description: 'لطفاً اطلاعات را بررسی کنید', nextLabel: 'ایجاد اسنپ‌شات', backLabel: 'قبلی', nextDisabled: false },
  creating: { icon: '⏳', title: 'در حال ایجاد...', description: 'لطفاً چند لحظه صبر کنید', nextLabel: '...', backLabel: '', nextDisabled: true },
  done: { icon: '🎉', title: 'تکمیل شد!', description: 'اسنپ‌شات با موفقیت ایجاد شد', nextLabel: 'بستن', backLabel: '', nextDisabled: false },
  error: { icon: '⚠️', title: 'خطا', description: 'خطای غیرمنتظره رخ داد', nextLabel: 'تلاش مجدد', backLabel: '', nextDisabled: false },
}

export const resolve = (state: ResolverState, ctx: ResolverContext): UISpec => {
  // ===== Emotion =====
  const emotionMap = {
    idle: identity.emotion.mapping.subtle,
    analyzing: identity.emotion.mapping.moderate,
    selecting: identity.emotion.mapping.subtle,
    metadata: identity.emotion.mapping.subtle,
    review: identity.emotion.mapping.critical,
    creating: identity.emotion.mapping.moderate,
    done: identity.emotion.mapping.subtle,
    error: identity.emotion.mapping.critical,
  }

  const emotion = emotionMap[state] || identity.emotion.mapping.subtle
  const color = emotion.color
  const tokens = resolveTokens(state as any)
  const motion = resolveMotion(state as any)
  const layout = layoutMap[state] || layoutMap.idle
  const narrative = narrativeMap[state] || narrativeMap.idle

  // ===== Progress (opaque) =====
  const stepIndex = ['selecting', 'metadata', 'review'].indexOf(state as any)
  const progressValue = state === 'analyzing' ? 0 : state === 'idle' ? 0 : state === 'done' ? 100 : stepIndex >= 0 ? ((stepIndex + 1) / 3) * 100 : 0
  const progress = `${Math.round(progressValue)}%`

  return {
    emotion: {
      color,
      badge: 'عادی',  // ← اصلاح: hardcoded به جای emotion.badge
      badgeClass: `badge-${color}`,  // ← اصلاح
    },
    visual: {
      bg: tokens.bg,
      text: tokens.text,
      border: tokens.border,
      iconColor: tokens.iconColor,
      stripeColor: tokens.stripeColor,
      progress: tokens.progress,
      progressGradient: tokens.progress,
    },
    button: {
      primary: tokens.buttonPrimary,
      secondary: tokens.buttonSecondary,
      disabled: tokens.buttonDisabled,
    },
    motion: {
      duration: motion.duration,
      easing: motion.easing,
      key: state,
      enter: motion.enter,
      exit: motion.exit,
    },
    layout: {
      showProgress: layout.showProgress,
      showBack: layout.showBack,
      scrollBody: design.layout.scroll.body,
      header: design.layout.scroll.header,
      footer: design.layout.scroll.footer,
    },
    narrative,
    progress,
  }
}