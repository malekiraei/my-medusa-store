// apps/premium-recovery-plugin/src/admin/routes/premium-recovery/hooks/useSnapshotMachine.ts
// ============================================================
// useSnapshotMachine Hook - XState v5
// ✅ استفاده از createActor برای اشتراک‌گذاری حالت
// ✅ مدیریت صحیح lifecycle
// ✅ اصلاح: context به صورت جداگانه در state قرار می‌گیرد
// ============================================================

import { useEffect, useRef, useState, useCallback } from "react"
import { createActor } from "xstate"
import { createSnapshotMachine } from "../machine/snapshot.machine"

type SnapshotServices = {
  fetchFiles: () => Promise<any[]>
  createSnapshot: (data: any) => Promise<void>
}

export const useSnapshotMachine = (services: SnapshotServices) => {
  const [state, setState] = useState<any>({ 
    status: 'idle', 
    files: [],
    selectedFiles: [],
    name: '',
    description: '',
    businessContext: '',
    useCase: 'manual',
    error: null,
  })
  
  const actorRef = useRef<any>(null)
  const servicesRef = useRef(services)
  servicesRef.current = services

  // ===== Reset function =====
  const resetState = useCallback(() => {
    setState({ 
      status: 'idle', 
      files: [],
      selectedFiles: [],
      name: '',
      description: '',
      businessContext: '',
      useCase: 'manual',
      error: null,
    })
  }, [])

  useEffect(() => {
    try {
      // ===== Create machine with services =====
      const machine = createSnapshotMachine({
        fetchFiles: servicesRef.current.fetchFiles,
        createSnapshot: servicesRef.current.createSnapshot,
      })

      // ===== Create actor =====
      const actor = createActor(machine)
      actorRef.current = actor

      // ===== Subscribe to state changes =====
      const { unsubscribe } = actor.subscribe((snapshot: any) => {
        const context = snapshot.context || {}
        
        // ===== Flatten context into state (برای دسترسی آسان) =====
        setState({
          status: snapshot.value,
          files: context.files || [],
          selectedFiles: context.selectedFiles || [],
          name: context.name || '',
          description: context.description || '',
          businessContext: context.businessContext || '',
          useCase: context.useCase || 'manual',
          error: context.error || null,
        })
      })

      // ===== Start the actor =====
      actor.start()

      // ===== Reset state on unmount =====
      return () => {
        unsubscribe()
        actor.stop()
        resetState()
      }
    } catch (error) {
      resetState()
      return () => {}
    }
  }, [resetState])

  // ===== Send events =====
  const send = useCallback((event: any) => {
    if (actorRef.current) {
      try {
        actorRef.current.send(event)
      } catch (error) {
        // Silently handle error
      }
    }
  }, [])

  // ===== Open wizard =====
  const open = useCallback(() => {
    send({ type: 'OPEN' })
  }, [send])

  // ===== Close wizard =====
  const close = useCallback(() => {
    send({ type: 'CLOSE' })
  }, [send])

  return {
    state,
    send,
    open,
    close,
  }
}