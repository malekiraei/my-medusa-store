// apps/premium-recovery-plugin/src/admin/routes/premium-recovery/views/snapshot/MetadataView.tsx
// ============================================================
// MetadataView - UNIFIED VIEW
// ✅ Same header pattern as other views
// ✅ Same padding system
// ✅ Same density
// ============================================================

import React from "react"
import { ViewHeader } from "./ViewHeader"

export type SnapshotUseCase = "manual" | "before_update" | "before_theme_change" | "before_plugin_install"

export type MetadataViewProps = {
  snapshotName: string
  snapshotDescription: string
  snapshotBusinessContext: string
  snapshotUseCase: SnapshotUseCase
  selectedCount: number
  onSetName: (name: string) => void
  onSetDescription: (description: string) => void
  onSetBusinessContext: (context: string) => void
  onSetUseCase: (useCase: SnapshotUseCase) => void
}

const useCaseOptions = [
  { value: "manual", label: "دستی (عمومی)" },
  { value: "before_update", label: "به‌روزرسانی محصول" },
  { value: "before_theme_change", label: "تغییر قالب" },
  { value: "before_plugin_install", label: "نصب افزونه" },
]

export const MetadataView: React.FC<MetadataViewProps> = ({
  snapshotName,
  snapshotDescription,
  snapshotBusinessContext,
  snapshotUseCase,
  selectedCount,
  onSetName,
  onSetDescription,
  onSetBusinessContext,
  onSetUseCase,
}) => {
  return (
    <div className="flex flex-col h-full">
      {/* ===== Unified Header ===== */}
      <ViewHeader
        icon={
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
        }
        iconColor="#10b981"
        title="اطلاعات اسنپ‌شات"
        subtitle={`${selectedCount} فایل انتخاب شده`}
      />

      {/* ===== Content ===== */}
      <div className="flex-1 overflow-y-auto py-3 space-y-3">
        {/* Name */}
        <div>
          <label className="block text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
            نام <span className="text-rose-500">*</span>
          </label>
          <input
            type="text"
            placeholder="مثلاً: قبل از به‌روزرسانی"
            value={snapshotName}
            onChange={(e) => onSetName(e.target.value)}
            className="w-full px-3 py-2 text-[13px] border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 dark:bg-gray-800/50 dark:text-gray-100 transition-all duration-200"
            autoFocus
          />
          {!snapshotName.trim() && (
            <p className="text-[10px] text-rose-500 mt-1">وارد کردن نام الزامی است</p>
          )}
        </div>

        {/* Use Case */}
        <div>
          <label className="block text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
            زمینه کاری
          </label>
          <select
            value={snapshotUseCase}
            onChange={(e) =>
              onSetUseCase(e.target.value as SnapshotUseCase)
            }
            className="w-full px-3 py-2 text-[13px] border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 dark:bg-gray-800/50 dark:text-gray-100 transition-all duration-200"
          >
            {useCaseOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {/* Business Context */}
        <div>
          <label className="block text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
            زمینه کسب‌وکاری
          </label>
          <textarea
            placeholder="مثلاً: آماده‌سازی برای انتشار"
            value={snapshotBusinessContext}
            onChange={(e) => onSetBusinessContext(e.target.value)}
            rows={2}
            className="w-full px-3 py-2 text-[13px] border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 dark:bg-gray-800/50 dark:text-gray-100 transition-all duration-200 resize-none"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-[11px] font-medium text-gray-700 dark:text-gray-300 mb-1">
            توضیحات <span className="text-gray-400">(اختیاری)</span>
          </label>
          <textarea
            placeholder="توضیحات بیشتر..."
            value={snapshotDescription}
            onChange={(e) => onSetDescription(e.target.value)}
            rows={2}
            className="w-full px-3 py-2 text-[13px] border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 dark:bg-gray-800/50 dark:text-gray-100 transition-all duration-200 resize-none"
          />
        </div>

        {/* Selected Files Count */}
        <div className="bg-gray-50/60 dark:bg-gray-800/30 rounded-lg px-4 py-3">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-medium text-gray-600 dark:text-gray-400">
              فایل‌های انتخاب شده
            </span>
            <span className="text-[15px] font-bold text-indigo-600 dark:text-indigo-400">
              {selectedCount}
            </span>
          </div>
        </div>

        {/* Helper Message */}
        <div className="flex items-center gap-2 p-3 rounded-lg bg-indigo-50/40 dark:bg-indigo-950/10 border border-indigo-200/40 dark:border-indigo-800/30">
          <svg className="w-4 h-4 text-indigo-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-[12px] text-indigo-500 dark:text-indigo-400">
            {!snapshotName.trim()
              ? 'لطفاً یک نام برای اسنپ‌شات وارد کنید'
              : 'همه اطلاعات وارد شده است. برای ادامه کلیک کنید.'}
          </p>
        </div>
      </div>
    </div>
  )
}

export default MetadataView