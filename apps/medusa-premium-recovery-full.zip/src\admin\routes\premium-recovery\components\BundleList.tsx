// ============================================================
// Premium Recovery - Bundle List (FIXED & STABLE)
// ============================================================

import React, { useState } from "react"

// ============================================================
// Types (FIXED - no duplication conflict)
// ============================================================

export type BundleInfo = {
  id: string
  name: string
  created_at: string
  created_by?: string
  size: string

  restore_ready?: boolean
  verified?: boolean
  portable?: boolean
}

type BundleListProps = {
  bundles: BundleInfo[]
  loading: boolean
  onDownload?: (bundle: BundleInfo) => void
  onDelete?: (bundle: BundleInfo) => void
  density?: "compact" | "normal" | "comfortable"
}

type BadgePriority = "primary" | "secondary" | "tertiary"

// ============================================================
// Helpers
// ============================================================

const formatDate = (dateStr: string) => {
  try {
    return new Date(dateStr).toLocaleDateString("fa-IR")
  } catch {
    return dateStr
  }
}

// ============================================================
// Badge Engine
// ============================================================

interface BadgeConfig {
  key: keyof BundleInfo
  label: string
  priority: BadgePriority
  color: string
  bg: string
}

const badgeConfigs: BadgeConfig[] = [
  {
    key: "restore_ready",
    label: "بازیابی",
    priority: "primary",
    color: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-50 dark:bg-emerald-950/40",
  },
  {
    key: "verified",
    label: "تأیید",
    priority: "secondary",
    color: "text-blue-700 dark:text-blue-300",
    bg: "bg-blue-50 dark:bg-blue-950/40",
  },
  {
    key: "portable",
    label: "قابل حمل",
    priority: "tertiary",
    color: "text-purple-700 dark:text-purple-300",
    bg: "bg-purple-50 dark:bg-purple-950/40",
  },
]

const getActiveBadges = (bundle: BundleInfo): BadgeConfig[] => {
  return badgeConfigs
    .filter((b) => Boolean(bundle[b.key]))
    .sort((a, b) => {
      const map = { primary: 0, secondary: 1, tertiary: 2 }
      return map[a.priority] - map[b.priority]
    })
}

// ============================================================
// Empty State
// ============================================================

const EmptyState = () => (
  <div className="rounded-2xl border px-6 py-10 flex flex-col items-center justify-center text-center">
    <div className="text-2xl mb-2">📦</div>
    <div className="text-sm font-medium">هیچ باندلی موجود نیست</div>
    <div className="text-xs text-gray-500 mt-1">
      پس از ایجاد اسنپ‌شات، باندل قابل دانلود خواهد بود
    </div>
  </div>
)

// ============================================================
// Loading
// ============================================================

const LoadingSkeleton = () => (
  <div className="space-y-2">
    {Array.from({ length: 3 }).map((_, i) => (
      <div key={i} className="h-16 rounded-2xl bg-gray-100 animate-pulse" />
    ))}
  </div>
)

// ============================================================
// Item
// ============================================================

const BundleItem = ({
  bundle,
  onDownload,
  onDelete,
}: {
  bundle: BundleInfo
  onDownload?: (bundle: BundleInfo) => void
  onDelete?: (bundle: BundleInfo) => void
}) => {
  const activeBadges = getActiveBadges(bundle)

  return (
    <div className="flex items-center justify-between p-3 border rounded-2xl">
      <div>
        <div className="flex gap-2 items-center">
          <span className="font-medium">{bundle.name}</span>

          {activeBadges.map((b) => (
            <span key={b.key} className={`text-xs px-2 py-0.5 rounded ${b.bg} ${b.color}`}>
              {b.label}
            </span>
          ))}
        </div>

        <div className="text-xs text-gray-500 mt-1">
          {formatDate(bundle.created_at)} • {bundle.size}
        </div>
      </div>

      <div className="flex gap-2">
        {onDownload && (
          <button onClick={() => onDownload(bundle)}>دانلود</button>
        )}
        {onDelete && (
          <button onClick={() => onDelete(bundle)}>حذف</button>
        )}
      </div>
    </div>
  )
}

// ============================================================
// Main
// ============================================================

export const BundleList: React.FC<BundleListProps> = ({
  bundles,
  loading,
  onDownload,
  onDelete,
}) => {
  if (loading) return <LoadingSkeleton />
  if (!bundles.length) return <EmptyState />

  return (
    <div className="space-y-2">
      {bundles.map((b) => (
        <BundleItem
          key={b.id}
          bundle={b}
          onDownload={onDownload}
          onDelete={onDelete}
        />
      ))}
    </div>
  )
}