import React, { useState } from "react"

// ============================================================
// Types
// ============================================================

export type RestorePoint = {
  id: string
  name: string
  description: string
  business_context: string
  use_case: "manual" | "before_update" | "before_theme_change" | "before_plugin_install"
  files: string[]
  files_count?: number
  created_at: string
  hash: string
  recovery_risk?: "low" | "medium" | "high"
  bundle_available?: boolean
}

type RestoreModalProps = {
  isOpen: boolean
  point: RestorePoint | null
  onClose: () => void
  onConfirm: (point: RestorePoint) => Promise<void>
}

// ============================================================
// Helpers
// ============================================================

const getUseCaseLabel = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update":
      return "قبل از به‌روزرسانی محصول"
    case "before_theme_change":
      return "قبل از تغییر قالب"
    case "before_plugin_install":
      return "قبل از نصب افزونه"
    case "manual":
      return "اسنپ‌شات دستی"
    default:
      return "اسنپ‌شات"
  }
}

const getUseCaseIcon = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update":
      return "📦"
    case "before_theme_change":
      return "🎨"
    case "before_plugin_install":
      return "🔌"
    case "manual":
      return "📸"
    default:
      return "📸"
  }
}

const getRiskIcon = (risk: RestorePoint["recovery_risk"]) => {
  switch (risk) {
    case "low":
      return "🛡️"
    case "medium":
      return "⚠️"
    case "high":
      return "🔴"
    default:
      return "⚪"
  }
}

const getRiskText = (risk: RestorePoint["recovery_risk"]) => {
  switch (risk) {
    case "low":
      return "کم"
    case "medium":
      return "متوسط"
    case "high":
      return "بالا"
    default:
      return "نامشخص"
  }
}

// ============================================================
// Component
// ============================================================

export const RestoreModal: React.FC<RestoreModalProps> = ({
  isOpen,
  point,
  onClose,
  onConfirm,
}) => {
  const [confirmInput, setConfirmInput] = useState("")
  const [isRestoring, setIsRestoring] = useState(false)

  // ✅ safe guard
  if (!isOpen || !point) return null

  const handleConfirm = async () => {
    if (confirmInput !== "RESTORE") return

    try {
      setIsRestoring(true)
      await onConfirm(point)
      setConfirmInput("")
      onClose()
    } catch (error) {
      // Error handled by parent
    } finally {
      setIsRestoring(false)
    }
  }

  const handleClose = () => {
    setConfirmInput("")
    onClose()
  }

  const fileCount = point.files?.length || point.files_count || 0

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">

        {/* Header */}
        <div className="px-6 py-4 border-b bg-gradient-to-r from-amber-50 to-orange-50">
          <span className="text-sm font-bold text-amber-800">
            ⚠️ بازیابی ایمن
          </span>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          <h3 className="text-lg font-bold text-slate-800 text-center">
            بازیابی "{point.name}"
          </h3>

          <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span>فایل‌ها</span>
              <span>{fileCount}</span>
            </div>

            <div className="flex justify-between">
              <span>نوع</span>
              <span>
                {getUseCaseLabel(point.use_case)} {getUseCaseIcon(point.use_case)}
              </span>
            </div>

            <div className="flex justify-between">
              <span>ریسک</span>
              <span>
                {getRiskIcon(point.recovery_risk)} {getRiskText(point.recovery_risk)}
              </span>
            </div>
          </div>

          <input
            value={confirmInput}
            onChange={(e) => setConfirmInput(e.target.value)}
            placeholder="RESTORE"
            className="w-full text-center font-mono border rounded-lg px-3 py-2"
          />
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t flex gap-3 bg-slate-50">
          <button
            onClick={handleClose}
            disabled={isRestoring}
            className="flex-1 border rounded-lg py-2"
          >
            انصراف
          </button>

          <button
            onClick={handleConfirm}
            disabled={confirmInput !== "RESTORE" || isRestoring}
            className="flex-1 bg-amber-600 text-white rounded-lg py-2 disabled:opacity-50"
          >
            {isRestoring ? "..." : "تأیید"}
          </button>
        </div>

      </div>
    </div>
  )
}