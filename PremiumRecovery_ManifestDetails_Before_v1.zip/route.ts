import { createHash, randomUUID } from "node:crypto"
import { execFile } from "node:child_process"
import {
  copyFile,
  mkdir,
  readdir,
  readFile,
  stat,
  writeFile,
} from "node:fs/promises"
import { existsSync } from "node:fs"
import { extname, isAbsolute, join, relative, resolve } from "node:path"
import { promisify } from "node:util"

import { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"

const execFileAsync = promisify(execFile)

type SnapshotFileManifest = {
  path: string
  status: "captured" | "missing"
  snapshot_path: string | null
  size: number
  sha256: string | null
  missing_reason: string | null
}

type RestorePointManifest = {
  id: string
  hash: string
  name: string
  description: string
  business_context: string
  use_case: string
  created_at: string
  files: SnapshotFileManifest[]
  files_count: number
  captured_files_count: number
  missing_files_count: number
}

type RestorePointSummary = Omit<RestorePointManifest, "files"> & {
  files: string[]
  storage_path: string
}

const RECOVERY_ROOT = join(
  process.cwd(),
  ".premium-recovery",
  "restore-points"
)

const jsonResponse = (
  res: MedusaResponse,
  statusCode: number,
  body: Record<string, unknown>
) => {
  res.status(statusCode).json(body)
}

const sha256 = (value: string | Buffer) => {
  return createHash("sha256").update(value).digest("hex")
}

const getRequestBody = async (req: MedusaRequest) => {
  const request = req as MedusaRequest & {
    body?: unknown
    json?: () => Promise<unknown>
  }

  if (request.body && typeof request.body === "object") {
    return request.body as Record<string, unknown>
  }

  if (typeof request.json === "function") {
    const body = await request.json()

    if (body && typeof body === "object") {
      return body as Record<string, unknown>
    }
  }

  return {}
}

const getWorkspaceRoot = async () => {
  try {
    const { stdout } = await execFileAsync(
      "git",
      ["rev-parse", "--show-toplevel"],
      {
        cwd: process.cwd(),
        windowsHide: true,
      }
    )

    return resolve(String(stdout).trim())
  } catch {
    return null
  }
}

const isInsideWorkspace = (workspaceRoot: string, absolutePath: string) => {
  const relativePath = relative(workspaceRoot, absolutePath)

  return Boolean(relativePath) &&
    !relativePath.startsWith("..") &&
    !isAbsolute(relativePath)
}

const normalizeSelectedPath = (
  workspaceRoot: string,
  selectedPath: string
) => {
  const normalizedPath = selectedPath.replace(/\\/g, "/").trim()

  if (!normalizedPath) {
    throw new Error("Every file path must be a non-empty string")
  }

  const absolutePath = resolve(workspaceRoot, normalizedPath)

  if (!isInsideWorkspace(workspaceRoot, absolutePath)) {
    throw new Error(`File path escapes workspace root: ${selectedPath}`)
  }

  return {
    relativePath: relative(workspaceRoot, absolutePath).replace(/\\/g, "/"),
    absolutePath,
  }
}

const getSnapshotFileName = (relativePath: string) => {
  const extension = extname(relativePath)

  return `${sha256(relativePath)}${extension}`
}

const summarizeManifest = (
  manifest: RestorePointManifest,
  storagePath: string
): RestorePointSummary => {
  return {
    id: manifest.id,
    hash: manifest.hash,
    name: manifest.name,
    description: manifest.description,
    business_context: manifest.business_context,
    use_case: manifest.use_case,
    created_at: manifest.created_at,
    files: manifest.files.map((file) => file.path),
    files_count: manifest.files_count,
    captured_files_count: manifest.captured_files_count,
    missing_files_count: manifest.missing_files_count,
    storage_path: storagePath,
  }
}

const readManifest = async (restorePointDirectory: string) => {
  const manifestPath = join(restorePointDirectory, "manifest.json")
  const manifest = JSON.parse(
    await readFile(manifestPath, "utf8")
  ) as RestorePointManifest

  return summarizeManifest(
    manifest,
    relative(process.cwd(), restorePointDirectory).replace(/\\/g, "/")
  )
}

const getRestorePoints = async () => {
  if (!existsSync(RECOVERY_ROOT)) {
    return []
  }

  const entries = await readdir(RECOVERY_ROOT, { withFileTypes: true })
  const restorePoints = await Promise.all(
    entries
      .filter((entry) => entry.isDirectory())
      .map(async (entry) => {
        try {
          return await readManifest(join(RECOVERY_ROOT, entry.name))
        } catch {
          return null
        }
      })
  )

  return restorePoints
    .filter((point): point is RestorePointSummary => Boolean(point))
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
}

const createRestorePoint = async (body: Record<string, unknown>) => {
  const name = String(body.name ?? "").trim()
  const description = String(body.description ?? "").trim()
  const businessContext = String(body.business_context ?? "").trim()
  const useCase = String(body.use_case ?? "manual").trim() || "manual"
  const files = body.files

  if (!name) {
    return {
      error: "Snapshot name is required",
      statusCode: 400,
    }
  }

  if (!Array.isArray(files) || files.length === 0) {
    return {
      error: "At least one selected file is required",
      statusCode: 400,
    }
  }

  if (!files.every((file) => typeof file === "string")) {
    return {
      error: "Every selected file path must be a string",
      statusCode: 400,
    }
  }

  const workspaceRoot = await getWorkspaceRoot()

  if (!workspaceRoot) {
    return {
      error: "Git workspace root could not be resolved",
      statusCode: 503,
    }
  }

  let normalizedFiles: Array<{ relativePath: string; absolutePath: string }>

  try {
    normalizedFiles = files.map((file) =>
      normalizeSelectedPath(workspaceRoot, file)
    )
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : "Invalid file path",
      statusCode: 400,
    }
  }

  const id = randomUUID()
  const createdAt = new Date().toISOString()
  const restorePointDirectory = join(RECOVERY_ROOT, id)
  const filesDirectory = join(restorePointDirectory, "files")

  await mkdir(filesDirectory, { recursive: true })

  const capturedFiles: SnapshotFileManifest[] = []

  for (const file of normalizedFiles) {
    const snapshotFileName = getSnapshotFileName(file.relativePath)
    const snapshotRelativePath = `files/${snapshotFileName}`
    const snapshotAbsolutePath = join(filesDirectory, snapshotFileName)

    try {
      const fileStat = await stat(file.absolutePath)

      if (!fileStat.isFile()) {
        capturedFiles.push({
          path: file.relativePath,
          status: "missing",
          snapshot_path: null,
          size: 0,
          sha256: null,
          missing_reason: "File did not exist at snapshot time",
        })
        continue
      }

      await copyFile(file.absolutePath, snapshotAbsolutePath)

      const copiedContent = await readFile(snapshotAbsolutePath)

      capturedFiles.push({
        path: file.relativePath,
        status: "captured",
        snapshot_path: snapshotRelativePath,
        size: copiedContent.byteLength,
        sha256: sha256(copiedContent),
        missing_reason: null,
      })
    } catch {
      capturedFiles.push({
        path: file.relativePath,
        status: "missing",
        snapshot_path: null,
        size: 0,
        sha256: null,
        missing_reason: "File did not exist at snapshot time",
      })
    }
  }

  const manifestWithoutHash = {
    id,
    name,
    description,
    business_context: businessContext,
    use_case: useCase,
    created_at: createdAt,
    files: capturedFiles,
    files_count: capturedFiles.length,
    captured_files_count: capturedFiles.filter(
      (file) => file.status === "captured"
    ).length,
    missing_files_count: capturedFiles.filter(
      (file) => file.status === "missing"
    ).length,
  }

  const manifest: RestorePointManifest = {
    ...manifestWithoutHash,
    hash: sha256(JSON.stringify(manifestWithoutHash)),
  }

  await writeFile(
    join(restorePointDirectory, "manifest.json"),
    JSON.stringify(manifest, null, 2),
    "utf8"
  )

  return {
    restorePoint: summarizeManifest(
      manifest,
      relative(process.cwd(), restorePointDirectory).replace(/\\/g, "/")
    ),
    statusCode: 201,
  }
}

export async function GET(
  req: MedusaRequest,
  res: MedusaResponse
) {
  res.json({
    restore_points: await getRestorePoints(),
  })
}

export async function POST(
  req: MedusaRequest,
  res: MedusaResponse
) {
  try {
    const result = await createRestorePoint(await getRequestBody(req))

    if ("error" in result) {
      jsonResponse(res, result.statusCode, {
        message: result.error,
      })
      return
    }

    jsonResponse(res, result.statusCode, {
      restore_point: result.restorePoint,
    })
  } catch (error) {
    jsonResponse(res, 500, {
      message:
        error instanceof Error
          ? error.message
          : "Failed to create restore point",
    })
  }
}
