import { Badge, Container, Heading, Text } from "../../../../ui/vendor"
import { Calendar } from "../../../../ui/vendor/icons"
import { Database } from "../../../../ui/vendor/lucide"

export type RestorePoint = {
  id: string
  name: string
  description?: string
  business_context?: string
  use_case?: "manual" | "before_update" | "before_theme_change" | "before_plugin_install"
  files: string[]
  files_count?: number
  captured_files_count?: number
  missing_files_count?: number
  created_at: string
  hash?: string
}

type RestoreTimelineProps = {
  points: RestorePoint[]
  loading: boolean
}

const getUseCaseLabel = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update":
      return "Before update"
    case "before_theme_change":
      return "Before theme change"
    case "before_plugin_install":
      return "Before plugin install"
    case "manual":
      return "Manual"
    default:
      return "Not available"
  }
}

const formatDate = (value: string) => {
  const date = new Date(value)

  if (Number.isNaN(date.getTime())) {
    return "Not available"
  }

  return date.toLocaleString()
}

const getFileCount = (point: RestorePoint) => {
  return typeof point.files_count === "number"
    ? point.files_count
    : point.files.length
}

const EmptyState = () => {
  return (
    <Container className="p-0">
      <div className="flex items-center justify-center px-6 py-8">
        <div className="flex flex-col items-center gap-y-2 text-center">
          <div className="flex items-center justify-center rounded-full border border-ui-border-base bg-ui-bg-subtle p-3 shadow-elevation-card">
            <Database className="text-ui-fg-subtle" />
          </div>

          <Heading level="h3">No snapshot records yet</Heading>

          <Text size="small" className="max-w-md text-ui-fg-muted">
            File-backed snapshot records created by the snapshot wizard will appear here.
          </Text>
        </div>
      </div>
    </Container>
  )
}

const LoadingState = () => {
  return (
    <Container className="p-0">
      <div className="px-6 py-6">
        <Text size="small" className="text-ui-fg-muted">
          Loading snapshot records...
        </Text>
      </div>
    </Container>
  )
}

const TimelineItem = ({ point }: { point: RestorePoint }) => {
  const fileCount = getFileCount(point)

  return (
    <div className="flex flex-col gap-y-3 px-6 py-4 md:flex-row md:items-start md:justify-between">
      <div className="flex min-w-0 items-start gap-x-3">
        <div className="flex items-center justify-center rounded-full border border-ui-border-base bg-ui-bg-subtle p-2 shadow-elevation-card">
          <Database className="text-ui-fg-subtle" />
        </div>

        <div className="flex min-w-0 flex-col gap-y-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <Heading level="h3">{point.name || "Untitled snapshot record"}</Heading>
            <Badge color="blue">Snapshot</Badge>
          </div>

          {(point.description || point.business_context) && (
            <Text size="small" className="text-ui-fg-muted">
              {point.description || point.business_context}
            </Text>
          )}

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <div className="flex items-center gap-x-1">
              <Calendar className="text-ui-fg-subtle" />
              <Text size="small" className="text-ui-fg-muted">
                {formatDate(point.created_at)}
              </Text>
            </div>

            <Text size="small" className="text-ui-fg-muted">
              {getUseCaseLabel(point.use_case)}
            </Text>

            <Text size="small" className="text-ui-fg-muted">
              {fileCount} files
            </Text>

            {typeof point.captured_files_count === "number" && (
              <Text size="small" className="text-ui-fg-muted">
                {point.captured_files_count} captured
              </Text>
            )}

            {typeof point.missing_files_count === "number" && (
              <Text size="small" className="text-ui-fg-muted">
                {point.missing_files_count} missing
              </Text>
            )}
          </div>
        </div>
      </div>

      {point.hash && (
        <Text size="small" className="break-all text-ui-fg-muted md:max-w-xs md:text-right">
          {point.hash}
        </Text>
      )}
    </div>
  )
}

export const RestoreTimeline = ({
  points,
  loading,
}: RestoreTimelineProps) => {
  if (loading && points.length === 0) {
    return <LoadingState />
  }

  if (points.length === 0) {
    return <EmptyState />
  }

  return (
    <Container className="overflow-hidden p-0">
      <div className="border-b border-ui-border-base px-6 py-4">
        <Heading level="h2">Snapshot Records</Heading>
        <Text size="small" className="mt-1 text-ui-fg-muted">
          Filesystem-backed snapshots created from selected workspace files.
        </Text>
      </div>

      <div className="divide-y divide-ui-border-base">
        {points.map((point) => (
          <TimelineItem key={point.id} point={point} />
        ))}
      </div>
    </Container>
  )
}

export default RestoreTimeline
