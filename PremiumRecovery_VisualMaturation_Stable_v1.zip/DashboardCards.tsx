import { useState, type ReactNode } from "react"

import { identityClasses, resolvePRStatus, type PRMetricIdentity, type PRMetricTone, type PRSystemStatus } from "../../../../ui/adapters/status"
import { PRMetricCard, PRMetricGrid, type PRMetricIcon, type PRMetricTrendPoint } from "../../../../ui/components/metric"
import {
  Archive,
  Button,
  Container,
  DatabaseBackup,
  FileClock,
  Gauge,
  Heading,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Text,
  clsx,
} from "../../../../ui/vendor"

export type DashboardMetric = {
  title: string
  value: ReactNode
  description?: ReactNode
  badge?: ReactNode
  footer?: ReactNode
  timestamp?: ReactNode
  action?: ReactNode
  actionLabel?: ReactNode
  onAction?: () => void
  tone?: PRMetricTone
  identity?: PRMetricIdentity
  icon?: PRMetricIcon
  trend?: PRMetricTrendPoint[]
  trendVariant?: "area" | "line"
  progress?: number
}

export type DashboardCardsProps = {
  status?: PRSystemStatus
  statusLabel?: string
  statusDescription?: string
  lastSyncText?: ReactNode
  changedFiles?: number | null
  restorePoints?: number | null
  bundles?: number | null
  onCreateSnapshot?: () => void
  onManualSync?: () => void | Promise<void>
  onQuickCheck?: () => void | Promise<void>
  createSnapshotLabel?: ReactNode
  manualSyncLabel?: ReactNode
  quickCheckLabel?: ReactNode
  metrics?: DashboardMetric[]
  className?: string
}

export const DashboardCards = ({
  status = "unknown",
  statusLabel,
  statusDescription,
  lastSyncText = "Status will update after the next check",
  changedFiles,
  restorePoints,
  bundles,
  onCreateSnapshot,
  onManualSync,
  onQuickCheck,
  createSnapshotLabel = "Create Snapshot",
  manualSyncLabel = "Manual Sync",
  quickCheckLabel = "Quick Check",
  metrics,
  className,
}: DashboardCardsProps) => {
  const [isQuickCheckPending, setIsQuickCheckPending] = useState(false)
  const descriptor = resolvePRStatus(status)
  const systemIdentityClass = identityClasses.system
  const StatusIcon = descriptor.icon
  const resolvedStatusLabel = statusLabel ?? descriptor.label
  const resolvedStatusDescription = statusDescription ?? descriptor.description
  const hasChangedFiles = typeof changedFiles === "number"
  const hasChanges = hasChangedFiles && changedFiles > 0
  const hasRestorePoints = typeof restorePoints === "number"
  const hasBundles = typeof bundles === "number"

  const defaultMetrics: DashboardMetric[] = [
    {
      title: "System Status",
      value: resolvedStatusLabel,
      description: resolvedStatusDescription,
      badge: descriptor.tone === "success" ? "Safe" : descriptor.tone,
      tone: descriptor.tone,
      identity: "system",
      icon: ShieldCheck,
    },
    {
      title: "Changed Files",
      value: hasChangedFiles ? changedFiles : "Unknown",
      description: hasChangedFiles
        ? hasChanges
          ? "Files are waiting for a recovery snapshot."
          : "No changed files reported by the recovery contract."
        : "Changed file data is not available.",
      badge: hasChangedFiles ? hasChanges ? "Review" : "Clean" : "Unknown",
      tone: hasChangedFiles ? hasChanges ? "warning" : "success" : "neutral",
      identity: "changes",
      icon: FileClock,
      trendVariant: "line",
    },
    {
      title: "Restore Points",
      value: hasRestorePoints ? restorePoints : "Unknown",
      description: hasRestorePoints
        ? restorePoints > 0
          ? "Restore points are available for rollback."
          : "No restore points are available yet."
        : "Restore point data is not available.",
      badge: hasRestorePoints ? restorePoints > 0 ? "Ready" : "Empty" : "Unknown",
      tone: hasRestorePoints ? restorePoints > 0 ? "info" : "neutral" : "neutral",
      identity: "restore",
      icon: DatabaseBackup,
    },
    {
      title: "Bundles",
      value: hasBundles ? bundles : "Unknown",
      description: hasBundles
        ? bundles > 0
          ? "Recovery bundles are available."
          : "No recovery bundle has been created yet."
        : "Bundle data is not available.",
      badge: hasBundles ? bundles > 0 ? "Available" : "None" : "Unknown",
      tone: hasBundles ? bundles > 0 ? "info" : "neutral" : "neutral",
      identity: "bundles",
      icon: Archive,
    },
  ]

  const visibleMetrics = metrics?.length ? metrics : defaultMetrics
  const quickCheckAction = onManualSync ?? onQuickCheck
  const quickCheckContent = onManualSync ? manualSyncLabel : quickCheckLabel

  const handleQuickCheck = async () => {
    if (!quickCheckAction || isQuickCheckPending) {
      return
    }

    try {
      const result = quickCheckAction()

      if (result && typeof (result as Promise<void>).then === "function") {
        setIsQuickCheckPending(true)
        await result
      }
    } finally {
      setIsQuickCheckPending(false)
    }
  }

  return (
    <div className={clsx("space-y-8", className)}>
      <Container className="relative overflow-hidden rounded-2xl border border-ui-border-base bg-ui-bg-base p-0 shadow-elevation-card-rest">
        <div className="absolute inset-0 bg-gradient-to-br from-ui-bg-subtle via-transparent to-ui-bg-base" />
        <div className={clsx("absolute inset-y-4 start-0 w-1 rounded-e-full opacity-70", systemIdentityClass.accent[descriptor.tone])} />
        <div className="absolute -top-16 end-8 size-44 rounded-full bg-ui-bg-subtle blur-3xl" />

        <div className="relative grid gap-5 p-4 sm:p-5 lg:grid-cols-[1fr_auto] lg:items-center lg:p-6">
          <div className="flex min-w-0 items-start gap-4">
            <div className="relative flex size-14 shrink-0 items-center justify-center rounded-2xl bg-ui-bg-subtle text-ui-fg-base shadow-elevation-card-rest ring-1 ring-ui-border-base sm:size-16">
              <Sparkles className="size-6 sm:size-7" strokeWidth={2.1} />
            </div>

            <div className="min-w-0 text-start">
              <div className="mb-1 inline-flex items-center gap-2 rounded-full border border-ui-border-base bg-ui-bg-subtle px-2.5 py-1 text-[11px] font-medium text-ui-fg-muted">
                <Gauge className="size-3.5" strokeWidth={2.1} />
                Premium Recovery Control Center
              </div>

              <Heading level="h1" className="text-xl font-semibold tracking-tight text-ui-fg-base sm:text-2xl">
                Recovery Dashboard
              </Heading>

              <Text className="mt-1 max-w-2xl text-sm leading-6 text-ui-fg-muted">
                Monitor protection health, detect file changes, and prepare polished recovery snapshots from one responsive command surface.
              </Text>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-center lg:min-w-[420px]">
            <div className="p-3">
              <div className="flex items-start gap-3 text-start">
                <div className={clsx("flex size-10 shrink-0 items-center justify-center rounded-xl", systemIdentityClass.tile[descriptor.tone])}>
                  <StatusIcon className="size-5" strokeWidth={2.2} />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Text className="truncate text-sm font-semibold text-ui-fg-base">{resolvedStatusLabel}</Text>
                    <span className="size-2 rounded-full bg-ui-fg-muted" />
                  </div>
                  <Text className="mt-0.5 line-clamp-2 text-xs leading-5 text-ui-fg-muted">
                    {lastSyncText}
                  </Text>
                </div>
              </div>
            </div>

            <div className="flex w-full flex-col gap-2 sm:w-40">
              <Button
                size="small"
                variant="secondary"
                onClick={handleQuickCheck}
                disabled={!quickCheckAction || isQuickCheckPending}
                className="h-9 w-full justify-center"
              >
                <span className="inline-flex items-center gap-2">
                  <RefreshCw
                    className={clsx("size-4", isQuickCheckPending ? "animate-spin" : "")}
                    strokeWidth={2.1}
                  />
                  {quickCheckContent}
                </span>
              </Button>

              <Button size="small" onClick={onCreateSnapshot} className="h-9 w-full justify-center shadow-elevation-card-rest">
                <span className="inline-flex items-center gap-2">
                  <ShieldCheck className="size-4" strokeWidth={2.1} />
                  {createSnapshotLabel}
                </span>
              </Button>
            </div>
          </div>
        </div>
      </Container>

      <PRMetricGrid>
        {visibleMetrics.map((metric) => {
          const Icon = metric.icon ?? ShieldCheck

          return (
            <PRMetricCard
              key={metric.title}
              title={metric.title}
              value={metric.value}
              description={metric.description}
              badge={metric.badge}
              footer={metric.footer}
              timestamp={metric.timestamp}
              action={metric.action}
              actionLabel={metric.actionLabel}
              onAction={metric.onAction}
              tone={metric.tone}
              identity={metric.identity}
              icon={Icon}
              trend={metric.trend}
              trendVariant={metric.trendVariant}
              progress={metric.progress}
            />
          )
        })}
      </PRMetricGrid>
    </div>
  )
}

export default DashboardCards
