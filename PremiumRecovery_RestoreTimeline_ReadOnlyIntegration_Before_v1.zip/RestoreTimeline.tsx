// src/admin/routes/premium-recovery/components/RestoreTimeline.tsx
// ============================================================
// Premium Recovery - Restore Timeline
// Medusa UI implementation
// No custom SVG, emoji icons, hardcoded colors, dark classes,
// arbitrary values, custom elevation, or dynamic Tailwind classes.
// ============================================================

import React from "react"
import { Badge, Button, Container, Heading, Text } from "../../../../ui/vendor"
import {
  ArrowPath,
  Calendar,
} from "../../../../ui/vendor/icons"
import {
  Database,
  Package,
  ShieldCheck,
} from "../../../../ui/vendor/lucide"

// ============================================================
// Types
// ============================================================

export type RestorePoint = {
  id: string
  name: string
  description: string
  business_context: string
  use_case: "manual" | "before_update" | "before_theme_change" | "before_plugin_install"
  files: string[]
  created_at: string
  hash: string
  category?: string
  human_date?: string
  bundle_available?: boolean
  recovery_risk?: string
}

type RestoreTimelineProps = {
  points: RestorePoint[]
  loading: boolean
  onSelect: (point: RestorePoint) => void
  onRestore: (point: RestorePoint) => void
  selectedId?: string
}

type RiskConfig = {
  label: string
  color: "green" | "orange" | "red" | "grey"
}

type UseCaseConfig = {
  label: string
  icon: React.ReactNode
}

// ============================================================
// Helpers
// ============================================================

const getUseCaseLabel = (useCase: RestorePoint["use_case"]) => {
  switch (useCase) {
    case "before_update":
      return "به‌روزرسانی"
    case "before_theme_change":
      return "تغییر قالب"
    case "before_plugin_install":
      return "نصب افزونه"
    case "manual":
      return "دستی"
    default:
      return "اسنپ‌شات"
  }
}

const getUseCaseConfig = (useCase: RestorePoint["use_case"]): UseCaseConfig => {
  const label = getUseCaseLabel(useCase)

  switch (useCase) {
    case "before_update":
      return {
        label,
        icon: <Package className="text-ui-fg-subtle" />,
      }
    case "before_plugin_install":
      return {
        label,
        icon: <Database className="text-ui-fg-subtle" />,
      }
    case "before_theme_change":
    case "manual":
    default:
      return {
        label,
        icon: <ShieldCheck className="text-ui-fg-subtle" />,
      }
  }
}

const getRiskConfig = (risk: string | undefined): RiskConfig => {
  switch (risk) {
    case "low":
      return {
        label: "ریسک کم",
        color: "green",
      }
    case "medium":
      return {
        label: "ریسک متوسط",
        color: "orange",
      }
    case "high":
      return {
        label: "ریسک بالا",
        color: "red",
      }
    default:
      return {
        label: "نامشخص",
        color: "grey",
      }
  }
}

const getCategoryTitle = (category: string) => {
  switch (category) {
    case "today":
      return "امروز"
    case "yesterday":
      return "دیروز"
    case "last_week":
      return "این هفته"
    default:
      return "قدیمی‌تر"
  }
}

const getPointDate = (point: RestorePoint) => {
  if (point.human_date) {
    return point.human_date
  }

  return new Date(point.created_at).toLocaleDateString("fa-IR")
}

// ============================================================
// Components
// ============================================================

const CategoryHeader = ({ category }: { category: string }) => {
  return (
    <div className="px-6 py-3">
      <Text size="small" className="text-ui-fg-muted">
        {getCategoryTitle(category)}
      </Text>
    </div>
  )
}

const EmptyState = () => {
  return (
    <Container className="p-0">
      <div className="flex items-center justify-center px-6 py-8">
        <div className="flex flex-col items-center gap-y-2 text-center">
          <div className="flex items-center justify-center rounded-full border border-ui-border-base bg-ui-bg-subtle p-3 shadow-elevation-card">
            <Database className="text-ui-fg-subtle" />
          </div>

          <Heading level="h3">هیچ اسنپ‌شاتی موجود نیست</Heading>

          <Text size="small" className="text-ui-fg-muted">
            پس از ایجاد اسنپ‌شات، نقاط بازیابی در این بخش نمایش داده می‌شوند.
          </Text>
        </div>
      </div>
    </Container>
  )
}

const LoadingState = () => {
  return (
    <Container className="p-0">
      <div className="flex items-center justify-center px-6 py-8">
        <div className="flex items-center gap-x-2">
          <ArrowPath className="text-ui-fg-subtle" />
          <Text size="small" className="text-ui-fg-muted">
            در حال بارگذاری نقاط بازیابی...
          </Text>
        </div>
      </div>
    </Container>
  )
}

const TimelineItem = ({
  point,
  isSelected,
  onSelect,
  onRestore,
}: {
  point: RestorePoint
  isSelected: boolean
  onSelect: (point: RestorePoint) => void
  onRestore: (point: RestorePoint) => void
}) => {
  const useCase = getUseCaseConfig(point.use_case)
  const risk = getRiskConfig(point.recovery_risk)

  return (
    <div
      className={
        isSelected
          ? "bg-ui-bg-subtle"
          : "bg-ui-bg-base hover:bg-ui-bg-hover"
      }
    >
      <button
        type="button"
        onClick={() => onSelect(point)}
        className="flex w-full flex-col gap-y-3 px-6 py-4 text-right transition-colors md:flex-row md:items-center md:justify-between"
      >
        <div className="flex min-w-0 items-start gap-x-3">
          <div className="flex items-center justify-center rounded-full border border-ui-border-base bg-ui-bg-subtle p-2 shadow-elevation-card">
            {useCase.icon}
          </div>

          <div className="flex min-w-0 flex-col gap-y-1">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <Heading level="h3">{point.name}</Heading>

              {point.bundle_available && (
                <Badge color="green">باندل</Badge>
              )}

              {isSelected && (
                <Badge color="blue">انتخاب شده</Badge>
              )}
            </div>

            <Text size="small" className="text-ui-fg-muted">
              {point.description || point.business_context || "بدون توضیح"}
            </Text>

            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <div className="flex items-center gap-x-1">
                <Calendar className="text-ui-fg-subtle" />
                <Text size="small" className="text-ui-fg-muted">
                  {getPointDate(point)}
                </Text>
              </div>

              <Text size="small" className="text-ui-fg-muted">
                {useCase.label}
              </Text>

              <Text size="small" className="text-ui-fg-muted">
                {point.files.length} فایل
              </Text>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-x-2 md:justify-end">
          <Badge color={risk.color}>{risk.label}</Badge>

          <Button
            type="button"
            variant="secondary"
            onClick={(event) => {
              event.stopPropagation()
              onRestore(point)
            }}
          >
            بازیابی
          </Button>
        </div>
      </button>
    </div>
  )
}

const TimelineSection = ({
  category,
  points,
  selectedId,
  onSelect,
  onRestore,
}: {
  category: string
  points: RestorePoint[]
  selectedId?: string
  onSelect: (point: RestorePoint) => void
  onRestore: (point: RestorePoint) => void
}) => {
  return (
    <Container className="overflow-hidden p-0">
      <CategoryHeader category={category} />

      <div className="divide-y divide-ui-border-base">
        {points.map((point) => (
          <TimelineItem
            key={point.id}
            point={point}
            isSelected={selectedId === point.id}
            onSelect={onSelect}
            onRestore={onRestore}
          />
        ))}
      </div>
    </Container>
  )
}

// ============================================================
// Main Component
// ============================================================

export const RestoreTimeline: React.FC<RestoreTimelineProps> = ({
  points,
  loading,
  onSelect,
  onRestore,
  selectedId,
}) => {
  const groupedPoints = React.useMemo(() => {
    const groups: Record<string, RestorePoint[]> = {}

    points.forEach((point) => {
      const category = point.category || "other"

      if (!groups[category]) {
        groups[category] = []
      }

      groups[category].push(point)
    })

    return groups
  }, [points])

  if (loading && points.length === 0) {
    return <LoadingState />
  }

  if (points.length === 0) {
    return <EmptyState />
  }

  return (
    <div className="flex flex-col gap-y-4">
      {Object.entries(groupedPoints).map(([category, items]) => (
        <TimelineSection
          key={category}
          category={category}
          points={items}
          selectedId={selectedId}
          onSelect={onSelect}
          onRestore={onRestore}
        />
      ))}
    </div>
  )
}

export default RestoreTimeline
