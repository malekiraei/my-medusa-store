export type SnapshotWorkflowStatus =
  | "idle"
  | "loading"
  | "selecting"
  | "metadata"
  | "review"
  | "creating"
  | "done"
  | "error"

export type SnapshotWorkflowFile = {
  path: string
  status?: string
  oldPath?: string
  business_impact?: string
  [key: string]: unknown
}

export type SnapshotWorkflowUseCase =
  | "manual"
  | "before_update"
  | "before_theme_change"
  | "before_plugin_install"

export type SnapshotWorkflowState = {
  status: SnapshotWorkflowStatus
  files: SnapshotWorkflowFile[]
  selectedFiles: string[]
  name: string
  description: string
  businessContext: string
  useCase: SnapshotWorkflowUseCase
  error: string | null
}

export type SnapshotWorkflowEvent =
  | { type: "OPEN" }
  | { type: "CLOSE" }
  | { type: "NEXT" }
  | { type: "BACK" }
  | { type: "CREATE" }
  | { type: "RETRY" }
  | { type: "TOGGLE_FILE"; path: string }
  | { type: "SELECT_ALL" }
  | { type: "SET_NAME"; name: string }
  | { type: "SET_DESCRIPTION"; description: string }
  | { type: "SET_BUSINESS_CONTEXT"; context: string }
  | { type: "SET_USE_CASE"; useCase: SnapshotWorkflowUseCase }
